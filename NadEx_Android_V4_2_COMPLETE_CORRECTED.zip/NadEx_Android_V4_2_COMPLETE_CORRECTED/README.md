# NadEx V4.1 — Executive Multi-Currency

This build preserves the existing NadEx package/application ID and legacy local-storage keys while adding the agreed UI and multi-currency layer.

## Included updates
- Executive single-view home screen based on the approved dark navy/cyan mockup.
- Family artwork dissolves into the background with no hard rectangular edges; Urdu names remain separate: آیان حذیفہ شایان زوھان.
- Modern Monthly Expenses and Ledger graphics.
- Transparent/glass content panels over the family watermark on all screens with high-contrast text.
- Restore/backup confirmations use the NadEx theme; Android file-save notification is returned into the themed app dialog.
- Latest Main Balance movement: green increase, red decrease, white neutral.
- Existing folded Ledger overview order retained: Money I Owe, Money I Will Get, Hard Money, My Expense.
- Optional Money I Owe party limit retained and extended to support a selected limit currency.
- Running balance retained for My Expense.
- Multi-currency architecture:
  - App Display Currency is selectable.
  - Every new ledger transaction can use its own transaction currency.
  - Manual transaction conversion rate is entered against the current app display currency.
  - Original amount/currency is permanently preserved.
  - Changing app display currency does not rewrite historical original transaction values.
  - When changing display currency, rates for currencies already used in records are requested so all balances can be valued consistently.
  - Statements/CSV show original currency plus current display-currency equivalent.
  - Monthly Expense purchases also support transaction currency and conversion.

## Data compatibility
- Ledger localStorage key remains `ledgerCalculationV1`.
- Monthly Expense localStorage key remains `transactorMessV2`.
- Legacy AED transactions are migrated in-place in memory/storage with original currency AED without deleting history.

## Android version
- versionCode: 41
- versionName: 4.1
