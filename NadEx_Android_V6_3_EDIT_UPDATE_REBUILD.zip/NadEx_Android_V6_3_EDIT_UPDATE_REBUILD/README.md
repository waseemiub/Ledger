# NadEx V6.3 — Edit/Update Rebuild
Built from V6.2. Replaces the competing V6.2 edit override with one final self-contained edit/update controller. Save writes the exact transaction to localStorage, verifies it, synchronizes linked transfer/movement amounts and date/time, then refreshes Ledger and statement. V6.1 minimal entry, numbers-only presentation, Monthly Expense and My Share are otherwise unchanged.
Version 6.3 / versionCode 63 / applicationId ae.transactor.app
