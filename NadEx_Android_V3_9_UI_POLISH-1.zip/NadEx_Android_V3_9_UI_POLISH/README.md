# NadEx Android V3.9 UI Polish
Based on V3.8. Preserves NadEx accounting/storage logic.
Changes: fixed single-view home, seamless dissolved family artwork, modern module icons, My Expense running balance, readable member/party controls, themed app modals.
