
/* NadEx V6.15 — MINIMAL functional patch on original V6.12.
   NO renderer replacement. NO CSS. NO HTML layout replacement. */
(function(){
'use strict';
const E15=id=>document.getElementById(id);
const saveD15=()=>localStorage.setItem(K,JSON.stringify(D));
const saveM15=()=>localStorage.setItem(MK,JSON.stringify(M));

/* 1) Monthly Expense only:
   Exclude "paid by me + only me involved" while the ORIGINAL V6.12
   Monthly Expense renderer/report executes. Restore the complete array
   immediately afterward, so Ledger > My Expense continues to see ALL items. */
function personalOnly15(p){
  let mine;try{mine=me().id}catch(e){return false}
  if(!p||String(p.paidBy)!==String(mine))return false;
  const a=(p.allocations||[]).filter(x=>Number(x.amount)>0.000001);
  return a.length===1&&String(a[0].memberId)===String(mine);
}
function withMonthlyFilter15(fn,ctx,args){
  const all=M.purchases;
  M.purchases=(all||[]).filter(p=>!personalOnly15(p));
  try{return fn.apply(ctx,args||[])}
  finally{M.purchases=all}
}
const originalMess15=window.renderMess;
window.renderMess=function(){return withMonthlyFilter15(originalMess15,this,arguments)};

const originalPdf15=window.exportMessPDF;
window.exportMessPDF=function(){return withMonthlyFilter15(originalPdf15,this,arguments)};

/* 2) Repair DELETE on the EXISTING Ledger party transaction screen.
   We do not rebuild the screen. We only replace the Save/Delete button
   handlers after the original transactionActions has drawn its modal. */
function confirm15(title,msg,yes){
  if(typeof nxConfirm==='function')return nxConfirm(title,msg,'DELETE',yes);
  if(confirm(msg))yes();
}
function exactTransactionActions15(id){
  const t=D.transactions.find(x=>String(x.id)===String(id));
  if(!t)return;

  /* Let existing V6.3 draw the exact existing edit/delete interface. */
  window.transactionActions(id);

  /* Expense-linked existing buttons: only repair Delete. */
  if(t.messId){
    const db=E15('deleteLinked');
    if(db)db.onclick=e=>{
      e.preventDefault();e.stopPropagation();
      const p=M.purchases.find(x=>String(x.id)===String(t.messId));
      if(!p)return alert('Linked expense purchase was not found.');
      confirm15('Delete Expense Purchase?','Delete this expense purchase and its linked Ledger entry?',()=>{
        M.purchases=M.purchases.filter(x=>String(x.id)!==String(p.id));
        D.transactions=D.transactions.filter(x=>String(x.messId||'')!==String(p.id)&&(!p.transferId||x.transferId!==p.transferId));
        saveM15();saveD15();close();renderLedger();party(window.__partyKey);
      });
    };
    return;
  }

  const del=E15('deleteTx');
  if(del)del.onclick=e=>{
    e.preventDefault();e.stopPropagation();
    const linked=t.transferId?D.transactions.filter(x=>x.transferId===t.transferId):[t];
    confirm15(t.transferId?'Delete Linked Transfer?':'Delete Transaction?',
      t.transferId?'Delete this entire linked transfer from both parties?':'Delete this transaction?',()=>{
        const ids=new Set(linked.map(x=>String(x.id)));
        D.transactions=D.transactions.filter(x=>!ids.has(String(x.id)));
        saveD15();

        /* Verify persistence before closing. */
        const saved=JSON.parse(localStorage.getItem(K)||'{}');
        if((saved.transactions||[]).some(x=>ids.has(String(x.id))))
          return alert('Delete could not be saved. Please try again.');

        close();renderLedger();party(window.__partyKey);
      });
  };
}

/* The original party() closes over app.js's old transactionActions.
   Rebind only the already-rendered transaction rows after party() runs.
   Nothing in the party layout or styling is replaced. */
const originalParty15=window.party;
window.party=function(k){
  const v=originalParty15.apply(this,arguments);
  const tl=E15('partyTimeline');
  if(tl)tl.querySelectorAll('[data-txid]').forEach(el=>{
    el.onclick=e=>{e.preventDefault();e.stopPropagation();exactTransactionActions15(el.dataset.txid)};
  });
  bindPartyManage15(k);
  return v;
};

/* 3) Party dropdown management, without rebuilding New Transaction UI.
   One small Manage Party button is appended to the EXISTING statement
   action area. No new page and no CSS changes. */
function hidden15(){
  if(!Array.isArray(D.hiddenParties))D.hiddenParties=[];
  return D.hiddenParties;
}
function isHidden15(k){return hidden15().includes(key(k))}
function filterPartyLists15(){
  const h=new Set(hidden15());
  ['parties','nxAccounts','transferParties'].forEach(id=>{
    const dl=E15(id);if(!dl)return;
    dl.querySelectorAll('option').forEach(o=>{
      const k=key(o.value||'');
      if(h.has(k))o.remove();
    });
  });
}
function manageParty15(k){
  k=key(k);
  const p=states().find(x=>x.key===k);
  if(!p||p.wallet||k===EXPENSE_KEY)return;
  const wasHidden=isHidden15(k);
  modal('Manage Party',
    '<div class="field"><label>Party Name</label><input id="p15name" value="'+esc(p.name)+'"></div>'+
    '<div class="opts two"><button id="p15rename" class="primary">SAVE NAME</button>'+
    '<button id="p15hide">'+(wasHidden?'SHOW IN DROPDOWN':'REMOVE FROM DROPDOWN')+'</button></div>');

  E15('p15rename').onclick=()=>{
    const name=String(E15('p15name').value||'').trim().replace(/\s+/g,' ');
    if(!name)return alert('Enter a party name.');
    const nk=key(name);
    if(isWalletKey(nk)||nk===EXPENSE_KEY)return alert('Choose a different party name.');
    const clash=states().find(x=>x.key===nk&&x.key!==k);
    if(clash)return alert('A party with this name already exists.');
    D.transactions.forEach(t=>{if(canonicalPartyKey(t)===k){t.partyKey=nk;t.party=name}});
    if(D.partyLimits&&Object.prototype.hasOwnProperty.call(D.partyLimits,k)){
      D.partyLimits[nk]=D.partyLimits[k];delete D.partyLimits[k];
    }
    if(isHidden15(k)){
      D.hiddenParties=hidden15().filter(x=>x!==k);D.hiddenParties.push(nk);
    }
    saveD15();close();renderLedger();party(nk);
  };
  E15('p15hide').onclick=()=>{
    D.hiddenParties=hidden15().filter(x=>x!==k);
    if(!wasHidden)D.hiddenParties.push(k);
    saveD15();close();renderLedger();party(k);
  };
}
function bindPartyManage15(k){
  const p=states().find(x=>x.key===key(k));
  const host=E15('partyPdf')?.parentElement;
  const old=E15('p15manage');if(old)old.remove();
  if(!host||!p||p.wallet||p.key===EXPENSE_KEY)return;
  const b=document.createElement('button');
  b.id='p15manage';b.type='button';b.textContent='Manage Party';
  b.onclick=e=>{e.preventDefault();e.stopPropagation();manageParty15(k)};
  host.appendChild(b);
}

/* Keep the ORIGINAL ledgerEntry. Only filter its existing datalist after open. */
const originalEntry15=window.ledgerEntry;
window.ledgerEntry=function(){
  const v=originalEntry15.apply(this,arguments);
  filterPartyLists15();
  return v;
};

/* Main Balance Statement is already present in the V6.12 base through v67.
   Do not replace or restyle it. */

})();
