NadEx V6.15 - minimal functional correction built from ORIGINAL V6.12.

NO CSS changes.
NO Monthly Expense renderer replacement.
NO ledgerEntry renderer replacement.
NO party statement layout replacement.
NO settings changes.

Only:
1) Monthly Expense personal-only records are temporarily filtered while the original Monthly Expense UI/PDF renders. Ledger My Expense still sees the complete records.
2) Existing Ledger party transaction rows are rebound to the existing V6.3 edit modal, with repaired Delete persistence.
3) Existing party statement gets one Manage Party button for Rename / Remove from Dropdown. Existing New Transaction UI is untouched; only its datalist is filtered after opening.
4) Existing Main Balance Statement from the V6.12 base is preserved unchanged.
