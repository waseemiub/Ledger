
/* NadEx V6.1 — one universal transaction form, numbers-only display. */
(function(){
'use strict';
const EXTERNAL='__external__', PERSONAL='__personal_expense__';
const num=v=>{v=Number(v);return Number.isFinite(v)?v:0};
const tidy=v=>String(v||'').trim().replace(/\s+/g,' ');

function listHtml(){
  let a=states().slice().sort((x,y)=>(!!y.wallet-!!x.wallet)||x.name.localeCompare(y.name));
  return `<datalist id="nxAccounts">${a.map(p=>`<option value="${esc(p.name)}"></option>`).join('')}
  <option value="External / No Account"></option><option value="My Expense"></option></datalist>`;
}
function resolve(v){
  let name=tidy(v); if(!name)return null;
  if(/^external\s*\/?\s*no account$/i.test(name))return{special:EXTERNAL,name:'External / No Account'};
  if(/^my expense$/i.test(name))return{special:PERSONAL,name:'My Expense'};
  let k=key(name),old=states().find(p=>p.key===k);
  return old||{key:k,name,wallet:isWalletKey(k)};
}
window.ledgerEntry=function(){
  modal('New Transaction',`${listHtml()}<div class="nx-entry">
    <div class="field nx-amount"><label>Amount</label><input id="nxAmount" type="number" inputmode="decimal" min=".01" step=".01" placeholder="0.00"></div>
    <div class="field"><label>Action</label><div class="nx-toggle"><button type="button" id="nxWithdraw" class="active">WITHDRAW</button><button type="button" id="nxDeposit">DEPOSIT</button></div></div>
    <div class="field"><label id="nxPrimaryLabel">Withdraw From</label><input id="nxPrimary" list="nxAccounts" placeholder="Select any account or party"></div>
    <div class="field"><label id="nxOtherLabel">Paid To / For</label><input id="nxOther" list="nxAccounts" placeholder="Select party, account, My Expense or External"></div>
    <div class="field"><label>Description <small>(optional)</small></label><textarea id="nxDesc" placeholder="What was this transaction for?"></textarea></div>
    <button id="nxSave" class="primary wide">SAVE TRANSACTION</button>
    <div class="nx-rule"><b>Automatic accounting</b><span>NadEx decides Money I Owe or Money I Will Get from the resulting party balance. You only record where the amount moved.</span></div>
  </div>`);
  let mode='withdraw';
  function paint(){
    $('nxWithdraw').classList.toggle('active',mode==='withdraw');
    $('nxDeposit').classList.toggle('active',mode==='deposit');
    $('nxPrimaryLabel').textContent=mode==='withdraw'?'Withdraw From':'Deposit Into';
    $('nxOtherLabel').textContent=mode==='withdraw'?'Paid To / For':'Received From';
  }
  $('nxWithdraw').onclick=()=>{mode='withdraw';paint()};
  $('nxDeposit').onclick=()=>{mode='deposit';paint()};
  $('nxSave').onclick=()=>saveUniversal(mode);
  paint();
};
function push(a,kind,amount,description,id,role,ts){
  D.transactions.push({id:uid('LED'),ts,partyKey:a.key,party:a.name,description,amount,kind,movementId:id,movementRole:role});
}
function expense(amount,source,desc){
  if(!source||source.special)return alert('Select the account or party the expense was withdrawn from.');
  let id=uid('MESS'),ts=Date.now(),mid=me().id;
  M.purchases.push({id,ts,description:desc||'Personal expense',amount,paidBy:mid,splitMode:'individual',
    allocations:[{memberId:mid,amount}],cycleId:activeCycle().id,ledgerIntent:null,currencyMeta:null,transferId:null});
  push(source,'subtract',amount,`Personal expense${desc?' — '+desc:''}`,uid('MOV'),'funding',ts-1);
  localStorage.setItem(MK,JSON.stringify(M));localStorage.setItem(K,JSON.stringify(D));
  close();renderLedger();renderMess();
}
window.saveUniversal=function(mode){
  let amount=num($('nxAmount').value),a=resolve($('nxPrimary').value),b=resolve($('nxOther').value),desc=tidy($('nxDesc').value);
  if(!(amount>0))return alert('Enter a valid amount.');
  if(!a)return alert(mode==='withdraw'?'Select Withdraw From.':'Select Deposit Into.');
  if(!b)return alert(mode==='withdraw'?'Select Paid To / For.':'Select Received From.');
  if(a.special)return alert('The first selection must be an account or party.');
  if(a.key&&b.key&&a.key===b.key)return alert('Choose two different accounts or parties.');
  if(mode==='deposit'&&b.special===PERSONAL)return alert('My Expense is used with Withdraw.');
  if(mode==='withdraw'&&b.special===PERSONAL)return expense(amount,a,desc);
  let ts=Date.now(),id=uid('MOV');
  if(mode==='withdraw'){
    push(a,'subtract',amount,`Paid${b.special===EXTERNAL?' externally':' to '+b.name}${desc?' — '+desc:''}`,id,'from',ts);
    if(b.special!==EXTERNAL)push(b,'add',amount,`Received from ${a.name}${desc?' — '+desc:''}`,id,'to',ts+1);
  }else{
    push(a,'add',amount,`Received${b.special===EXTERNAL?' externally':' from '+b.name}${desc?' — '+desc:''}`,id,'to',ts);
    if(b.special!==EXTERNAL)push(b,'subtract',amount,`Paid into ${a.name}${desc?' — '+desc:''}`,id,'from',ts+1);
  }
  localStorage.setItem(K,JSON.stringify(D));close();renderLedger();
};
let nb=$('new');if(nb)nb.onclick=()=>window.ledgerEntry();

function strip(root=document){
  let rx=/\b(?:AED|USD|EUR|GBP|PKR|INR|SAR|QAR|KWD|BHD|OMR|JPY|CNY|CAD|AUD)\s+/g;
  root.querySelectorAll('#ledgerView .section-total,#ledgerFullBalanceV59,#ledgerMovementV59,#partyBalance,#partyIn,#partyOut,#monthExpense,#myMessBalance,.purchase .total,.pt-amount,.pt-balance,.pt-meta').forEach(el=>{
    if(!el.children.length)el.textContent=el.textContent.replace(rx,'').trim();
  });
}
let rl=window.renderLedger;window.renderLedger=function(){rl();strip()};
let rm=window.renderMess;window.renderMess=function(){rm();strip()};
let rp=window.party;window.party=function(k){rp(k);strip()};
let re=window.myExpenseParty;window.myExpenseParty=function(){re();strip()};
if(D.settings)D.settings.displayCurrency='';
localStorage.setItem(K,JSON.stringify(D));
renderLedger();renderMess();
})();
