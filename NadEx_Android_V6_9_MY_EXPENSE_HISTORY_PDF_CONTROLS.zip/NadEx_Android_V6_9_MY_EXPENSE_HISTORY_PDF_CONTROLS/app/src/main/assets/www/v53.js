/* NadEx V5.3 — responsive section totals + compact expense transactions */
(()=>{
  function sectionTotals(){
    const s=states(), wallets=s.filter(p=>p.wallet), others=s.filter(p=>!p.wallet&&p.key!==EXPENSE_KEY), share=s.find(p=>p.key===EXPENSE_KEY)||{balance:0};
    return {
      pay: others.filter(p=>p.balance<0).reduce((n,p)=>n+Math.abs(p.balance),0)+Math.max(-share.balance,0),
      rec: others.filter(p=>p.balance>0).reduce((n,p)=>n+p.balance,0)+Math.max(share.balance,0),
      wallet: wallets.reduce((n,p)=>n+p.balance,0),
      expense: myExpenseData().total||0
    };
  }
  function decorateFoldHeads(){
    const dc=(D.settings&&D.settings.displayCurrency)||'', t=sectionTotals();
    [['pay','Money I Owe',t.pay],['rec','Money I Will Get',t.rec],['wallet','Money With Me',t.wallet],['expense','My Expense',t.expense]].forEach(([cls,name,val])=>{
      const h=document.querySelector('.group.'+cls+' .fold-head'); if(!h)return;
      const num=h.querySelector(':scope > span')?.outerHTML||'';
      h.innerHTML=`${num}<span class="section-name">${name}</span><span class="section-total"><small>${cls==='expense'?'TOTAL':'BALANCE'}</small>${dc} ${money(Math.abs(val))}</span><i class="fold-arrow">⌄</i>`;
      h.setAttribute('role','button');h.setAttribute('aria-label',name+' '+dc+' '+money(Math.abs(val))+'; tap to open');
    });
  }
  const previousLedger=renderLedger;
  renderLedger=function(){previousLedger();decorateFoldHeads();};

  const previousMess=renderMess;
  renderMess=function(){
    previousMess();
    const ps=purchasesForCycle();
    const box=$('purchaseList');
    if(box){
      box.innerHTML=ps.length?ps.map(p=>{
        const payer=M.members.find(m=>m.id===p.paidBy)?.name||'Unknown';
        const names=p.allocations.map(a=>M.members.find(m=>m.id===a.memberId)?.name||'Member').join(', ');
        const split=p.splitMode==='equal'?'Equal':'Individual';
        return `<article class="purchase compact-purchase">
          <div class="purchase-main"><h3>${esc(p.description||'Purchase')}</h3><div class="purchase-meta">${new Date(p.ts).toLocaleDateString()} • ${esc(payer)} • ${split}: ${esc(names)}</div></div>
          <div class="purchase-amount">AED ${money(p.amount)}</div>
          <div class="purchase-actions"><button data-viewp="${p.id}">Details</button><button data-editp="${p.id}">Edit</button><button data-delp="${p.id}">Delete</button></div>
        </article>`;
      }).join(''):'<div class="empty">No purchases in this cycle</div>';
      box.querySelectorAll('[data-viewp]').forEach(b=>b.onclick=()=>purchaseDetails(b.dataset.viewp));
      box.querySelectorAll('[data-editp]').forEach(b=>b.onclick=()=>openPurchase({editId:b.dataset.editp}));
      box.querySelectorAll('[data-delp]').forEach(b=>b.onclick=()=>deletePurchase(b.dataset.delp));
    }
  };

  // Rebind fold headers after v5.3 replaces their markup. Entire category card remains touch responsive.
  document.querySelectorAll('.fold-head').forEach(h=>{
    const toggle=()=>h.parentElement.classList.toggle('collapsed');
    h.onclick=toggle;h.onkeydown=e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();toggle();}};
  });
  renderLedger();renderMess();
})();
