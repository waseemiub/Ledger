/* NadEx V5.4 — restore-safe ledger category renderer */
(()=>{
  const dc=()=>((D.settings&&D.settings.displayCurrency)||'');
  const abs=n=>money(Math.abs(Number(n)||0));

  function partyStats(pk){
    const rows=(D.transactions||[]).filter(t=>{
      try{return (typeof canonicalPartyKey==='function'?canonicalPartyKey(t):t.partyKey)===pk}catch(e){return t.partyKey===pk}
    });
    let tin=0,tout=0;
    rows.forEach(t=>{
      let v;
      try{v=typeof nxTransactionValue==='function'?nxTransactionValue(t):Number(t.amount||0)}catch(e){v=Number(t.amount||0)}
      if(t.kind==='add')tin+=v;else tout+=v;
    });
    return {rows,tin,tout};
  }

  function card(p){
    const x=partyStats(p.key), cur=dc();
    let rem=null;
    try{if(!p.wallet&&p.balance<0)rem=remainingOweLimit(p.key,p.balance)}catch(e){}
    const meaning=p.wallet?'Available balance':p.balance>0?'You will receive':p.balance<0?'You owe':'Settled';
    return `<article class="account-overview-card v54-party" data-k="${esc(p.key)}">
      <div class="account-overview-top"><div><small>${esc(meaning)}</small><h3>${esc(p.name)}</h3></div><b class="${p.balance>0?'pos':p.balance<0?'neg':'neu'}">${cur} ${abs(p.balance)}</b></div>
      <div class="account-overview-stats"><span><small>TOTAL IN</small><b>${cur} ${money(x.tin)}</b></span><span><small>TOTAL OUT</small><b>${cur} ${money(x.tout)}</b></span><span><small>ENTRIES</small><b>${x.rows.length}</b></span></div>
      ${rem==null?'':`<div class="overview-limit">Remaining limit: ${cur} ${money(rem)}</div>`}
      <div class="account-overview-foot"><span>${p.modified?new Date(p.modified).toLocaleString():(p.wallet?'Available account':'No activity')}</span><b>View statement ›</b></div>
    </article>`;
  }

  function fill(id,arr,showZero){
    const box=document.getElementById(id); if(!box)return;
    const a=(showZero?arr:arr.filter(p=>Math.abs(Number(p.balance)||0)>.000001)).slice().sort((x,y)=>(y.modified||0)-(x.modified||0));
    box.innerHTML=a.length?a.map(card).join(''):'<div class="empty">None</div>';
    box.querySelectorAll('[data-k]').forEach(el=>el.onclick=()=>party(el.dataset.k));
  }

  function expenseCard(){
    const box=document.getElementById('expenseAccount'); if(!box)return;
    const x=myExpenseData(),cur=dc(),last=x.items.length?x.items[x.items.length-1].ts:0;
    box.innerHTML=`<article class="account-overview-card v54-party" data-expense="1"><div class="account-overview-top"><div><small>Personal spending</small><h3>My Expense</h3></div><b class="neg">${cur} ${money(x.total||0)}</b></div><div class="account-overview-stats"><span><small>TOTAL</small><b>${cur} ${money(x.total||0)}</b></span><span><small>ENTRIES</small><b>${x.items.length}</b></span><span><small>LATEST</small><b>${last?new Date(last).toLocaleDateString():'—'}</b></span></div><div class="account-overview-foot"><span>Linked to Monthly Expense Details</span><b>View statement ›</b></div></article>`;
    box.querySelector('[data-expense]').onclick=()=>party(MY_EXPENSE_VIEW_KEY);
  }

  function totalsAndBodies(){
    const s=states(), wallets=s.filter(p=>p.wallet), others=s.filter(p=>!p.wallet&&p.key!==EXPENSE_KEY), share=s.find(p=>p.key===EXPENSE_KEY)||{key:EXPENSE_KEY,name:EXPENSE_NAME,balance:0,modified:0};
    const sets={pay:others.filter(p=>p.balance<0),rec:[share,...others.filter(p=>p.balance>0)],wallet:wallets};
    fill('payments',sets.pay,false); fill('receivables',sets.rec,true); fill('wallets',sets.wallet,true); expenseCard();
    const vals={pay:sets.pay.reduce((n,p)=>n+Math.abs(p.balance),0)+Math.max(-share.balance,0),rec:others.filter(p=>p.balance>0).reduce((n,p)=>n+p.balance,0)+Math.max(share.balance,0),wallet:wallets.reduce((n,p)=>n+p.balance,0),expense:myExpenseData().total||0};
    [['pay','Money I Owe'],['rec','Money I Will Get'],['wallet','Money With Me'],['expense','My Expense']].forEach(([cls,name])=>{
      const h=document.querySelector('.group.'+cls+' .fold-head'); if(!h)return;
      let total=h.querySelector('.section-total');
      if(!total){total=document.createElement('span');total.className='section-total';const arrow=h.querySelector('.fold-arrow');h.insertBefore(total,arrow)}
      total.innerHTML=`<small>${cls==='expense'?'TOTAL':'BALANCE'}</small>${dc()} ${abs(vals[cls])}`;
      h.onclick=()=>h.parentElement.classList.toggle('collapsed');
      h.onkeydown=e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();h.click()}};
    });
  }

  const base=renderLedger;
  renderLedger=function(){base();totalsAndBodies();};
  renderLedger();
})();
