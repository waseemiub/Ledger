
(function(){
'use strict';
function entry(){
 const b=document.getElementById('new'); if(!b)return;
 b.onclick=function(e){e.preventDefault();e.stopPropagation();window.ledgerEntry();};
}
function purchase(){
 ['newPurchase','newPurchaseTop'].forEach(id=>{
  const b=document.getElementById(id);if(!b)return;
  b.onclick=function(e){e.preventDefault();e.stopPropagation();window.__nxFund=null;window.openPurchase({});};
 });
}
const a=window.renderLedger;if(typeof a==='function')window.renderLedger=function(){const r=a.apply(this,arguments);setTimeout(entry,0);return r};
const b=window.renderMess;if(typeof b==='function')window.renderMess=function(){const r=b.apply(this,arguments);setTimeout(purchase,0);return r};
document.addEventListener('DOMContentLoaded',()=>setTimeout(()=>{entry();purchase()},0));
setTimeout(()=>{entry();purchase()},300);
})();
