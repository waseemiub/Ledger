
/* NadEx V6.6 — Ledger and Monthly Expense are independent.
   Monthly Expense never posts to Ledger. Ledger My Share/My Expense is manual only. */
(function(){
'use strict';
const $6=id=>document.getElementById(id);
const r2=v=>Math.round((Number(v)||0)*100)/100;

/* ---------------- MONTHLY EXPENSE: STANDALONE ---------------- */

window.syncMessLedger=function(){ /* intentionally disconnected in V6.6 */ };

function saveMessOnly(){ localStorage.setItem(MK,JSON.stringify(M)); }

window.openPurchase=function(o={}){
  const p=o.editId?M.purchases.find(x=>x.id===o.editId):null;
  const amount=p?.amount??'';
  const desc=p?.description??'';
  const payer=p?.paidBy??me().id;
  const mode=p?.splitMode||'equal';
  const alloc=new Map((p?.allocations||[]).map(a=>[a.memberId,Number(a.amount)||0]));
  const active=M.members.filter(m=>m.active||alloc.has(m.id));

  modal(p?'Edit Purchase':'New Purchase',`
    <div class="field"><label>Description</label><input id="pdesc" value="${esc(desc)}" placeholder="e.g. Groceries"></div>
    <div class="field"><label>Paid By</label><select id="ppaid">${active.map(m=>`<option value="${m.id}" ${m.id===payer?'selected':''}>${esc(m.name)}</option>`).join('')}</select></div>
    <div class="field"><label>Total Amount</label><input id="pamount" type="number" inputmode="decimal" step=".01" min=".01" value="${esc(amount)}"></div>
    <div class="field"><label>Split Method</label><select id="pmode"><option value="equal" ${mode==='equal'?'selected':''}>Divide Equally</option><option value="individual" ${mode==='individual'?'selected':''}>Enter Individual Amounts</option></select></div>
    <div class="field"><label>Members Involved</label><div class="check-grid" id="memberChecks">
      ${active.map(m=>`<label class="check-row"><input type="checkbox" data-mid="${m.id}" ${(p?alloc.has(m.id):true)?'checked':''}><span>${esc(m.name)}</span><input class="share" data-share="${m.id}" type="number" inputmode="decimal" step=".01" min="0" value="${alloc.has(m.id)?r2(alloc.get(m.id)):''}" ${mode==='equal'?'disabled':''}></label>`).join('')}
    </div></div>
    <div id="splitPreview" class="split-box"></div>
    <button type="button" id="savePurchase" class="primary wide" style="margin-top:12px">${p?'UPDATE PURCHASE':'SAVE PURCHASE'}</button>`);

  function recalc(){
    const total=Number($6('pamount').value)||0;
    const checks=[...document.querySelectorAll('#memberChecks [data-mid]')].filter(c=>c.checked);
    const md=$6('pmode').value;
    document.querySelectorAll('#memberChecks .share').forEach(i=>{
      const c=document.querySelector(`#memberChecks [data-mid="${i.dataset.share}"]`);
      i.disabled=md==='equal'||!c?.checked;
    });
    if(md==='equal'){
      $6('splitPreview').textContent=checks.length?`Equal share: ${money(total/checks.length)} each (${checks.length} members)`:'Select at least one member';
    }else{
      const sum=checks.reduce((a,c)=>a+(Number(document.querySelector(`#memberChecks [data-share="${c.dataset.mid}"]`)?.value)||0),0);
      $6('splitPreview').textContent=`Allocated: ${money(sum)} / ${money(total)}`;
    }
  }
  $6('pmode').addEventListener('change',recalc);
  $6('pamount').addEventListener('input',recalc);
  document.querySelectorAll('#memberChecks [data-mid],#memberChecks .share').forEach(i=>i.addEventListener('input',recalc));
  recalc();

  $6('savePurchase').addEventListener('click',function(ev){
    ev.preventDefault();ev.stopPropagation();
    const btn=this;
    const amount=Number($6('pamount').value);
    const description=$6('pdesc').value.trim();
    const paidBy=$6('ppaid').value;
    const splitMode=$6('pmode').value;
    const checks=[...document.querySelectorAll('#memberChecks [data-mid]')].filter(c=>c.checked);
    if(!(amount>0))return alert('Enter a valid amount.');
    if(!description)return alert('Enter a description.');
    if(!checks.length)return alert('Select at least one member.');

    let allocations=[];
    if(splitMode==='equal'){
      let remaining=r2(amount), raw=amount/checks.length;
      checks.forEach((c,i)=>{
        const a=i===checks.length-1?remaining:r2(raw);
        remaining=r2(remaining-a);
        allocations.push({memberId:c.dataset.mid,amount:a});
      });
    }else{
      allocations=checks.map(c=>({memberId:c.dataset.mid,amount:r2(document.querySelector(`#memberChecks [data-share="${c.dataset.mid}"]`).value)}));
      const sum=r2(allocations.reduce((a,x)=>a+x.amount,0));
      if(Math.abs(sum-amount)>.009)return alert(`Individual amounts must total ${money(amount)}.`);
    }

    btn.disabled=true;btn.textContent=p?'UPDATING...':'SAVING...';
    try{
      const old=p;
      const rec={
        id:old?.id||uid('MESS'),
        ts:old?.ts||Date.now(),
        description,
        amount:r2(amount),
        paidBy,
        splitMode,
        allocations,
        cycleId:old?.cycleId||activeCycle().id
      };
      if(old) M.purchases[M.purchases.indexOf(old)]=rec;
      else M.purchases.push(rec);

      saveMessOnly();

      /* Remove any old auto-generated Ledger link for this purchase.
         Monthly Expense is independent from Ledger from V6.6 onward. */
      D.transactions=D.transactions.filter(t=>t.messId!==rec.id);
      localStorage.setItem(K,JSON.stringify(D));

      const verify=JSON.parse(localStorage.getItem(MK)||'{}');
      if(!(verify.purchases||[]).some(x=>x.id===rec.id))throw new Error('Purchase storage verification failed.');

      btn.textContent=p?'UPDATED':'SAVED';
      setTimeout(()=>{close();renderMess();setMessTab('purchases');renderLedger();},100);
    }catch(err){
      console.error('V6.6 purchase save',err);
      btn.disabled=false;btn.textContent=p?'UPDATE PURCHASE':'SAVE PURCHASE';
      alert('Purchase save failed: '+(err.message||'Unknown error'));
    }
  });
};

/* Purchase details: add a reliable Edit button. */
window.purchaseDetails=function(id){
  const p=M.purchases.find(x=>x.id===id); if(!p)return;
  const payer=M.members.find(m=>m.id===p.paidBy)?.name||'Unknown';
  modal('Purchase Details',`
    <div class="themed-dialog"><div class="dialog-icon">▤</div><h3>${esc(p.description)}</h3><p>${new Date(p.ts).toLocaleString()}</p></div>
    <p>Paid by: <b>${esc(payer)}</b><br>Total: <b>${money(p.amount)}</b><br>Split: ${p.splitMode==='equal'?'Equal':'Individual'}</p>
    <div class="table"><table><tr><th>Member</th><th>Share</th></tr>${p.allocations.map(a=>`<tr><td>${esc(M.members.find(m=>m.id===a.memberId)?.name||'Member')}</td><td>${money(a.amount)}</td></tr>`).join('')}</table></div>
    <div class="opts two"><button type="button" id="v66EditPurchase" class="primary">EDIT PURCHASE</button><button type="button" id="v66DeletePurchase" class="danger">DELETE PURCHASE</button></div>`);
  $6('v66EditPurchase').addEventListener('click',()=>{close();openPurchase({editId:id});});
  $6('v66DeletePurchase').addEventListener('click',()=>{close();deletePurchase(id);});
};

/* Rebind both purchase entry buttons after every Monthly Expense render. */
function bindMess(){
  const a=$6('newPurchase'),b=$6('newPurchaseTop');
  if(a)a.onclick=e=>{e.preventDefault();openPurchase({});};
  if(b)b.onclick=e=>{e.preventDefault();openPurchase({});};
}
const priorMess=window.renderMess;
window.renderMess=function(){const r=priorMess.apply(this,arguments);bindMess();return r;};

/* ---------------- LEDGER: MANUAL MY SHARE / MY EXPENSE ---------------- */

/* Ignore historical Monthly Expense auto-posts in Ledger calculations.
   They remain stored for compatibility but no longer affect Ledger. */
const priorStates=window.states;
window.states=function(){
  const hidden=D.transactions.filter(t=>t.messId);
  if(!hidden.length)return priorStates();
  const original=D.transactions;
  try{D.transactions=original.filter(t=>!t.messId);return priorStates();}
  finally{D.transactions=original;}
};

/* My Expense is informational only and mirrors manual Ledger transactions
   posted to My Share (EXPENSE_KEY). */
window.myExpenseData=function(){
  const items=D.transactions.filter(t=>!t.messId && canonicalPartyKey(t)===EXPENSE_KEY)
    .sort((a,b)=>(a.ts||0)-(b.ts||0))
    .map(t=>({...t,myAmount:Number(t.amount)||0}));
  let total=0;
  items.forEach(t=>{total+=t.kind==='add'?(Number(t.amount)||0):-(Number(t.amount)||0);});
  return {cycle:null,items,total:Math.abs(r2(total))};
};

/* My Expense selection in the universal Ledger form is now a Ledger-only
   My Share posting. It does NOT create a Monthly Expense purchase. */
window.expense=function(amount,from,description){
  const ts=Date.now(), movementId=uid('MOV');
  D.transactions.push({
    id:uid('LED'),ts,partyKey:from.key,party:from.name,
    description:description||'My Expense',amount:r2(amount),kind:'subtract',
    movementId,movementRole:'from'
  });
  D.transactions.push({
    id:uid('LED'),ts:ts+1,partyKey:EXPENSE_KEY,party:EXPENSE_NAME,
    description:description||'My Expense',amount:r2(amount),kind:'add',
    movementId,movementRole:'expense'
  });
  localStorage.setItem(K,JSON.stringify(D));
  close();renderLedger();
};

/* Replace the old Monthly-Expense-derived My Expense statement with a
   Ledger-only informational statement. */
window.myExpenseParty=function(){
  const data=D.transactions.filter(t=>!t.messId && canonicalPartyKey(t)===EXPENSE_KEY).sort((a,b)=>a.ts-b.ts);
  let running=0;
  const rows=data.map(t=>{running+=t.kind==='add'?Number(t.amount)||0:-(Number(t.amount)||0);return {...t,running};});
  $6('partyTitle').textContent='My Expense';
  $6('partySubtitle').textContent='Information only • Ledger';
  $6('partyBalance').textContent=money(Math.abs(r2(running)));
  $6('partyMeaning').textContent='Based only on manual My Share / My Expense Ledger entries';
  $6('partyIn').textContent=money(data.filter(t=>t.kind==='add').reduce((a,t)=>a+(Number(t.amount)||0),0));
  $6('partyOut').textContent=money(data.filter(t=>t.kind==='subtract').reduce((a,t)=>a+(Number(t.amount)||0),0));
  $6('partyCount').textContent=data.length;
  $6('partyTimeline').innerHTML=rows.length?rows.slice().reverse().map(t=>`<div class="party-tx editable-tx" data-txid="${esc(t.id)}"><div><div class="pt-date">${new Date(t.ts).toLocaleDateString()} • ${new Date(t.ts).toLocaleTimeString()}</div><div class="pt-desc">${esc(t.description||'My Expense')}</div><div class="pt-meta">Ledger entry</div></div><div><div class="pt-amount ${t.kind==='add'?'pos':'neg'}">${t.kind==='add'?'+':'−'} ${money(t.amount)}</div><div class="pt-balance">Running: ${money(t.running)}</div><div class="pt-edit">Tap to edit / delete</div></div></div>`).join(''):'<div class="empty">No My Expense Ledger entries yet</div>';
  $6('partyTimeline').querySelectorAll('[data-txid]').forEach(e=>e.onclick=()=>transactionActions(e.dataset.txid));
  window.__partyKey=MY_EXPENSE_VIEW_KEY;
  showView('partyView');
};

document.addEventListener('DOMContentLoaded',()=>setTimeout(bindMess,0));
setTimeout(bindMess,250);
})();
