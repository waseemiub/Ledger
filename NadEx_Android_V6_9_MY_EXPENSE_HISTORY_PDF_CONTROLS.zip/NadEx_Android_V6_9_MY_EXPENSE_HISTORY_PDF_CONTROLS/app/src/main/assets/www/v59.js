/* NadEx V5.9 — Ledger Overview balance visibility + latest movement UI only.
   No transaction, Monthly Expense, My Share, backup/restore or accounting mutation. */
(function(){
  'use strict';
  var VIS_KEY='nadexLedgerOverviewVisibleV59';
  function E(id){return document.getElementById(id);}
  function n(v){v=Number(v);return Number.isFinite(v)?v:0;}
  function dc(){return (D.settings&&D.settings.displayCurrency)||'';}
  function visible(){return localStorage.getItem(VIS_KEY)!=='0';}
  function share(){try{var r=messStats(),mine=r.stats.get(me().id);return mine?n(mine.balance):0;}catch(e){return 0;}}
  function totals(){
    var s=states(), wallets=s.filter(function(p){return !!p.wallet;}), others=s.filter(function(p){return !p.wallet&&p.key!==EXPENSE_KEY;}), sh=share();
    var hard=wallets.reduce(function(a,p){return a+n(p.balance);},0);
    var otherNet=others.reduce(function(a,p){return a+n(p.balance);},0);
    return {full:hard+otherNet+sh};
  }
  function ensurePanel(){
    var main=document.querySelector('#ledgerView .inner-main'), head=main&&main.querySelector('.section-head');
    if(!main||!head)return null;
    var p=E('ledgerPositionV59');
    if(!p){
      p=document.createElement('section');p.id='ledgerPositionV59';p.className='ledger-position-v59';
      p.innerHTML='<div class="lp-top"><div><small>FULL LEDGER BALANCE</small><b id="ledgerFullBalanceV59">AED 0.00</b></div><button id="ledgerPrivacyV59" type="button">Hide</button></div><div id="ledgerMovementV59" class="lp-movement neutral">• AED 0.00</div>';
      main.insertBefore(p,head);
      E('ledgerPrivacyV59').onclick=function(){localStorage.setItem(VIS_KEY,visible()?'0':'1');applyPrivacy();};
    }
    return p;
  }
  function movement(){
    try{return latestBalanceMovement();}catch(e){return {delta:0,empty:true};}
  }
  function paintMovement(){
    var box=E('ledgerMovementV59');if(!box)return;
    var x=movement(),d=n(x.delta),c=dc();box.className='lp-movement';
    if(x.empty||Math.abs(d)<.005){box.classList.add('neutral');box.textContent='• '+c+' 0.00';}
    else if(d>0){box.classList.add('up');box.textContent='▲ + '+c+' '+money(d);}
    else{box.classList.add('down');box.textContent='▼ − '+c+' '+money(Math.abs(d));}
  }
  function applyPrivacy(){
    var show=visible(), btn=E('ledgerPrivacyV59'), full=E('ledgerFullBalanceV59'), mov=E('ledgerMovementV59');
    if(btn)btn.textContent=show?'Hide':'Show';
    if(full)full.classList.toggle('money-hidden',!show);
    if(mov)mov.classList.toggle('money-hidden',!show);
    document.querySelectorAll('#ledgerView .section-total').forEach(function(el){el.classList.toggle('money-hidden',!show);});
  }
  function renderV59(){
    ensurePanel();
    var t=totals(), full=E('ledgerFullBalanceV59');
    if(full){full.textContent=dc()+' '+money(Math.abs(t.full));full.classList.remove('pos','neg','neu');full.classList.add(t.full>0?'pos':t.full<0?'neg':'neu');}
    paintMovement();applyPrivacy();
  }
  var prior=window.renderLedger;
  window.renderLedger=function(){if(typeof prior==='function')prior();renderV59();};
  renderV59();
})();
