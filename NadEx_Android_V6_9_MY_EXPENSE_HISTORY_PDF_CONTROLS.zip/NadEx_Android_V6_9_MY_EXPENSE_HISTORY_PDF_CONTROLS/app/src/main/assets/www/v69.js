
/* NadEx V6.9 — My Expense transaction history + in-app Monthly Expense PDF controls */
(function(){
'use strict';
const G=id=>document.getElementById(id), num=v=>Number(v)||0, rr=v=>Math.round(num(v)*100)/100;
const fmt=v=>{try{return money(Math.abs(num(v)))}catch(e){return Math.abs(num(v)).toFixed(2)}};

/* My Expense statement is informational: every Monthly Expense allocation belonging
   to me + any direct/manual My Expense ledger rows. Balance logic remains unchanged. */
window.myExpenseParty=function(){
  const mine=me().id, rows=[];
  (M.purchases||[]).forEach(p=>{
    const a=(p.allocations||[]).find(x=>x.memberId===mine);
    if(!a || !num(a.amount)) return;
    rows.push({
      id:'mess:'+p.id, ts:p.ts||0, amount:num(a.amount),
      description:p.description||'Monthly Expense',
      meta:'Monthly Expense • Paid by '+(M.members.find(m=>m.id===p.paidBy)?.name||'Unknown'),
      source:'mess', purchaseId:p.id
    });
  });
  D.transactions.filter(t=>!t.messId && canonicalPartyKey(t)===EXPENSE_KEY).forEach(t=>{
    rows.push({
      id:'ledger:'+t.id, ts:t.ts||0,
      amount:t.kind==='add'?num(t.amount):-num(t.amount),
      description:t.description||'My Expense',
      meta:'Direct Ledger expense', source:'ledger', txId:t.id
    });
  });
  rows.sort((a,b)=>a.ts-b.ts);
  let running=0;
  rows.forEach(x=>{running=rr(running+x.amount);x.running=running});

  G('partyTitle').textContent='My Expense';
  G('partySubtitle').textContent='All expenses allocated to me';
  G('partyBalance').textContent=fmt(running);
  G('partyMeaning').textContent='Information only • Monthly Expense + direct Ledger expenses';
  G('partyIn').textContent=fmt(rows.filter(x=>x.amount>0).reduce((a,x)=>a+x.amount,0));
  G('partyOut').textContent=fmt(rows.filter(x=>x.amount<0).reduce((a,x)=>a+Math.abs(x.amount),0));
  G('partyCount').textContent=rows.length;
  G('partyTimeline').innerHTML=rows.length?rows.slice().reverse().map(x=>
    '<div class="party-tx" data-source="'+x.source+'" data-id="'+esc(x.source==='mess'?x.purchaseId:x.txId)+'">'+
      '<div><div class="pt-date">'+new Date(x.ts).toLocaleString()+'</div>'+
      '<div class="pt-desc">'+esc(x.description)+'</div><div class="pt-meta">'+esc(x.meta)+'</div></div>'+
      '<div><div class="pt-amount pos">+ '+fmt(Math.abs(x.amount))+'</div>'+
      '<div class="pt-balance">Running expense: '+fmt(x.running)+'</div>'+
      '<div class="pt-edit">'+(x.source==='mess'?'Tap to view purchase':'Tap to edit / delete')+'</div></div></div>'
  ).join(''):'<div class="empty">No My Expense transactions yet</div>';

  G('partyTimeline').querySelectorAll('[data-source]').forEach(el=>{
    el.onclick=()=>{
      if(el.dataset.source==='mess'){
        if(typeof purchaseDetails==='function') purchaseDetails(el.dataset.id);
      } else if(typeof transactionActions==='function') transactionActions(el.dataset.id);
    };
  });
  window.__partyKey=MY_EXPENSE_VIEW_KEY;
  showView('partyView');
};

/* Ensure the My Expense card opens the new combined informational history. */
function bindExpenseCard(){
  const card=document.querySelector('#expenseAccount [data-expense]');
  if(card) card.onclick=()=>myExpenseParty();
}

/* In-app detailed statement: gives explicit Save PDF and Back buttons.
   Save uses Android/browser print dialog, where the user can choose Save as PDF. */
window.exportMessPDF=function(){
  const c=activeCycle();
  const ps=(M.purchases||[]).filter(p=>!c||!p.cycleId||p.cycleId===c.id).sort((a,b)=>a.ts-b.ts);
  const z=messStats(), total=ps.reduce((a,p)=>a+num(p.amount),0);
  const summary=(M.members||[]).filter(m=>m.active||z.stats.has(m.id)).map(m=>{
    const x=z.stats.get(m.id)||{paid:0,share:0,balance:0};
    return '<tr><td>'+esc(m.name)+'</td><td>'+fmt(x.paid)+'</td><td>'+fmt(x.share)+'</td><td>'+fmt(x.balance)+'</td><td>'+(x.balance>0?'To receive':x.balance<0?'To pay':'Settled')+'</td></tr>';
  }).join('');
  const details=ps.map((p,i)=>{
    const payer=M.members.find(m=>m.id===p.paidBy)?.name||'Unknown';
    const alloc=(p.allocations||[]).map(a=>'<tr><td>'+esc(M.members.find(m=>m.id===a.memberId)?.name||'Member')+'</td><td>'+fmt(a.amount)+'</td></tr>').join('');
    return '<section class="nx-print-section"><h3>'+(i+1)+'. '+esc(p.description||'Purchase')+'</h3>'+
      '<p><b>Date/Time:</b> '+new Date(p.ts).toLocaleString()+' &nbsp; <b>Paid by:</b> '+esc(payer)+' &nbsp; <b>Total:</b> '+fmt(p.amount)+' &nbsp; <b>Split:</b> '+esc(p.splitMode||'equal')+'</p>'+
      '<table><tr><th>Member involved</th><th>Share</th></tr>'+alloc+'</table></section>';
  }).join('');

  const old=G('nxPdfPreview'); if(old) old.remove();
  const overlay=document.createElement('div');
  overlay.id='nxPdfPreview';
  overlay.innerHTML='<style>'+
    '#nxPdfPreview{position:fixed;inset:0;z-index:99999;background:#f4f6f8;color:#111;overflow:auto;font-family:Arial,sans-serif}'+
    '#nxPdfBar{position:sticky;top:0;z-index:2;display:flex;gap:10px;padding:12px;background:#101c2c;box-shadow:0 2px 8px #0004}'+
    '#nxPdfBar button{flex:1;border:0;border-radius:10px;padding:13px;font-weight:800}#nxPdfSave{background:#0d7b61;color:white}#nxPdfBack{background:white;color:#101c2c}'+
    '#nxPdfDoc{max-width:900px;margin:auto;background:white;min-height:100%;padding:28px}#nxPdfDoc table{width:100%;border-collapse:collapse;margin:8px 0 20px}#nxPdfDoc th,#nxPdfDoc td{border:1px solid #aaa;padding:7px;text-align:left}#nxPdfDoc th{background:#eee}'+
    '@media print{#nxPdfBar{display:none!important}#nxPdfPreview{position:static;overflow:visible;background:white}#nxPdfDoc{max-width:none;padding:0}.nx-print-section{break-inside:avoid}}'+
  '</style>'+
  '<div id="nxPdfBar"><button id="nxPdfBack" type="button">← BACK TO MONTHLY EXPENSE</button><button id="nxPdfSave" type="button">SAVE PDF</button></div>'+
  '<div id="nxPdfDoc"><h1>NadEx Monthly Expense Statement</h1><p>Cycle: '+esc(c?.name||'Current')+' • Generated: '+new Date().toLocaleString()+'</p>'+
  '<h2>Summary</h2><p><b>Total transactions:</b> '+ps.length+' &nbsp; <b>Total spend:</b> '+fmt(total)+'</p>'+
  '<table><tr><th>Member</th><th>Paid</th><th>Share</th><th>Net Balance</th><th>Status</th></tr>'+summary+'</table>'+
  '<h2>Complete Transaction Details</h2>'+details+'</div>';
  document.body.appendChild(overlay);
  G('nxPdfBack').onclick=()=>overlay.remove();
  G('nxPdfSave').onclick=()=>window.print();
};

function bind(){
  bindExpenseCard();
  document.querySelectorAll('#messView button').forEach(b=>{
    const t=(b.textContent||'').trim().toLowerCase();
    if(t.includes('pdf')||t.includes('statement')) b.onclick=e=>{e.preventDefault();exportMessPDF()};
  });
}
const rl=window.renderLedger;
if(typeof rl==='function') window.renderLedger=function(){const x=rl.apply(this,arguments);setTimeout(bind,0);return x};
const rm=window.renderMess;
if(typeof rm==='function') window.renderMess=function(){const x=rm.apply(this,arguments);setTimeout(bind,0);return x};
document.addEventListener('DOMContentLoaded',()=>setTimeout(bind,0));
setTimeout(bind,300);
})();
