NadEx V6.9
- My Expense balance remains as before, but its statement now lists every expense allocated to the user from Monthly Expense plus direct/manual My Expense Ledger entries.
- Monthly Expense detailed statement now opens inside the app with BACK TO MONTHLY EXPENSE and SAVE PDF controls.
- SAVE PDF opens Android/browser print handling so Save as PDF can be selected.
- V6.8 entry/purchase execution, V6.7 smart share logic, V6.3 edit/save, and V6.4 limits are preserved.
Version 6.9 / versionCode 69.
