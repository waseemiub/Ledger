
/* NadEx V6.13 — four targeted fixes only:
   1) Monthly Expense excludes personal-only purchases paid by me for me alone.
      Ledger My Expense still includes ALL of my expense allocations + direct Ledger expense rows.
   2) Reliable Purchase delete.
   3) Long-press party card to rename or hide/show it in transaction dropdowns.
   4) Dedicated Full Ledger Balance statement.
*/
(function(){
'use strict';

const E13=id=>document.getElementById(id);
const N13=v=>Number.isFinite(Number(v))?Number(v):0;
const R13=v=>Math.round(N13(v)*100)/100;
const F13=v=>{try{return money(Math.abs(N13(v)))}catch(e){return Math.abs(N13(v)).toFixed(2)}};
const saveD13=()=>localStorage.setItem(K,JSON.stringify(D));
const saveM13=()=>localStorage.setItem(MK,JSON.stringify(M));

function isPersonalOnly13(p){
  try{
    const mine=me().id;
    const a=(p.allocations||[]).filter(x=>N13(x.amount)>0.000001);
    return p.paidBy===mine && a.length===1 && a[0].memberId===mine;
  }catch(e){return false}
}
function visibleCyclePurchases13(){
  const c=activeCycle();
  return (M.purchases||[])
    .filter(p=>(!c||!p.cycleId||p.cycleId===c.id) && !isPersonalOnly13(p))
    .sort((a,b)=>(b.ts||0)-(a.ts||0));
}

/* ---------- 1. MONTHLY EXPENSE FILTER ---------- */

/* Monthly Expense calculations/list/summary now ignore only:
   Paid By = me AND Members Involved = me only.
   Records are NOT deleted. They remain available to Ledger My Expense. */
window.messStats=function(){
  const ps=visibleCyclePurchases13();
  const stats=new Map((M.members||[]).map(m=>[m.id,{member:m,paid:0,share:0,balance:0}]));
  ps.forEach(p=>{
    const payer=stats.get(p.paidBy);
    if(payer)payer.paid+=N13(p.amount);
    (p.allocations||[]).forEach(a=>{
      const x=stats.get(a.memberId);
      if(x)x.share+=N13(a.amount);
    });
  });
  stats.forEach(x=>x.balance=R13(x.paid-x.share));
  return {ps,stats,total:R13(ps.reduce((a,p)=>a+N13(p.amount),0))};
};

/* Keep CSV aligned with what Monthly Expense visibly contains. */
window.messRows=function(){
  return visibleCyclePurchases13().slice().reverse().flatMap(p=>
    (p.allocations||[]).map(a=>[
      new Date(p.ts).toLocaleDateString(),
      new Date(p.ts).toLocaleTimeString(),
      p.id,
      p.description,
      M.members.find(m=>m.id===p.paidBy)?.name||"",
      p.amount,
      M.members.find(m=>m.id===a.memberId)?.name||"",
      a.amount,
      p.splitMode
    ])
  );
};

/* Replace V6.12 PDF data source with the filtered Monthly Expense data.
   Native Android PDF bridge is preserved. */
window.exportMessPDF=function(){
  const c=activeCycle();
  const ps=visibleCyclePurchases13().slice().sort((a,b)=>(a.ts||0)-(b.ts||0));
  const z=window.messStats();
  const total=ps.reduce((a,p)=>a+N13(p.amount),0);

  const summary=(M.members||[]).filter(m=>m.active||z.stats.has(m.id)).map(m=>{
    const x=z.stats.get(m.id)||{paid:0,share:0,balance:0};
    return '<tr><td>'+esc(m.name)+'</td><td>'+F13(x.paid)+'</td><td>'+F13(x.share)+'</td><td>'+F13(x.balance)+'</td><td>'+
      (x.balance>0?'To receive':x.balance<0?'To pay':'Settled')+'</td></tr>';
  }).join('');

  const details=ps.map((p,i)=>{
    const payer=M.members.find(m=>m.id===p.paidBy)?.name||'Unknown';
    const alloc=(p.allocations||[]).map(a=>
      '<tr><td>'+esc(M.members.find(m=>m.id===a.memberId)?.name||'Member')+'</td><td>'+F13(a.amount)+'</td></tr>'
    ).join('');
    return '<section><h3>'+(i+1)+'. '+esc(p.description||'Purchase')+'</h3>'+
      '<p><b>Date/Time:</b> '+new Date(p.ts).toLocaleString()+
      ' &nbsp; <b>Paid by:</b> '+esc(payer)+
      ' &nbsp; <b>Total:</b> '+F13(p.amount)+
      ' &nbsp; <b>Split:</b> '+esc(p.splitMode||'equal')+'</p>'+
      '<table><tr><th>Member involved</th><th>Share</th></tr>'+alloc+'</table></section>';
  }).join('');

  const html='<!doctype html><html><head><meta charset="utf-8"><style>'+
    '@page{size:A4;margin:12mm}body{font-family:Arial,sans-serif;color:#111;font-size:11pt}'+
    'h1{margin:0 0 4px}h2{margin:18px 0 7px}h3{margin:12px 0 4px}'+
    'table{width:100%;border-collapse:collapse;margin:6px 0 14px}th,td{border:1px solid #888;padding:6px;text-align:left}'+
    'th{background:#eee}section{break-inside:avoid}</style></head><body>'+
    '<h1>NadEx Monthly Expense Statement</h1><p>Cycle: '+esc(c?.name||'Current')+
    ' | Generated: '+new Date().toLocaleString()+'</p>'+
    '<h2>Summary</h2><p><b>Total transactions:</b> '+ps.length+
    ' &nbsp; | &nbsp; <b>Total spend:</b> '+F13(total)+'</p>'+
    '<table><tr><th>Member</th><th>Paid</th><th>Share</th><th>Net Balance</th><th>Status</th></tr>'+summary+'</table>'+
    '<h2>Complete Transaction Details</h2>'+details+'</body></html>';

  if(window.AndroidBridge&&typeof AndroidBridge.printHtml==='function'){
    AndroidBridge.printHtml(html,'NadEx Monthly Expense');
  }else{
    alert('Android PDF service is unavailable in this installation.');
  }
};

/* ---------- 2. RELIABLE DELETE ---------- */

window.deletePurchase=function(id){
  const p=(M.purchases||[]).find(x=>x.id===id);
  if(!p)return alert('Purchase not found.');

  nxConfirm(
    'Delete Purchase?',
    (p.description||'This purchase')+' will be permanently removed.',
    'DELETE',
    ()=>{
      try{
        M.purchases=M.purchases.filter(x=>x.id!==id);
        D.transactions=D.transactions.filter(t=>{
          if(t.messId===id)return false;
          if(p.transferId && t.transferId===p.transferId)return false;
          return true;
        });
        saveM13();
        saveD13();

        const check=JSON.parse(localStorage.getItem(MK)||'{}');
        if((check.purchases||[]).some(x=>x.id===id))throw new Error('Delete verification failed.');

        close();
        renderMess();
        renderLedger();
        try{setMessTab('purchases')}catch(e){}
      }catch(err){
        console.error('V6.13 delete purchase',err);
        alert('Delete failed: '+(err.message||'Unknown error'));
      }
    }
  );
};

/* Rebind Delete buttons after each Monthly Expense render so old handlers
   cannot bypass the corrected delete function. */
function bindPurchaseDelete13(){
  document.querySelectorAll('#purchaseList [data-delp]').forEach(b=>{
    b.onclick=e=>{
      e.preventDefault();e.stopPropagation();
      window.deletePurchase(b.dataset.delp);
    };
  });
}

/* ---------- 3. SIMPLE PARTY RENAME / HIDE FROM DROPDOWN ---------- */

function hidden13(){
  if(!Array.isArray(D.hiddenParties))D.hiddenParties=[];
  return D.hiddenParties;
}
function isHidden13(k){return hidden13().includes(key(k))}
function setHidden13(k,hide){
  k=key(k);
  D.hiddenParties=hidden13().filter(x=>x!==k);
  if(hide)D.hiddenParties.push(k);
  saveD13();
}
function filterDropdowns13(){
  const hidden=new Set(hidden13());

  /* Main legacy datalist */
  const p=E13('parties');
  if(p)[...p.options].forEach(o=>{
    const s=states().find(x=>x.name===o.value);
    if(s && hidden.has(s.key))o.remove();
  });

  /* Universal +Entry datalist */
  const nx=E13('nxAccounts');
  if(nx)[...nx.options].forEach(o=>{
    const s=states().find(x=>x.name===o.value);
    if(s && hidden.has(s.key))o.remove();
  });

  /* Transfer datalist if opened */
  const tr=E13('transferParties');
  if(tr)[...tr.options].forEach(o=>{
    const s=states().find(x=>x.name===o.value);
    if(s && hidden.has(s.key))o.remove();
  });
}

function manageParty13(k){
  k=key(k);
  const s=states().find(x=>x.key===k);
  if(!s||s.wallet||k===EXPENSE_KEY)return;
  const hide=isHidden13(k);

  modal('Manage Party',
    '<div class="field"><label>Party Name</label><input id="v613PartyName" value="'+esc(s.name)+'"></div>'+
    '<div class="note">Rename updates this party throughout its existing Ledger history. Hide only removes it from transaction dropdowns; the account and history remain unchanged.</div>'+
    '<div class="opts two">'+
      '<button type="button" id="v613Rename" class="primary">SAVE NAME</button>'+
      '<button type="button" id="v613Hide">'+(hide?'SHOW IN DROPDOWN':'HIDE FROM DROPDOWN')+'</button>'+
    '</div>'
  );

  E13('v613Rename').onclick=()=>{
    const newName=String(E13('v613PartyName').value||'').trim().replace(/\s+/g,' ');
    if(!newName)return alert('Enter a party name.');
    const nk=key(newName);
    if(isWalletKey(nk)||nk===EXPENSE_KEY)return alert('Choose a different party name.');
    const collision=states().find(x=>x.key===nk&&x.key!==k);
    if(collision)return alert('A party with this name already exists.');

    D.transactions.forEach(t=>{
      if(canonicalPartyKey(t)===k){
        t.partyKey=nk;
        t.party=newName;
      }
    });

    if(D.partyLimits&&Object.prototype.hasOwnProperty.call(D.partyLimits,k)){
      D.partyLimits[nk]=D.partyLimits[k];
      delete D.partyLimits[k];
    }
    if(isHidden13(k)){
      D.hiddenParties=hidden13().filter(x=>x!==k);
      D.hiddenParties.push(nk);
    }

    saveD13();
    close();
    renderLedger();
  };

  E13('v613Hide').onclick=()=>{
    setHidden13(k,!hide);
    close();
    renderLedger();
  };
}

function bindPartyManage13(){
  ['payments','receivables'].forEach(id=>{
    const box=E13(id); if(!box)return;
    box.querySelectorAll('.row[data-k],.account-overview-card[data-k]').forEach(card=>{
      const k=card.dataset.k;
      if(!k||k===EXPENSE_KEY||isWalletKey(k)||card.dataset.v613Manage==='1')return;
      card.dataset.v613Manage='1';

      let timer=null,longDone=false;
      const start=()=>{
        longDone=false;
        timer=setTimeout(()=>{
          longDone=true;
          manageParty13(k);
        },650);
      };
      const cancel=()=>{if(timer){clearTimeout(timer);timer=null}};
      card.addEventListener('touchstart',start,{passive:true});
      card.addEventListener('touchend',cancel,{passive:true});
      card.addEventListener('touchcancel',cancel,{passive:true});
      card.addEventListener('mousedown',start);
      card.addEventListener('mouseup',cancel);
      card.addEventListener('mouseleave',cancel);
      card.addEventListener('click',e=>{
        if(longDone){e.preventDefault();e.stopImmediatePropagation();longDone=false}
      },true);
      card.addEventListener('contextmenu',e=>{
        e.preventDefault();e.stopPropagation();cancel();manageParty13(k);
      });
    });
  });
}

/* Universal entry is preserved; only hidden parties are removed after it opens. */
const baseEntry13=window.ledgerEntry;
if(typeof baseEntry13==='function'){
  window.ledgerEntry=function(){
    const v=baseEntry13.apply(this,arguments);
    filterDropdowns13();
    return v;
  };
}

/* ---------- 4. FULL LEDGER BALANCE STATEMENT ---------- */

function currentMainBalance13(){
  try{
    const s=states();
    const wallets=s.filter(x=>x.wallet).reduce((a,x)=>a+N13(x.balance),0);
    const parties=s.filter(x=>!x.wallet&&x.key!==EXPENSE_KEY).reduce((a,x)=>a+N13(x.balance),0);
    const ms=messStats(), mine=ms.stats.get(me().id);
    return R13(wallets+parties+N13(mine&&mine.balance));
  }catch(e){return 0}
}

window.openMainBalanceStatement=function(){
  const rows=(D.transactions||[]).filter(t=>!t.messId).slice().sort((a,b)=>(a.ts||0)-(b.ts||0));
  let running=0;
  const data=rows.map(t=>{
    const d=t.kind==='add'?N13(t.amount):-N13(t.amount);
    running=R13(running+d);
    return {t,d,running};
  });

  modal('Main Ledger Balance Statement',
    '<div class="balance-card"><small>CURRENT MAIN LEDGER BALANCE</small><strong>'+F13(currentMainBalance13())+'</strong>'+
    '<span>'+data.length+' Ledger entries</span></div>'+
    '<div class="note">This statement shows every Ledger entry in date/time order. Linked internal movements may appear on both sides, exactly as recorded in the party/account statements.</div>'+
    '<div class="party-timeline">'+
      (data.length?data.slice().reverse().map(x=>
        '<div class="party-tx"><div>'+
          '<div class="pt-date">'+new Date(x.t.ts).toLocaleString()+'</div>'+
          '<div class="pt-desc">'+esc(x.t.description||'Transaction')+'</div>'+
          '<div class="pt-meta">'+esc(x.t.party||'Account')+(x.t.movementId?' • Linked movement':'')+'</div>'+
        '</div><div>'+
          '<div class="pt-amount '+(x.d>=0?'pos':'neg')+'">'+(x.d>=0?'+ ':'− ')+F13(Math.abs(x.d))+'</div>'+
          '<div class="pt-balance">Running entries: '+F13(x.running)+'</div>'+
        '</div></div>'
      ).join(''):'<div class="empty">No Ledger transactions</div>')+
    '</div>'
  );
};

function ensureMainStatementButton13(){
  const panel=E13('ledgerPositionV59'); if(!panel)return;
  let b=E13('v613MainStatement');
  if(!b){
    b=document.createElement('button');
    b.id='v613MainStatement';
    b.type='button';
    b.textContent='Statement';
    b.style.cssText='margin-top:12px;width:100%;padding:11px 14px;border-radius:12px;border:1px solid rgba(148,163,184,.25);background:rgba(15,35,50,.75);color:inherit;font-weight:700;';
    panel.appendChild(b);
  }
  b.onclick=e=>{e.preventDefault();e.stopPropagation();window.openMainBalanceStatement()};
  const full=E13('ledgerFullBalanceV59');
  if(full){
    full.style.cursor='pointer';
    full.onclick=e=>{e.preventDefault();e.stopPropagation();window.openMainBalanceStatement()};
  }
}

/* Existing Overview "Statement" remains available, but its first action now
   directly opens the Main Ledger Balance statement. */
function bindOverviewStatement13(){
  const b=E13('download');
  if(b)b.onclick=e=>{e.preventDefault();window.openMainBalanceStatement()};
}

function bindAll13(){
  bindPurchaseDelete13();
  bindPartyManage13();
  filterDropdowns13();
  ensureMainStatementButton13();
  bindOverviewStatement13();
}

/* Wrap only render functions; no accounting mutation. */
const baseLedger13=window.renderLedger;
if(typeof baseLedger13==='function'){
  window.renderLedger=function(){
    const v=baseLedger13.apply(this,arguments);
    setTimeout(bindAll13,0);
    return v;
  };
}
const baseMess13=window.renderMess;
if(typeof baseMess13==='function'){
  window.renderMess=function(){
    const v=baseMess13.apply(this,arguments);
    setTimeout(bindAll13,0);
    return v;
  };
}

document.addEventListener('DOMContentLoaded',()=>setTimeout(bindAll13,50));
setTimeout(bindAll13,350);
})();
