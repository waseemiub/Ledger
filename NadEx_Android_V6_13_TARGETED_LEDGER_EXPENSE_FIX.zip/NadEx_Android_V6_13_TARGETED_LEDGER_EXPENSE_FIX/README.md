NadEx V6.13 — Targeted update from V6.12
VersionCode 73 / VersionName 6.13

Only requested changes:
1. Monthly Expense excludes purchases where the user paid and the user is the only involved member.
   The records are not deleted. Ledger My Expense still includes all of the user's expense allocations,
   including those excluded from Monthly Expense, plus direct Ledger My Expense entries.
2. Purchase Delete rebuilt with in-app confirmation, persistence, and storage verification.
3. Long-press a non-wallet party card to Manage Party:
   - rename the party throughout Ledger history
   - hide/show the party in transaction dropdowns
   Hiding does not delete the party or its history.
4. Full Ledger Balance has a dedicated Statement button and statement view.

Everything else remains based on V6.12.
