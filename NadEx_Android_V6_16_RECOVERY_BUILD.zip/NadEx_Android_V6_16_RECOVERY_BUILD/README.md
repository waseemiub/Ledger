NadEx V6.11
Exact fixes based on V6.10 screenshots:
- Outer 04 My Expense TOTAL is forcibly synchronized to the same authoritative allocated expense total as the inner card.
- Inner transaction count/history remains.
- Monthly Expense no longer opens the intermediate HTML statement screen.
- PDF button builds the same full detailed report in a hidden print frame and directly invokes Android native Print / Save as PDF.
- Full member summary and every purchase/share detail remain.
Version 6.11 / versionCode 71.
