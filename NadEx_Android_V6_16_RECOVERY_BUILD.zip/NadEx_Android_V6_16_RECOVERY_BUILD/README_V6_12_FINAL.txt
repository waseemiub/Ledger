NadEx V6.12 FINAL
VersionCode 72.

Final targeted fixes from the user's V6.11 source package:
1. My Expense outer section TOTAL and inner card now use the same authoritative snapshot.
2. Current-cycle Monthly Expense allocations plus direct manual My Expense Ledger entries feed that snapshot.
3. Monthly Expense PDF no longer uses window.print(), popup windows, or hidden iframes.
4. PDF uses the app's existing AndroidBridge.printHtml() -> Android PrintManager implementation in MainActivity.kt.
5. Detailed statement retains total transactions, total spend, each member Paid/Share/Net/Status, and every transaction with payer, date/time, split method, involved members and individual shares.
6. V6.10/V6.11 experimental print scripts are no longer loaded; V6.12 is the final override.
