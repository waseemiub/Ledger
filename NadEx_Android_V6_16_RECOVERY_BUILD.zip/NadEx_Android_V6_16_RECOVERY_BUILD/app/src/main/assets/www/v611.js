
/* NadEx V6.11 — exact visible header repair + working Android PDF action */
(function(){
'use strict';
const n=v=>Number(v)||0, r=v=>Math.round(n(v)*100)/100;
const f=v=>{try{return money(Math.abs(n(v)))}catch(e){return Math.abs(n(v)).toFixed(2)}};

function exactExpenseTotal(){
 let total=0;
 try{
   const mine=me().id,c=activeCycle();
   (M.purchases||[]).filter(p=>!c||!p.cycleId||p.cycleId===c.id)
    .forEach(p=>total+=n((p.allocations||[]).find(a=>a.memberId===mine)?.amount));
 }catch(e){}
 try{
   total+=(D.transactions||[]).filter(t=>!t.messId&&canonicalPartyKey(t)===EXPENSE_KEY)
    .reduce((a,t)=>a+(t.kind==='add'?n(t.amount):-n(t.amount)),0);
 }catch(e){}
 return Math.max(0,r(total));
}

function forceVisibleExpenseHeader(){
 const root=document.getElementById('expenseAccount'); if(!root)return;
 const value=f(exactExpenseTotal());

 /* Find the OUTER TOTAL label by text, explicitly excluding the inner [data-expense] card.
    Then replace the visible numeric sibling/descendant. */
 const all=[...root.querySelectorAll('*')];
 const label=all.find(el=>{
   if(el.closest('[data-expense]'))return false;
   return el.children.length===0 && (el.textContent||'').trim().toUpperCase()==='TOTAL';
 });
 if(label){
   let box=label.parentElement;
   for(let depth=0;box && depth<3;depth++,box=box.parentElement){
     const nums=[...box.querySelectorAll('*')].filter(el=>{
       if(el.closest('[data-expense]'))return false;
       if(el===label||el.children.length)return false;
       const t=(el.textContent||'').trim();
       return /(?:AED\s*)?[\d,.]+/i.test(t) && t.toUpperCase()!=='TOTAL';
     });
     if(nums.length){ nums[0].textContent=value; break; }
   }
 }

 /* Hard fallback targeted to the outer section only. */
 all.filter(el=>!el.closest('[data-expense]')&&el.children.length===0).forEach(el=>{
   const t=(el.textContent||'').trim();
   if(/^(?:AED\s*)?0(?:[,.]00)?$/i.test(t))el.textContent=value;
 });
}

/* Do NOT open another HTML preview. The screenshot proves that preview is the problem.
   Generate a print-only iframe from the detailed statement and call the native print
   action directly. This immediately opens Android's Print / Save as PDF destination. */
window.exportMessPDF=function(){
 const c=activeCycle();
 const ps=(M.purchases||[]).filter(p=>!c||!p.cycleId||p.cycleId===c.id).sort((a,b)=>a.ts-b.ts);
 const z=messStats(),total=ps.reduce((a,p)=>a+n(p.amount),0);
 const summary=(M.members||[]).filter(m=>m.active||z.stats.has(m.id)).map(m=>{
   const x=z.stats.get(m.id)||{paid:0,share:0,balance:0};
   return '<tr><td>'+esc(m.name)+'</td><td>'+f(x.paid)+'</td><td>'+f(x.share)+'</td><td>'+f(x.balance)+'</td><td>'+(x.balance>0?'To receive':x.balance<0?'To pay':'Settled')+'</td></tr>';
 }).join('');
 const detail=ps.map((p,i)=>{
   const payer=M.members.find(m=>m.id===p.paidBy)?.name||'Unknown';
   const shares=(p.allocations||[]).map(a=>'<tr><td>'+esc(M.members.find(m=>m.id===a.memberId)?.name||'Member')+'</td><td>'+f(a.amount)+'</td></tr>').join('');
   return '<section><h3>'+(i+1)+'. '+esc(p.description||'Purchase')+'</h3>'+
    '<p><b>Date/Time:</b> '+new Date(p.ts).toLocaleString()+' &nbsp; <b>Paid by:</b> '+esc(payer)+' &nbsp; <b>Total:</b> '+f(p.amount)+' &nbsp; <b>Split:</b> '+esc(p.splitMode||'equal')+'</p>'+
    '<table><tr><th>Member involved</th><th>Share</th></tr>'+shares+'</table></section>';
 }).join('');
 const doc='<!doctype html><html><head><meta charset="utf-8"><style>@page{size:A4;margin:12mm}body{font-family:Arial,sans-serif;color:#111;font-size:11pt}h1{margin:0 0 4px}h2{margin:18px 0 7px}h3{margin:12px 0 4px}table{width:100%;border-collapse:collapse;margin:6px 0 14px}th,td{border:1px solid #888;padding:6px;text-align:left}th{background:#eee}section{break-inside:avoid}</style></head><body>'+
  '<h1>NadEx Monthly Expense Statement</h1><p>Cycle: '+esc(c?.name||'Current')+' | Generated: '+new Date().toLocaleString()+'</p>'+
  '<h2>Summary</h2><p><b>Total transactions:</b> '+ps.length+' &nbsp; | &nbsp; <b>Total spend:</b> '+f(total)+'</p>'+
  '<table><tr><th>Member</th><th>Paid</th><th>Share</th><th>Net Balance</th><th>Status</th></tr>'+summary+'</table>'+
  '<h2>Complete Transaction Details</h2>'+detail+'</body></html>';

 let frame=document.getElementById('nxPrintFrame');
 if(frame)frame.remove();
 frame=document.createElement('iframe');
 frame.id='nxPrintFrame';frame.style.position='fixed';frame.style.right='0';frame.style.bottom='0';frame.style.width='1px';frame.style.height='1px';frame.style.border='0';frame.style.opacity='0';
 document.body.appendChild(frame);
 const d=frame.contentDocument||frame.contentWindow.document;
 d.open();d.write(doc);d.close();
 setTimeout(()=>{
   try{
     frame.contentWindow.focus();
     frame.contentWindow.print();
   }catch(e){
     alert('Unable to open Android print service.');
   }
 },350);
};

function bind611(){
 forceVisibleExpenseHeader();
 document.querySelectorAll('#messView button').forEach(b=>{
   const t=(b.textContent||'').trim().toLowerCase();
   if(t.includes('pdf')||t.includes('statement')){
     b.onclick=e=>{e.preventDefault();e.stopPropagation();exportMessPDF()};
   }
 });
}
const rl=window.renderLedger;
if(typeof rl==='function')window.renderLedger=function(){const x=rl.apply(this,arguments);setTimeout(bind611,0);return x};
const rm=window.renderMess;
if(typeof rm==='function')window.renderMess=function(){const x=rm.apply(this,arguments);setTimeout(bind611,0);return x};
document.addEventListener('DOMContentLoaded',()=>setTimeout(bind611,20));
setTimeout(bind611,300);
})();
