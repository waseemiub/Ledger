
/* NadEx V6.16 recovery integration — original V6.12 UI preserved. */
(function(){
'use strict';
const E=id=>document.getElementById(id);
const persist=()=>localStorage.setItem(K,JSON.stringify(D));

/* A. Monthly Expense personal-only exclusion.
   Original renderer/PDF execute unchanged against a temporary filtered array.
   The full array is restored immediately, so Ledger My Expense keeps all records. */
function personalOnly(p){
  let id;try{id=me().id}catch(e){return false}
  if(!p||String(p.paidBy)!==String(id))return false;
  const a=(p.allocations||[]).filter(x=>Number(x.amount)>0.000001);
  return a.length===1&&String(a[0].memberId)===String(id);
}
function filteredCall(fn,ctx,args){
  const all=M.purchases;
  M.purchases=(all||[]).filter(p=>!personalOnly(p));
  try{return fn.apply(ctx,args||[])}finally{M.purchases=all}
}
const originalMess=window.renderMess;
window.renderMess=function(){return filteredCall(originalMess,this,arguments)};
if(typeof window.exportMessPDF==='function'){
  const originalPdf=window.exportMessPDF;
  window.exportMessPDF=function(){return filteredCall(originalPdf,this,arguments)};
}

/* B. Party management on the EXISTING party statement.
   No page/layout replacement. One button is appended to its existing action row. */
function hidden(){
  if(!Array.isArray(D.hiddenParties))D.hiddenParties=[];
  return D.hiddenParties;
}
function isHidden(k){return hidden().includes(key(k))}
function manageParty(k){
  k=key(k);
  const p=states().find(x=>x.key===k);
  if(!p||p.wallet||k===EXPENSE_KEY)return;
  const h=isHidden(k);
  modal('Edit / Remove Party',
    '<div class="field"><label>Party Name</label><input id="v616PartyName" value="'+esc(p.name)+'"></div>'+
    '<div class="note">Remove from dropdown keeps the existing balance and transaction history.</div>'+
    '<div class="opts two"><button id="v616Rename" class="primary">SAVE NAME</button>'+
    '<button id="v616Remove">'+(h?'RESTORE TO DROPDOWN':'REMOVE PARTY')+'</button></div>');

  E('v616Rename').onclick=()=>{
    const name=String(E('v616PartyName').value||'').trim().replace(/\s+/g,' ');
    if(!name)return alert('Enter a party name.');
    const nk=key(name);
    if(isWalletKey(nk)||nk===EXPENSE_KEY)return alert('Choose a different party name.');
    if(states().some(x=>x.key===nk&&x.key!==k))return alert('A party with this name already exists.');
    D.transactions.forEach(t=>{
      if(canonicalPartyKey(t)===k){t.partyKey=nk;t.party=name}
    });
    if(D.partyLimits&&Object.prototype.hasOwnProperty.call(D.partyLimits,k)){
      D.partyLimits[nk]=D.partyLimits[k];delete D.partyLimits[k];
    }
    if(isHidden(k)){
      D.hiddenParties=hidden().filter(x=>x!==k);
      D.hiddenParties.push(nk);
    }
    persist();close();renderLedger();party(nk);
  };
  E('v616Remove').onclick=()=>{
    D.hiddenParties=hidden().filter(x=>x!==k);
    if(!h)D.hiddenParties.push(k);
    persist();close();renderLedger();party(k);
  };
}
function bindManage(k){
  const p=states().find(x=>x.key===key(k));
  const row=document.querySelector('#partyView .statement-actions');
  if(!row)return;
  let b=E('v616ManageParty');if(b)b.remove();
  if(!p||p.wallet||p.key===EXPENSE_KEY)return;
  b=document.createElement('button');
  b.id='v616ManageParty';b.type='button';b.textContent='Edit / Remove Party';
  b.onclick=e=>{e.preventDefault();e.stopPropagation();manageParty(k)};
  row.appendChild(b);
}

/* Filter only the options in the already-existing New Transaction datalists.
   The transaction modal itself is untouched. */
function filterLists(){
  const h=new Set(hidden());
  ['parties','nxAccounts','transferParties'].forEach(id=>{
    const dl=E(id);if(!dl)return;
    dl.querySelectorAll('option').forEach(o=>{if(h.has(key(o.value||'')))o.remove()});
  });
}
const entry0=window.ledgerEntry;
window.ledgerEntry=function(){
  const r=entry0.apply(this,arguments);
  setTimeout(filterLists,0);
  return r;
};

/* Wrap final party only to add the one management button.
   Transaction row click itself was fixed directly in original app.js to call
   window.transactionActions, which is the proven V6.3 controller. */
const party0=window.party;
window.party=function(k){
  const r=party0.apply(this,arguments);
  setTimeout(()=>bindManage(k),0);
  return r;
};

/* C. Main Balance Statement.
   v67 already contains the working statement generator.
   The previous problem was binding to non-existent IDs.
   Bind it to the ACTUAL V5.9 balance ID: ledgerFullBalanceV59. */
function bindMain(){
  const bal=E('ledgerFullBalanceV59');
  if(bal){
    bal.style.cursor='pointer';
    bal.onclick=e=>{
      e.preventDefault();e.stopPropagation();
      if(typeof window.openMainBalanceStatement==='function')window.openMainBalanceStatement();
    };
  }
  const panel=E('ledgerPositionV59');
  if(panel&&!E('v616MainStatement')){
    const b=document.createElement('button');
    b.id='v616MainStatement';b.type='button';b.textContent='Statement';
    b.onclick=e=>{
      e.preventDefault();e.stopPropagation();
      if(typeof window.openMainBalanceStatement==='function')window.openMainBalanceStatement();
    };
    panel.appendChild(b);
  }
}
const ledger0=window.renderLedger;
window.renderLedger=function(){
  const r=ledger0.apply(this,arguments);
  setTimeout(bindMain,0);
  return r;
};
document.addEventListener('DOMContentLoaded',()=>setTimeout(bindMain,50));
setTimeout(bindMain,300);
})();
