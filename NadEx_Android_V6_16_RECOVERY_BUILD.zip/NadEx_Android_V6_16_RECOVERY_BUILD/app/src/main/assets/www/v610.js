
/* NadEx V6.10 — outer My Expense total sync + classic printable Monthly Expense statement */
(function(){
'use strict';
const Q=(s,r=document)=>r.querySelector(s), QA=(s,r=document)=>[...r.querySelectorAll(s)];
const NN=v=>Number(v)||0, RR=v=>Math.round(NN(v)*100)/100;
const FM=v=>{try{return money(Math.abs(NN(v)))}catch(e){return Math.abs(NN(v)).toFixed(2)}};

function expenseTotal610(){
 let monthly=0;
 try{
   const c=activeCycle(), mine=me().id;
   (M.purchases||[]).filter(p=>!c||!p.cycleId||p.cycleId===c.id).forEach(p=>{
     monthly+=NN((p.allocations||[]).find(a=>a.memberId===mine)?.amount);
   });
 }catch(e){}
 let manual=0;
 try{
   manual=(D.transactions||[]).filter(t=>!t.messId&&canonicalPartyKey(t)===EXPENSE_KEY)
     .reduce((a,t)=>a+(t.kind==='add'?NN(t.amount):-NN(t.amount)),0);
 }catch(e){}
 return Math.max(0,RR(monthly+manual));
}

/* Fix BOTH numbers visible in user's screenshot:
   outer "04 My Expense TOTAL" and inner My Expense card. */
function syncExpenseDisplay(){
 const total=expenseTotal610(), text=FM(total);
 const section=document.getElementById('expenseAccount');
 if(!section)return;

 /* inner card */
 const card=section.querySelector('[data-expense]');
 if(card){
   const big=card.querySelector('.account-overview-top > b');
   if(big)big.textContent=text;
   const stat=card.querySelector('.account-overview-stats span:first-child b');
   if(stat)stat.textContent=text;
   const entries=card.querySelector('.account-overview-stats span:nth-child(2) b');
   if(entries){
     let count=0;
     try{
       const mine=me().id,c=activeCycle();
       count+=(M.purchases||[]).filter(p=>(!c||!p.cycleId||p.cycleId===c.id)&&NN((p.allocations||[]).find(a=>a.memberId===mine)?.amount)>0).length;
       count+=(D.transactions||[]).filter(t=>!t.messId&&canonicalPartyKey(t)===EXPENSE_KEY).length;
     }catch(e){}
     entries.textContent=String(count);
   }
 }

 /* outer header: locate the TOTAL label then its amount, without touching inner card */
 const header=[...section.children].find(el=>el.querySelector&&/My Expense/i.test(el.textContent||'')&&/TOTAL/i.test(el.textContent||''));
 if(header){
   const totalLabel=QA('*',header).find(el=>(el.textContent||'').trim().toUpperCase()==='TOTAL');
   if(totalLabel){
     const parent=totalLabel.parentElement;
     const candidates=parent?QA('b,strong,span,div',parent):[];
     const amount=candidates.find(el=>el!==totalLabel && /[0-9]/.test(el.textContent||'') && !/TOTAL/i.test(el.textContent||''));
     if(amount) amount.textContent=text;
   }
 }

 /* fallback: direct text nodes/elements containing exactly the stale formatted zero */
 QA('*',section).forEach(el=>{
   if(el.closest('[data-expense]'))return;
   const t=(el.textContent||'').trim();
   if(/^(AED\s*)?0([,.]00)?$/i.test(t) && el.children.length===0) el.textContent=text;
 });
}

/* Restore the previous statement style:
   a clean printable document opens, browser/Android print handles Print or Save as PDF.
   No custom full-screen overlay that traps navigation. */
window.exportMessPDF=function(){
 const c=activeCycle();
 const ps=(M.purchases||[]).filter(p=>!c||!p.cycleId||p.cycleId===c.id).sort((a,b)=>a.ts-b.ts);
 const z=messStats(), total=ps.reduce((a,p)=>a+NN(p.amount),0);
 const members=(M.members||[]).filter(m=>m.active||z.stats.has(m.id));
 const summary=members.map(m=>{
   const x=z.stats.get(m.id)||{paid:0,share:0,balance:0};
   return '<tr><td>'+esc(m.name)+'</td><td>'+FM(x.paid)+'</td><td>'+FM(x.share)+'</td><td>'+FM(x.balance)+'</td><td>'+(x.balance>0?'To receive':x.balance<0?'To pay':'Settled')+'</td></tr>';
 }).join('');
 const detail=ps.map((p,i)=>{
   const payer=M.members.find(m=>m.id===p.paidBy)?.name||'Unknown';
   const alloc=(p.allocations||[]).map(a=>{
     const nm=M.members.find(m=>m.id===a.memberId)?.name||'Member';
     return '<tr><td>'+esc(nm)+'</td><td>'+FM(a.amount)+'</td></tr>';
   }).join('');
   return '<section><h3>'+(i+1)+'. '+esc(p.description||'Purchase')+'</h3>'+
     '<div class="meta"><b>Date/Time:</b> '+new Date(p.ts).toLocaleString()+
     ' &nbsp; <b>Paid by:</b> '+esc(payer)+
     ' &nbsp; <b>Total:</b> '+FM(p.amount)+
     ' &nbsp; <b>Split:</b> '+esc(p.splitMode||'equal')+'</div>'+
     '<table><thead><tr><th>Member involved</th><th>Share</th></tr></thead><tbody>'+alloc+'</tbody></table></section>';
 }).join('');

 const doc='<!doctype html><html><head><meta charset="utf-8"><title>NadEx Monthly Expense Statement</title>'+
 '<style>@page{size:A4;margin:12mm}body{font-family:Arial,sans-serif;color:#111;margin:0;padding:18px}h1{margin:0 0 4px}h2{margin:22px 0 8px}h3{margin:14px 0 5px}table{width:100%;border-collapse:collapse;margin:7px 0 15px}th,td{border:1px solid #999;padding:7px;text-align:left;font-size:12px}th{background:#eee}.meta{font-size:12px;line-height:1.6}.toolbar{position:sticky;top:0;display:flex;gap:10px;background:#fff;padding:10px 0;border-bottom:1px solid #ddd;margin-bottom:15px}.toolbar button{padding:10px 16px;border:1px solid #777;border-radius:8px;background:#fff;font-weight:bold}.toolbar .save{background:#0d7b61;color:#fff;border-color:#0d7b61}section{break-inside:avoid}@media print{.toolbar{display:none}body{padding:0}}</style></head><body>'+
 '<div class="toolbar"><button onclick="window.close()">← Back</button><button class="save" onclick="window.print()">Print / Save PDF</button></div>'+
 '<h1>NadEx Monthly Expense Statement</h1><div>Cycle: '+esc(c?.name||'Current')+' &nbsp; | &nbsp; Generated: '+new Date().toLocaleString()+'</div>'+
 '<h2>Summary</h2><div><b>Total transactions:</b> '+ps.length+' &nbsp; | &nbsp; <b>Total spend:</b> '+FM(total)+'</div>'+
 '<table><thead><tr><th>Member</th><th>Paid</th><th>Share</th><th>Net Balance</th><th>Status</th></tr></thead><tbody>'+summary+'</tbody></table>'+
 '<h2>Complete Transaction Details</h2>'+detail+
 '<script>setTimeout(function(){window.print()},350);<\/script></body></html>';

 const w=window.open('','_blank');
 if(!w){alert('Statement window could not open.');return}
 w.document.open();w.document.write(doc);w.document.close();
};

/* Remove V6.9 overlay if one was left open. */
const stale=document.getElementById('nxPdfPreview');if(stale)stale.remove();

function bind610(){
 syncExpenseDisplay();
 document.querySelectorAll('#messView button').forEach(b=>{
   const t=(b.textContent||'').trim().toLowerCase();
   if(t.includes('pdf')||t.includes('statement')){
     b.onclick=e=>{e.preventDefault();e.stopPropagation();exportMessPDF()};
   }
 });
}
const rl=window.renderLedger;
if(typeof rl==='function')window.renderLedger=function(){const x=rl.apply(this,arguments);setTimeout(bind610,0);return x};
const rm=window.renderMess;
if(typeof rm==='function')window.renderMess=function(){const x=rm.apply(this,arguments);setTimeout(bind610,0);return x};
document.addEventListener('DOMContentLoaded',()=>setTimeout(bind610,30));
setTimeout(bind610,350);
})();
