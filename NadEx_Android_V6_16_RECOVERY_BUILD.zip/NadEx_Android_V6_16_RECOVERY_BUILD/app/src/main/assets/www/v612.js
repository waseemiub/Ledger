/* NadEx V6.12 FINAL — authoritative My Expense header + Android native PDF */
(function(){
'use strict';
const $12=id=>document.getElementById(id), n12=v=>Number(v)||0, r12=v=>Math.round(n12(v)*100)/100;
const f12=v=>{try{return money(Math.abs(n12(v)))}catch(e){return Math.abs(n12(v)).toFixed(2)}};

/* One source of truth for My Expense: current-cycle share allocations + direct manual expense rows. */
function expenseSnapshot12(){
  let items=[], total=0, mine=null, cycle=null;
  try{mine=me().id;cycle=activeCycle()}catch(e){}
  try{
    (M.purchases||[]).filter(p=>!cycle||!p.cycleId||p.cycleId===cycle.id).forEach(p=>{
      const a=(p.allocations||[]).find(x=>x.memberId===mine), amount=n12(a&&a.amount);
      if(amount>0){items.push({source:'mess',id:p.id,ts:p.ts||0,description:p.description||'Monthly Expense',myAmount:amount,amount:n12(p.amount),paidBy:p.paidBy});total+=amount}
    });
  }catch(e){}
  try{
    (D.transactions||[]).filter(t=>!t.messId&&canonicalPartyKey(t)===EXPENSE_KEY).forEach(t=>{
      const delta=t.kind==='add'?n12(t.amount):-n12(t.amount);
      if(delta!==0){items.push({source:'ledger',id:t.id,ts:t.ts||0,description:t.description||'My Expense',myAmount:delta,amount:n12(t.amount),party:t.party||''});total+=delta}
    });
  }catch(e){}
  items.sort((a,b)=>a.ts-b.ts);
  return {total:Math.max(0,r12(total)),items,cycle};
}

/* Fix the actual source-rendered fold header, not a post-render zero search. */
function renderExpenseHeader12(){
  const x=expenseSnapshot12();
  const h=document.querySelector('.group.expense .fold-head');
  if(!h)return;
  const arrow=h.querySelector('.fold-arrow')?.textContent||'⌄';
  h.innerHTML='<span>04</span><span class="section-name">My Expense</span><span class="section-total"><small>TOTAL</small>'+f12(x.total)+'</span><i class="fold-arrow">'+arrow+'</i>';
  h.setAttribute('role','button');h.setAttribute('tabindex','0');
  h.onclick=()=>h.parentElement.classList.toggle('collapsed');
  h.onkeydown=e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();h.click()}};

  const card=$12('expenseAccount')?.querySelector('[data-expense]');
  if(card){
    const a=card.querySelector('.account-overview-top > b'); if(a)a.textContent=f12(x.total);
    const b=card.querySelector('.account-overview-stats span:first-child b'); if(b)b.textContent=f12(x.total);
    const c=card.querySelector('.account-overview-stats span:nth-child(2) b'); if(c)c.textContent=String(x.items.length);
    const last=x.items.length?x.items[x.items.length-1].ts:0;
    const d=card.querySelector('.account-overview-stats span:nth-child(3) b'); if(d)d.textContent=last?new Date(last).toLocaleDateString():'—';
  }
}

/* Wrap the real Ledger renderer once; header and inner card are always synchronized. */
const baseRender12=window.renderLedger;
if(typeof baseRender12==='function')window.renderLedger=function(){const v=baseRender12.apply(this,arguments);renderExpenseHeader12();return v};

/* Full detailed Monthly Expense report, sent to the EXISTING Android native PrintManager bridge.
   No window.print, iframe, popup, or HTML preview. */
window.exportMessPDF=function(){
  const c=activeCycle();
  const ps=(M.purchases||[]).filter(p=>!c||!p.cycleId||p.cycleId===c.id).sort((a,b)=>a.ts-b.ts);
  const z=messStats(), total=ps.reduce((a,p)=>a+n12(p.amount),0);
  const summary=(M.members||[]).filter(m=>m.active||z.stats.has(m.id)).map(m=>{
    const x=z.stats.get(m.id)||{paid:0,share:0,balance:0};
    return '<tr><td>'+esc(m.name)+'</td><td>'+f12(x.paid)+'</td><td>'+f12(x.share)+'</td><td>'+f12(x.balance)+'</td><td>'+(x.balance>0?'To receive':x.balance<0?'To pay':'Settled')+'</td></tr>';
  }).join('');
  const details=ps.map((p,i)=>{
    const payer=M.members.find(m=>m.id===p.paidBy)?.name||'Unknown';
    const alloc=(p.allocations||[]).map(a=>'<tr><td>'+esc(M.members.find(m=>m.id===a.memberId)?.name||'Member')+'</td><td>'+f12(a.amount)+'</td></tr>').join('');
    return '<section><h3>'+(i+1)+'. '+esc(p.description||'Purchase')+'</h3><p><b>Date/Time:</b> '+new Date(p.ts).toLocaleString()+' &nbsp; <b>Paid by:</b> '+esc(payer)+' &nbsp; <b>Total:</b> '+f12(p.amount)+' &nbsp; <b>Split:</b> '+esc(p.splitMode||'equal')+'</p><table><tr><th>Member involved</th><th>Share</th></tr>'+alloc+'</table></section>';
  }).join('');
  const html='<!doctype html><html><head><meta charset="utf-8"><style>@page{size:A4;margin:12mm}body{font-family:Arial,sans-serif;color:#111;font-size:11pt}h1{margin:0 0 4px}h2{margin:18px 0 7px}h3{margin:12px 0 4px}table{width:100%;border-collapse:collapse;margin:6px 0 14px}th,td{border:1px solid #888;padding:6px;text-align:left}th{background:#eee}section{break-inside:avoid}</style></head><body><h1>NadEx Monthly Expense Statement</h1><p>Cycle: '+esc(c?.name||'Current')+' | Generated: '+new Date().toLocaleString()+'</p><h2>Summary</h2><p><b>Total transactions:</b> '+ps.length+' &nbsp; | &nbsp; <b>Total spend:</b> '+f12(total)+'</p><table><tr><th>Member</th><th>Paid</th><th>Share</th><th>Net Balance</th><th>Status</th></tr>'+summary+'</table><h2>Complete Transaction Details</h2>'+details+'</body></html>';
  if(window.AndroidBridge&&typeof AndroidBridge.printHtml==='function'){
    AndroidBridge.printHtml(html,'NadEx Monthly Expense');
  }else{
    alert('Android PDF service is unavailable in this installation.');
  }
};

function bind12(){
  renderExpenseHeader12();
  document.querySelectorAll('#messView button').forEach(b=>{
    const t=(b.textContent||'').trim().toLowerCase();
    if(t.includes('pdf')||t.includes('statement'))b.onclick=e=>{e.preventDefault();e.stopPropagation();window.exportMessPDF()};
  });
}
const baseMess12=window.renderMess;
if(typeof baseMess12==='function')window.renderMess=function(){const v=baseMess12.apply(this,arguments);setTimeout(bind12,0);return v};
document.addEventListener('DOMContentLoaded',()=>setTimeout(bind12,30));
setTimeout(bind12,300);
})();
