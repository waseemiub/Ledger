NadEx V6.16 Recovery Build
Base: original V6.12.

No CSS changes. No Monthly Expense layout replacement. No Ledger layout replacement.
No transaction modal redesign. No settings changes.

Exact fixes:
1. app.js original party transaction click now calls window.transactionActions(), so the final V6.3 Save/Delete controller is actually used.
2. Existing party statement gets Edit / Remove Party in its existing statement-actions row. Rename changes history name. Remove hides it from transaction dropdowns but preserves history/balance.
3. Main Balance Statement from v67 is bound to the actual V5.9 DOM id ledgerFullBalanceV59 and also gets a Statement button in the existing balance panel.
4. Monthly Expense personal-only entries are filtered only during the original Monthly Expense render/PDF; complete purchase data is immediately restored for Ledger My Expense.
