/* NadEx V5.8 — Ledger balance + My Share consistency fix only.
   No other screen, transaction, monthly-expense or storage behavior is changed. */
(function(){
  'use strict';

  function E(id){ return document.getElementById(id); }
  function num(v){ v=Number(v); return Number.isFinite(v)?v:0; }
  function cur(){ return (D.settings&&D.settings.displayCurrency)||'AED'; }
  function meId(){ try{return me().id;}catch(e){return 'me';} }

  function authoritativeShare(){
    try{
      var r=messStats(), mine=r.stats.get(meId());
      return mine ? num(mine.balance) : 0;
    }catch(e){ return 0; }
  }

  function sectionHead(cls,label,value,isExpense){
    var h=document.querySelector('#ledgerView .group.'+cls+' .fold-head');
    if(!h)return;
    var idx=({pay:'01',rec:'02',wallet:'03',expense:'04'})[cls]||'';
    h.innerHTML='<span>'+idx+'</span><span class="section-name">'+esc(label)+'</span><span class="section-total"><small>'+(isExpense?'TOTAL':'BALANCE')+'</small>'+cur()+' '+money(Math.abs(num(value)))+'</span><i class="fold-arrow">⌄</i>';
    h.setAttribute('role','button');
    h.setAttribute('tabindex','0');
    h.onclick=function(){h.parentElement.classList.toggle('collapsed');};
    h.onkeydown=function(ev){if(ev.key==='Enter'||ev.key===' '){ev.preventDefault();h.click();}};
  }

  var priorRender=window.renderLedger;
  window.renderLedger=function(){
    if(typeof priorRender==='function') priorRender();

    var s=states();
    var shareBalance=authoritativeShare();
    var wallets=s.filter(function(p){return !!p.wallet;});
    var others=s.filter(function(p){return !p.wallet && p.key!==EXPENSE_KEY;});
    var pay=others.filter(function(p){return num(p.balance)<-0.000001;});
    var rec=others.filter(function(p){return num(p.balance)>0.000001;});

    var payTotal=pay.reduce(function(a,p){return a+Math.abs(num(p.balance));},0)+Math.max(-shareBalance,0);
    var recTotal=rec.reduce(function(a,p){return a+num(p.balance);},0)+Math.max(shareBalance,0);
    var walletTotal=wallets.reduce(function(a,p){return a+num(p.balance);},0);
    var expenseTotal=0; try{expenseTotal=num(myExpenseData().total);}catch(e){}

    sectionHead('pay','Money I Owe',payTotal,false);
    sectionHead('rec','Money I Will Get',recTotal,false);
    sectionHead('wallet','Money With Me',walletTotal,false);
    sectionHead('expense','My Expense',expenseTotal,true);

    // Ensure My Share card itself uses the authoritative Monthly Expense balance.
    var box=E('receivables');
    if(box){
      var card=box.querySelector('[data-k="'+EXPENSE_KEY+'"]');
      if(card){
        var amount=card.querySelector('.account-overview-top > b');
        if(amount){
          amount.textContent=cur()+' '+money(Math.abs(shareBalance));
          amount.className=shareBalance>0?'pos':shareBalance<0?'neg':'neu';
        }
        var meaning=card.querySelector('.account-overview-top small');
        if(meaning)meaning.textContent=shareBalance>0?'You will receive':shareBalance<0?'You owe':'Settled';
      }
    }
  };

  // My Share statement must be derived from Monthly Expense purchases, not from
  // stale/legacy ledger-value snapshots. This makes Current Balance, Total In,
  // Total Out and running balances mathematically identical to Monthly Expense.
  var priorParty=window.party;
  window.party=function(k){
    if(k!==EXPENSE_KEY) return priorParty(k);

    var dc=cur(), c=activeCycle(), start=c?num(c.startTs):0, end=c&&c.endTs!=null?num(c.endTs):Infinity;
    var purchases=(M.purchases||[]).filter(function(p){return num(p.ts)>=start&&num(p.ts)<=end;}).slice().sort(function(a,b){return num(a.ts)-num(b.ts);});
    var mid=meId(), rows=[], running=0, tin=0, tout=0;

    purchases.forEach(function(p){
      var factor=1; try{factor=nxPurchaseFactor(p);}catch(e){}
      var purchaseValue=0; try{purchaseValue=nxPurchaseValue(p);}catch(e){purchaseValue=num(p.amount);}
      var myShare=(p.allocations||[]).filter(function(a){return a.memberId===mid;}).reduce(function(sum,a){return sum+num(a.amount)*factor;},0);
      var delta=(p.paidBy===mid ? purchaseValue-myShare : -myShare);
      delta=Math.round(delta*100)/100;
      running=Math.round((running+delta)*100)/100;
      if(delta>=0)tin+=delta; else tout+=Math.abs(delta);
      rows.push({p:p,delta:delta,running:running,purchaseValue:purchaseValue,myShare:myShare});
    });

    var balance=Math.round((tin-tout)*100)/100;
    E('partyTitle').textContent=EXPENSE_NAME;
    E('partySubtitle').textContent='My Share • Expense-linked Statement';
    E('partyBalance').textContent=dc+' '+money(Math.abs(balance));
    E('partyMeaning').textContent='Your net share linked with Monthly Expense Details';
    E('partyIn').textContent=dc+' '+money(tin);
    E('partyOut').textContent=dc+' '+money(tout);
    E('partyCount').textContent=rows.length;

    E('partyTimeline').innerHTML=rows.length?rows.slice().reverse().map(function(r){
      var p=r.p, inc=r.delta>=0, payer=(M.members||[]).find(function(m){return m.id===p.paidBy;});
      return '<div class="party-tx editable-tx" data-mid="'+esc(p.id)+'">'+
        '<div><div class="pt-date">'+new Date(p.ts).toLocaleDateString()+' • '+new Date(p.ts).toLocaleTimeString()+'</div>'+
        '<div class="pt-desc">'+esc(p.description||'Expense')+'</div>'+
        '<div class="pt-meta">'+dc+' '+money(Math.abs(r.delta))+' • Expense linked • Paid by '+esc(payer?payer.name:'Unknown')+'</div></div>'+
        '<div><div class="pt-amount '+(inc?'pos':'neg')+'">'+(inc?'+':'−')+' '+dc+' '+money(Math.abs(r.delta))+'</div>'+
        '<div class="pt-balance">Running: '+dc+' '+money(r.running)+'</div><div class="pt-edit">Tap to edit / delete</div></div></div>';
    }).join(''):'<div class="empty">No transactions yet</div>';

    E('partyTimeline').querySelectorAll('[data-mid]').forEach(function(el){el.onclick=function(){var p=(M.purchases||[]).find(function(x){return x.id===el.dataset.mid;});if(p)openPurchase({editId:p.id});};});
    window.__partyKey=EXPENSE_KEY;
    showView('partyView');
  };

  renderLedger();
})();
