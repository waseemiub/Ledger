/* NadEx V5.7 — Ledger-only render fix.
   Intentionally changes ONLY the Ledger overview renderer. */
(function(){
  'use strict';

  function el(id){ return document.getElementById(id); }
  function dc(){ return (D.settings && D.settings.displayCurrency) || 'AED'; }
  function n(v){ v=Number(v); return Number.isFinite(v)?v:0; }

  function renderRows(id, rows, showZero){
    var box=el(id); if(!box) return;
    var arr=(rows||[]).filter(function(p){return showZero || Math.abs(n(p.balance))>0.000001;})
      .slice().sort(function(a,b){return n(b.modified)-n(a.modified);});
    box.innerHTML=arr.length ? arr.map(function(p){
      var data=[]; try{ data=tx(p.key)||[]; }catch(e){ data=[]; }
      var tin=0,tout=0;
      data.forEach(function(t){ var v=n(t.displayAmount!=null?t.displayAmount:t.amount); if(t.kind==='add')tin+=v; else if(t.kind==='subtract')tout+=v; });
      var rem=null; try{ if(!p.wallet && n(p.balance)<0) rem=remainingOweLimit(p.key,p.balance); }catch(e){}
      var meaning=p.wallet?'Available balance':n(p.balance)>0?'You will receive':n(p.balance)<0?'You owe':'Settled';
      return '<article class="account-overview-card" data-k="'+esc(p.key)+'">'+
        '<div class="account-overview-top"><div><small>'+esc(meaning)+'</small><h3>'+esc(p.name)+'</h3></div><b class="'+(n(p.balance)>0?'pos':n(p.balance)<0?'neg':'neu')+'">'+dc()+' '+money(Math.abs(n(p.balance)))+'</b></div>'+
        '<div class="account-overview-stats"><span><small>TOTAL IN</small><b>'+dc()+' '+money(tin)+'</b></span><span><small>TOTAL OUT</small><b>'+dc()+' '+money(tout)+'</b></span><span><small>ENTRIES</small><b>'+data.length+'</b></span></div>'+
        (rem==null?'':'<div class="overview-limit">Remaining limit: '+dc()+' '+money(rem)+'</div>')+
        '<div class="account-overview-foot"><span>'+(p.modified?new Date(p.modified).toLocaleString():(p.wallet?'Available account':'No activity'))+'</span><b>View statement ›</b></div></article>';
    }).join('') : '<div class="empty">None</div>';
    box.querySelectorAll('[data-k]').forEach(function(card){card.onclick=function(){party(card.dataset.k);};});
  }

  function renderExpenseOnly(){
    var box=el('expenseAccount'); if(!box)return;
    var x=myExpenseData(), last=x.items.length?x.items[x.items.length-1].ts:0;
    box.innerHTML='<article class="account-overview-card" data-expense="1"><div class="account-overview-top"><div><small>Personal spending</small><h3>My Expense</h3></div><b class="neg">'+dc()+' '+money(n(x.total))+'</b></div><div class="account-overview-stats"><span><small>TOTAL</small><b>'+dc()+' '+money(n(x.total))+'</b></span><span><small>ENTRIES</small><b>'+x.items.length+'</b></span><span><small>LATEST</small><b>'+(last?new Date(last).toLocaleDateString():'—')+'</b></span></div><div class="account-overview-foot"><span>Linked to Monthly Expense Details</span><b>View statement ›</b></div></article>';
    var c=box.querySelector('[data-expense]'); if(c)c.onclick=function(){party(MY_EXPENSE_VIEW_KEY);};
  }

  function head(cls,label,value,isExpense){
    var h=document.querySelector('.group.'+cls+' .fold-head'); if(!h)return;
    var num=h.querySelector('span:first-child'); num=num?num.textContent:({pay:'01',rec:'02',wallet:'03',expense:'04'}[cls]||'');
    h.innerHTML='<span>'+esc(num)+'</span><span class="section-name">'+esc(label)+'</span><span class="section-total"><small>'+(isExpense?'TOTAL':'BALANCE')+'</small>'+dc()+' '+money(Math.abs(n(value)))+'</span><i class="fold-arrow">⌄</i>';
    h.setAttribute('role','button'); h.setAttribute('tabindex','0');
    h.onclick=function(){h.parentElement.classList.toggle('collapsed');};
    h.onkeydown=function(e){if(e.key==='Enter'||e.key===' '){e.preventDefault();h.click();}};
  }

  window.renderLedger=function(){
    var s=states();
    var wallets=s.filter(function(p){return !!p.wallet;});
    var others=s.filter(function(p){return !p.wallet && p.key!==EXPENSE_KEY;});
    var share=s.find(function(p){return p.key===EXPENSE_KEY;}) || {key:EXPENSE_KEY,name:EXPENSE_NAME,balance:0,modified:0};
    var pay=others.filter(function(p){return n(p.balance)<-0.000001;});
    var rec=others.filter(function(p){return n(p.balance)>0.000001;});

    renderRows('payments',pay,false);
    renderRows('receivables',[share].concat(rec),true);
    renderRows('wallets',wallets,true);
    renderExpenseOnly();

    var payTotal=pay.reduce(function(a,p){return a+Math.abs(n(p.balance));},0)+Math.max(-n(share.balance),0);
    var recTotal=rec.reduce(function(a,p){return a+n(p.balance);},0)+Math.max(n(share.balance),0);
    var walletTotal=wallets.reduce(function(a,p){return a+n(p.balance);},0);
    var expenseTotal=0; try{expenseTotal=n(myExpenseData().total);}catch(e){}
    head('pay','Money I Owe',payTotal,false);
    head('rec','Money I Will Get',recTotal,false);
    head('wallet','Money With Me',walletTotal,false);
    head('expense','My Expense',expenseTotal,true);

    var parties=el('parties');
    if(parties){parties.innerHTML=s.filter(function(p){return p.key!==EXPENSE_KEY;}).sort(function(a,b){return a.name.localeCompare(b.name);}).map(function(p){return '<option value="'+esc(p.name)+'">';}).join('')+'<option value="'+EXPENSE_NAME+'">';}
  };

  // Replace only the Ledger renderer after every earlier version script has loaded.
  renderLedger();
})();
