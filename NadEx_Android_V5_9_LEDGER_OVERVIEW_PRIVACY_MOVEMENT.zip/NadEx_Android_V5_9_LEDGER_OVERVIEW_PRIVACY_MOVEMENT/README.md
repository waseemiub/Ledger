# NadEx V5.8 — Ledger Balance + My Share Fix

Only two ledger-related corrections are made from V5.7:
1. Ledger Overview section balances are explicitly restored/displayed.
2. My Share balance and statement are calculated directly from the active Monthly Expense cycle, so they match the Monthly Expense My Share Balance exactly.

No other layout, Monthly Expense purchase presentation, calculations outside My Share, backup/restore format, currency settings, home screen, or navigation behavior was changed.

Version: 5.8
Version code: 58
Application ID: ae.transactor.app
