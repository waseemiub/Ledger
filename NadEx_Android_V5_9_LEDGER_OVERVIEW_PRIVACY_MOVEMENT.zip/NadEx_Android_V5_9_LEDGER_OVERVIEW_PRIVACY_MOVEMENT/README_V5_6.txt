NadEx V5.6 — Ledger Render Final Fix

- Fixes the actual root cause of blank Ledger sections: the original renderLedger still wrote to aggregate balance DOM elements removed in V5.2, throwing before party rows could render.
- Core renderLedger is now compatible with the simplified Ledger DOM.
- Restores V5.3 compact Monthly Expense purchase renderer.
- Retains V5.2 compact party/member overview cards and all existing calculations, backup/restore, My Share sync, and transaction logic.
- versionCode 56 / versionName 5.6.
