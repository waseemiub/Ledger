
/* NadEx V6.4 — Monthly Expense purchase compatibility fix.
   Currency UI stays removed. Legacy purchase code still expects internal
   pcurrency/pfx DOM nodes before it binds SAVE PURCHASE, so provide them hidden. */
(function(){
'use strict';

window.currencyFields = function(prefix){
  prefix = prefix || '';
  return '<input type="hidden" id="'+prefix+'currency" value="">'
       + '<input type="hidden" id="'+prefix+'fx" value="1">';
};

window.wireCurrency = function(prefix, amountId){
  /* Intentionally no visible currency controls in numbers-only mode. */
};

window.readCurrency = function(prefix, amountId){
  var node = document.getElementById(amountId);
  if(!node) throw new Error('Amount field is unavailable.');
  var v = Math.round(Number(node.value) * 100) / 100;
  if(!(v > 0)) throw new Error('Enter a valid amount.');
  return {
    originalAmount:v,
    originalCurrency:'',
    fxRate:1,
    aedAmount:v,
    valueAmount:v,
    valueCurrency:'',
    fxRateToValue:1,
    fxSnapshots:{}
  };
};

/* Defensive diagnostic: after a purchase modal opens, its internal compatibility
   nodes should exist and the existing savePurchase handler can bind normally. */
})();
