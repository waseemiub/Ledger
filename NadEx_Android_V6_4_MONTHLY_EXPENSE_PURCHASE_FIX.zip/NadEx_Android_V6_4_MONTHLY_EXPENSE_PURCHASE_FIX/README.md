# NadEx V6.4 — Monthly Expense Purchase Fix

Root cause fixed:
V6.1 removed currencyFields() completely, but the existing Monthly Expense openPurchase() still accesses `pcurrency` and `pfx` immediately after rendering the purchase modal. Because those elements no longer existed, JavaScript stopped before attaching the SAVE PURCHASE handler.

V6.4 restores only hidden compatibility nodes. No currency option is visible to the user and amounts remain numbers-only.

Preserved:
- V6.1 minimal Ledger transaction design
- V6.3 transaction edit/update controller
- Monthly Expense split/allocation logic
- My Share logic
- Existing localStorage data
- applicationId ae.transactor.app

Version 6.4 / versionCode 64
