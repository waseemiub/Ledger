NadEx V6.10
Targeted fixes from V6.9:
1. Synchronizes the outer My Expense section TOTAL with the same authoritative total already shown correctly inside the My Expense card.
2. Keeps the My Expense transaction history.
3. Returns Monthly Expense statement to classic document-window style.
4. Detailed report remains: summary, total transactions/spend, member paid/share/net/status, every purchase, payer, involved members and individual shares.
5. Statement opens the native Android/browser print flow automatically and also provides Print / Save PDF plus Back.
Version 6.10 / versionCode 70.
