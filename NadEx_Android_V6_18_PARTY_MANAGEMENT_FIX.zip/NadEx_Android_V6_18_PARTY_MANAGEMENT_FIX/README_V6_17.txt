NadEx V6.17 Direct Source Fix
Base: original V6.12.

Fixes:
1. Edit/Delete Party is now a real static control in the existing Party Statement header, using the existing outline-btn design.
2. Delete Party means remove from New Transaction dropdowns only; balance/history are preserved. Rename updates existing history.
3. Ledger transaction Delete root cause fixed: V6.3 was calling nxConfirm from another script's private IIFE. V6.3 now owns its confirmation function and verifies localStorage after deletion.
4. Party transaction rows now explicitly call window.transactionActions, the final V6.3 controller.
5. Main Balance Statement uses the existing Overview Statement button, so there is no extra white button/bar. Clicking the full balance also opens it.
6. Main Balance Statement includes PDF Statement and CSV Statement buttons using the existing statement-actions design.
7. Monthly Expense personal-only filtering remains data-only during original render/PDF; original Monthly Expense layout is not replaced.

No V6.17 CSS file. No Monthly Expense redesign. No Ledger redesign. No settings changes.
