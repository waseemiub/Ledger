NadEx V6.18 - Party Management Access Fix
Base: V6.17 direct-source build.

Only party-management access was changed:
- Edit/Delete Party button moved into the existing Party Statement action row, so it inherits the same dark button design as PDF/CSV.
- Button visibility is synchronized from the actual visible partyView + window.__partyKey, independent of which legacy party() wrapper opened the screen.
- Normal non-wallet party: EDIT / DELETE PARTY.
- Hidden party: EDIT / RESTORE PARTY.
- Wallet / My Share / My Expense: control hidden.
- Press-and-hold a party card for 650 ms also opens the same Edit/Delete Party dialog.
- Existing card HTML/CSS and normal tap behavior remain unchanged.
- Delete Party continues to remove the party from transaction dropdowns while preserving existing history and balance.

No CSS changes.
No Monthly Expense changes.
No Ledger calculation changes.
No Main Balance Statement changes.
No settings changes.
