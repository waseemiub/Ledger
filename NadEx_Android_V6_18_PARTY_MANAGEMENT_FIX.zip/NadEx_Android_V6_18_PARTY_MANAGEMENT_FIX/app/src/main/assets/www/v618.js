
/* NadEx V6.18 — direct source correction, original V6.12 design retained. */
(function(){
'use strict';
const E=id=>document.getElementById(id);
const saveD=()=>localStorage.setItem(K,JSON.stringify(D));

function hidden(){
  if(!Array.isArray(D.hiddenParties))D.hiddenParties=[];
  return D.hiddenParties;
}
function isHidden(k){return hidden().includes(key(k));}

function partyConfirm(title,text,yes){
  modal(title,'<div class="themed-dialog"><div class="dialog-icon">!</div><h3>'+esc(title)+'</h3><p>'+esc(text)+'</p><div class="dialog-actions"><button type="button" id="p617Cancel">CANCEL</button><button type="button" id="p617Yes" class="danger">DELETE</button></div></div>');
  E('p617Cancel').onclick=close;
  E('p617Yes').onclick=function(e){e.preventDefault();e.stopPropagation();close();yes();};
}

/* Edit / Delete Party — directly opened by the static button in Party Statement. */
window.managePartyV617=function(k,currentName){
  k=key(k);
  const p=states().find(x=>x.key===k);
  if(!p||p.wallet||k===EXPENSE_KEY)return;
  const hiddenNow=isHidden(k);

  modal('Edit / Delete Party',
    '<div class="field"><label>Party Name</label><input id="p617Name" value="'+esc(currentName||p.name)+'"></div>'+
    '<div class="note">Deleting a party removes it from New Transaction dropdowns only. Existing balance and transaction history remain available.</div>'+
    '<div class="opts two"><button type="button" id="p617Save" class="primary">SAVE NAME</button>'+
    '<button type="button" id="p617Delete" class="danger">'+(hiddenNow?'RESTORE PARTY':'DELETE PARTY')+'</button></div>'
  );

  E('p617Save').onclick=function(e){
    e.preventDefault();e.stopPropagation();
    const name=String(E('p617Name').value||'').trim().replace(/\s+/g,' ');
    if(!name)return alert('Enter a party name.');
    const nk=key(name);
    if(isWalletKey(nk)||nk===EXPENSE_KEY)return alert('Choose a different party name.');
    if(states().some(x=>x.key===nk&&x.key!==k))return alert('A party with this name already exists.');

    D.transactions.forEach(t=>{
      if(canonicalPartyKey(t)===k){t.partyKey=nk;t.party=name;}
    });

    if(D.partyLimits&&Object.prototype.hasOwnProperty.call(D.partyLimits,k)){
      D.partyLimits[nk]=D.partyLimits[k];
      delete D.partyLimits[k];
    }

    if(isHidden(k)){
      D.hiddenParties=hidden().filter(x=>x!==k);
      D.hiddenParties.push(nk);
    }

    saveD();close();renderLedger();party(nk);
  };

  E('p617Delete').onclick=function(e){
    e.preventDefault();e.stopPropagation();

    if(hiddenNow){
      D.hiddenParties=hidden().filter(x=>x!==k);
      saveD();close();renderLedger();party(k);
      return;
    }

    partyConfirm(
      'Delete Party From List?',
      'This removes '+(currentName||p.name)+' from New Transaction dropdowns. Existing transactions and balance will not be deleted.',
      function(){
        if(!isHidden(k))D.hiddenParties.push(k);
        saveD();renderLedger();party(k);
      }
    );
  };
};

/* Keep personal-only purchases out of Monthly Expense only.
   Full source data is restored immediately for Ledger My Expense. */
function personalOnly(p){
  let mine;try{mine=me().id}catch(e){return false}
  if(!p||String(p.paidBy)!==String(mine))return false;
  const a=(p.allocations||[]).filter(x=>Number(x.amount)>0.000001);
  return a.length===1&&String(a[0].memberId)===String(mine);
}
function filtered(fn,ctx,args){
  const all=M.purchases;
  M.purchases=(all||[]).filter(p=>!personalOnly(p));
  try{return fn.apply(ctx,args||[])}finally{M.purchases=all}
}
const mess0=window.renderMess;
window.renderMess=function(){return filtered(mess0,this,arguments)};
if(typeof window.exportMessPDF==='function'){
  const pdf0=window.exportMessPDF;
  window.exportMessPDF=function(){return filtered(pdf0,this,arguments)};
}

/* Main Balance Statement:
   use the EXISTING "Statement" outline button already present in the Overview.
   No extra button, no white bar, no CSS change. */
if(typeof window.openMainBalanceStatement==='function'){
  const mainStatement0=window.openMainBalanceStatement;
  window.openMainBalanceStatement=function(){
    const r=mainStatement0.apply(this,arguments);
    setTimeout(function(){
      const body=E('mb');
      if(!body||E('main617Actions'))return;
      const actions=document.createElement('div');
      actions.id='main617Actions';
      actions.className='statement-actions';
      actions.innerHTML='<button type="button" id="main617Pdf">PDF Statement</button><button type="button" id="main617Csv">CSV Statement</button>';
      body.appendChild(actions);
      E('main617Pdf').onclick=function(){if(typeof printLedger==='function')printLedger();};
      E('main617Csv').onclick=function(){if(typeof csv==='function')csv();};
    },0);
    return r;
  };
}

function bindMainStatement(){
  const b=E('download');
  if(b){
    b.textContent='Statement';
    b.onclick=function(e){e.preventDefault();e.stopPropagation();window.openMainBalanceStatement();};
  }
  const bal=E('ledgerFullBalanceV59');
  if(bal){
    bal.style.cursor='pointer';
    bal.onclick=function(e){e.preventDefault();e.stopPropagation();window.openMainBalanceStatement();};
  }
}
const ledger0=window.renderLedger;
window.renderLedger=function(){
  const r=ledger0.apply(this,arguments);
  setTimeout(bindMainStatement,0);
  return r;
};
document.addEventListener('DOMContentLoaded',()=>setTimeout(bindMainStatement,50));
setTimeout(bindMainStatement,300);

/* V6.18 PARTY MANAGEMENT ACCESS FIX
   The prior button depended on one historical party() path.
   This synchronizes from the ACTUAL visible partyView and __partyKey,
   so it works regardless of which legacy wrapper opened the statement.
   It also adds press-and-hold access on party cards without changing card design. */
function partyManageSync618(){
  const b=E('partyManage');
  if(!b)return;

  const view=E('partyView');
  if(!view || view.classList.contains('hide')){
    b.style.display='none';
    return;
  }

  const k=window.__partyKey;
  if(!k || k===EXPENSE_KEY || k===MY_EXPENSE_VIEW_KEY){
    b.style.display='none';
    return;
  }

  const p=states().find(x=>x.key===key(k));
  if(!p || p.wallet){
    b.style.display='none';
    return;
  }

  b.style.display='';
  b.style.gridColumn='1 / -1';
  b.textContent=isHidden(p.key)?'EDIT / RESTORE PARTY':'EDIT / DELETE PARTY';
  b.onclick=function(e){
    e.preventDefault();
    e.stopPropagation();
    window.managePartyV617(p.key,p.name);
  };
}

/* Observe only partyView visibility. No page/layout replacement. */
const pv618=E('partyView');
if(pv618){
  new MutationObserver(function(){setTimeout(partyManageSync618,0);})
    .observe(pv618,{attributes:true,attributeFilter:['class']});
}

/* After every final party() call, sync the real button from __partyKey. */
const party618=window.party;
window.party=function(){
  const r=party618.apply(this,arguments);
  setTimeout(partyManageSync618,0);
  return r;
};

/* Press and hold any normal Ledger party card for direct Edit/Delete access.
   Card HTML/CSS is unchanged. A normal tap still opens the statement. */
function bindPartyHold618(){
  ['payments','receivables'].forEach(function(id){
    const box=E(id); if(!box)return;
    box.querySelectorAll('[data-k]').forEach(function(card){
      const k=key(card.dataset.k||'');
      const p=states().find(x=>x.key===k);
      if(!p || p.wallet || k===EXPENSE_KEY || k===MY_EXPENSE_VIEW_KEY)return;
      if(card.dataset.partyHold618==='1')return;
      card.dataset.partyHold618='1';

      let timer=null, fired=false;
      const start=function(){
        fired=false;
        clearTimeout(timer);
        timer=setTimeout(function(){
          fired=true;
          window.managePartyV617(p.key,p.name);
        },650);
      };
      const stop=function(){clearTimeout(timer);};
      card.addEventListener('touchstart',start,{passive:true});
      card.addEventListener('touchend',stop,{passive:true});
      card.addEventListener('touchcancel',stop,{passive:true});
      card.addEventListener('mousedown',start);
      card.addEventListener('mouseup',stop);
      card.addEventListener('mouseleave',stop);
      card.addEventListener('click',function(e){
        if(fired){
          e.preventDefault();
          e.stopImmediatePropagation();
          fired=false;
        }
      },true);
    });
  });
}

const render618=window.renderLedger;
window.renderLedger=function(){
  const r=render618.apply(this,arguments);
  setTimeout(function(){
    bindMainStatement();
    bindPartyHold618();
    partyManageSync618();
  },0);
  return r;
};

document.addEventListener('DOMContentLoaded',function(){
  setTimeout(function(){
    bindPartyHold618();
    partyManageSync618();
  },80);
});

})();
