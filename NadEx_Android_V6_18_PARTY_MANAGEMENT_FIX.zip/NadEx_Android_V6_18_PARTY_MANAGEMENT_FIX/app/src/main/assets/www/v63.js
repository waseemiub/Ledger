
/* NadEx V6.3 — rebuilt Edit/Update controller */
(function(){
'use strict';
const el=id=>document.getElementById(id);
const persist=()=>localStorage.setItem(K,JSON.stringify(D));
function confirmDelete63(title,text,yes){
  modal(title,`<div class="themed-dialog"><div class="dialog-icon">!</div><h3>${esc(title)}</h3><p>${esc(text)}</p><div class="dialog-actions"><button type="button" id="v63Cancel">CANCEL</button><button type="button" id="v63Yes" class="danger">DELETE</button></div></div>`);
  el('v63Cancel').onclick=close;
  el('v63Yes').onclick=function(e){e.preventDefault();e.stopPropagation();close();yes();};
}

function linked(t){
  if(t.transferId)return D.transactions.filter(x=>x.transferId===t.transferId);
  if(t.movementId)return D.transactions.filter(x=>x.movementId===t.movementId);
  return [t];
}
function parts(ts){
  let d=new Date(Number(ts)||Date.now()),p=v=>String(v).padStart(2,'0');
  return{date:`${d.getFullYear()}-${p(d.getMonth()+1)}-${p(d.getDate())}`,time:`${p(d.getHours())}:${p(d.getMinutes())}`};
}
function refresh(k){
  try{renderLedger()}catch(e){console.error(e)}
  if(k)try{party(k)}catch(e){console.error(e)}
}
function editTransaction(t){
  const rows=linked(t), pair=rows.length>1, dp=parts(t.ts), returnKey=t.partyKey;
  const amount=Number(t.amount??t.valueAmount??t.aedAmount??t.originalAmount)||0;
  modal(pair?'Edit Linked Transaction':'Edit Transaction',`
    <div class="field"><label>Amount</label><input id="v63Amount" type="number" inputmode="decimal" min=".01" step=".01" value="${esc(amount)}"></div>
    <div class="field"><label>Description</label><textarea id="v63Desc">${esc(t.description||'')}</textarea></div>
    <div class="field"><label>Date</label><input id="v63Date" type="date" value="${dp.date}"></div>
    <div class="field"><label>Time</label><input id="v63Time" type="time" value="${dp.time}"></div>
    ${pair?'<div class="linked">Amount and date/time update both linked sides.</div>':''}
    <div id="v63Status" class="note" style="display:none"></div>
    <div class="opts two"><button type="button" id="v63Save" class="primary">SAVE CHANGES</button><button type="button" id="v63Delete" class="danger">DELETE</button></div>`);

  el('v63Save').addEventListener('click',function(e){
    e.preventDefault();e.stopPropagation();
    const btn=el('v63Save'),status=el('v63Status');
    const amt=Math.round(Number(el('v63Amount').value)*100)/100;
    if(!Number.isFinite(amt)||amt<=0)return alert('Enter a valid amount.');
    if(!el('v63Date').value||!el('v63Time').value)return alert('Enter a valid date and time.');
    const nts=new Date(el('v63Date').value+'T'+el('v63Time').value+':00').getTime();
    if(!Number.isFinite(nts))return alert('Enter a valid date and time.');
    btn.disabled=true;btn.textContent='SAVING...';
    try{
      rows.forEach((x,i)=>{
        x.amount=amt;x.ts=nts+i;
        if('originalAmount'in x)x.originalAmount=amt;
        if('aedAmount'in x)x.aedAmount=amt;
        if('valueAmount'in x)x.valueAmount=amt;
        if('fxRate'in x)x.fxRate=1;
        if('fxRateToValue'in x)x.fxRateToValue=1;
        if('originalCurrency'in x)x.originalCurrency='';
        if('valueCurrency'in x)x.valueCurrency='';
      });
      t.description=String(el('v63Desc').value||'').trim();
      persist();

      const saved=JSON.parse(localStorage.getItem(K)||'{}');
      const check=(saved.transactions||[]).find(x=>x.id===t.id);
      if(!check||Math.round(Number(check.amount)*100)/100!==amt)throw new Error('Storage verification failed.');

      status.style.display='block';status.textContent='Saved successfully';btn.textContent='SAVED';
      setTimeout(()=>{close();refresh(returnKey)},120);
    }catch(err){
      console.error('V6.3 save',err);
      btn.disabled=false;btn.textContent='SAVE CHANGES';
      status.style.display='block';status.textContent='Save failed: '+(err.message||'Unknown error');
      alert(status.textContent);
    }
  });

  el('v63Delete').addEventListener('click',function(e){
    e.preventDefault();e.stopPropagation();
    confirmDelete63(pair?'Delete Linked Transaction?':'Delete Transaction?',pair?'Both linked sides will be removed.':'This transaction will be permanently removed.',()=>{
      try{
        const ids=new Set(rows.map(x=>x.id));
        D.transactions=D.transactions.filter(x=>!ids.has(x.id));
        persist();
        const saved=JSON.parse(localStorage.getItem(K)||'{}');
        if((saved.transactions||[]).some(x=>ids.has(x.id)))throw new Error('Delete storage verification failed.');
        close();refresh(returnKey);
      }catch(err){console.error(err);alert('Delete failed.')}
    });
  });
}

window.transactionActions=function(id){
  const t=D.transactions.find(x=>x.id===id);
  if(!t)return alert('Transaction not found.');
  if(t.messId){
    const p=M.purchases.find(x=>x.id===t.messId);
    modal('Expense-linked Transaction',`<div class="note">This entry is controlled by its Monthly Expense purchase.</div><div class="opts two"><button type="button" id="v63ExpenseEdit">EDIT EXPENSE</button><button type="button" id="v63ExpenseDelete" class="danger">DELETE EXPENSE</button></div>`);
    el('v63ExpenseEdit').addEventListener('click',()=>{close();p?openPurchase({editId:p.id}):alert('Linked expense was not found.')});
    el('v63ExpenseDelete').addEventListener('click',()=>{close();p?deletePurchase(p.id):alert('Linked expense was not found.')});
    return;
  }
  editTransaction(t);
};
})();
