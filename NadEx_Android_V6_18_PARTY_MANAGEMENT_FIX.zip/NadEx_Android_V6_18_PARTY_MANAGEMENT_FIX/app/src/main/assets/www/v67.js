
(function(){
'use strict';
const E=id=>document.getElementById(id),N=v=>Number.isFinite(Number(v))?Number(v):0,R=v=>Math.round(N(v)*100)/100;
const F=v=>{try{return money(Math.abs(N(v)))}catch(e){return Math.abs(N(v)).toFixed(2)}};
const SD=()=>localStorage.setItem(K,JSON.stringify(D));
function MS(){try{let z=messStats(),x=z.stats.get(me().id);return x||{paid:0,share:0,balance:0}}catch(e){return{paid:0,share:0,balance:0}}}
function myExpenseTotal(){
 let monthly=0;
 try{let c=activeCycle();M.purchases.filter(p=>!c||!p.cycleId||p.cycleId===c.id).forEach(p=>monthly+=N((p.allocations||[]).find(a=>a.memberId===me().id)?.amount))}catch(e){}
 let manual=D.transactions.filter(t=>!t.messId&&canonicalPartyKey(t)===EXPENSE_KEY).reduce((a,t)=>a+(t.kind==='add'?N(t.amount):-N(t.amount)),0);
 return Math.max(0,R(monthly+manual));
}

/* Ledger Withdraw -> My Expense opens Monthly Expense allocation. */
const oldOpen=window.openPurchase;
window.openPurchase=function(o={}){
 oldOpen(o);
 setTimeout(()=>{
  let b=E('savePurchase'); if(!b)return;
  if(window.__nxFund){
   let note=document.createElement('div');note.className='split-box';
   note.innerHTML='<b>Ledger funding:</b> '+esc(window.__nxFund.name)+'<br><small>Save the purchase after choosing individual/equal member shares.</small>';
   b.parentElement.insertBefore(note,b);
  }
 },0);
};
window.expense=function(amount,from,description){
 window.__nxFund={key:from.key,name:from.name,amount:R(amount),description:description||''};
 openPurchase({});
 setTimeout(()=>{
  let a=E('pamount'),d=E('pdesc'),p=E('ppaid');
  if(a){a.value=R(amount);a.dispatchEvent(new Event('input',{bubbles:true}))}
  if(d&&description)d.value=description;
  if(p)p.value=me().id;
 },0);
};

/* After a new purchase initiated from Ledger, debit the selected funding account.
   My Share itself is calculated from Monthly Expense, avoiding duplicate postings. */
document.addEventListener('click',function(ev){
 let b=ev.target.closest&&ev.target.closest('#savePurchase'); if(!b||!window.__nxFund)return;
 let fund=window.__nxFund,before=new Set((M.purchases||[]).map(p=>p.id));
 setTimeout(()=>{
  let p=(M.purchases||[]).filter(x=>!before.has(x.id)).sort((a,b)=>b.ts-a.ts)[0]; if(!p)return;
  if(p.paidBy===me().id){
   D.transactions.push({id:uid('LED'),ts:p.ts||Date.now(),partyKey:fund.key,party:fund.name,description:p.description||fund.description||'Monthly Expense',amount:R(p.amount),kind:'subtract',movementId:uid('EXP'),movementRole:'expenseFunding',messId:p.id});
   SD();
  }
  window.__nxFund=null; renderLedger();
 },220);
},true);

/* My Share = live Monthly Expense settlement. My Expense = all my allocated expenses. */
function repair(){
 let ms=MS(),bal=N(ms.balance),pay=E('payments'),rec=E('receivables');
 if(pay&&rec){
  let c=document.querySelector('[data-k="'+EXPENSE_KEY+'"]');
  if(!c){c=document.createElement('article');c.className='account-overview-card';c.dataset.k=EXPENSE_KEY}
  let target=bal<0?pay:rec;if(c.parentElement!==target)target.prepend(c);
  c.innerHTML='<div class="account-overview-top"><div><small>MONTHLY EXPENSE SETTLEMENT</small><h3>'+esc(EXPENSE_NAME)+'</h3></div><b class="'+(bal>0?'pos':bal<0?'neg':'neu')+'">'+F(bal)+'</b></div><div class="account-overview-stats"><span><small>I PAID</small><b>'+F(ms.paid)+'</b></span><span><small>MY SHARE</small><b>'+F(ms.share)+'</b></span><span><small>NET</small><b>'+F(bal)+'</b></span></div><div class="account-overview-foot"><span>Live from Monthly Expense</span><b>View statement ›</b></div>';
  c.onclick=()=>party(EXPENSE_KEY);
 }
 let ex=E('expenseAccount');
 if(ex){let c=ex.querySelector('[data-expense]');if(c){let v=myExpenseTotal(),a=c.querySelector('.account-overview-top > b'),b=c.querySelector('.account-overview-stats span:first-child b');if(a)a.textContent=F(v);if(b)b.textContent=F(v)}}
}
const oldRender=window.renderLedger;window.renderLedger=function(){let x=oldRender.apply(this,arguments);setTimeout(repair,0);return x};

/* Detailed My Share statement from purchases. */
const oldParty=window.party;
window.party=function(key){
 if(key!==EXPENSE_KEY)return oldParty.apply(this,arguments);
 let manage=E('partyManage');if(manage)manage.style.display='none';
 let id=me().id,run=0,ti=0,to=0,rows=[];
 (M.purchases||[]).slice().sort((a,b)=>a.ts-b.ts).forEach(p=>{
  let sh=N((p.allocations||[]).find(a=>a.memberId===id)?.amount),pd=p.paidBy===id?N(p.amount):0;if(!sh&&!pd)return;
  let d=R(pd-sh);run=R(run+d);if(d>=0)ti+=d;else to+=-d;rows.push({p,sh,pd,d,run});
 });
 E('partyTitle').textContent=EXPENSE_NAME;E('partySubtitle').textContent='Monthly Expense settlement statement';E('partyBalance').textContent=F(run);
 E('partyMeaning').textContent=run>0?'Monthly Expense owes you':run<0?'You owe Monthly Expense':'Settled';E('partyIn').textContent=F(ti);E('partyOut').textContent=F(to);E('partyCount').textContent=rows.length;
 E('partyTimeline').innerHTML=rows.length?rows.slice().reverse().map(x=>'<div class="party-tx"><div><div class="pt-date">'+new Date(x.p.ts).toLocaleString()+'</div><div class="pt-desc">'+esc(x.p.description||'Purchase')+'</div><div class="pt-meta">Paid '+F(x.pd)+' • My share '+F(x.sh)+' • '+esc((x.p.allocations||[]).map(a=>M.members.find(m=>m.id===a.memberId)?.name||'Member').join(', '))+'</div></div><div><div class="pt-amount '+(x.d>=0?'pos':'neg')+'">'+(x.d>=0?'+ ':'− ')+F(Math.abs(x.d))+'</div><div class="pt-balance">Running: '+F(x.run)+'</div></div></div>').join(''):'<div class="empty">No share transactions</div>';
 window.__partyKey=EXPENSE_KEY;showView('partyView');
};

/* Full Monthly Expense PDF/print statement. */
window.exportMessPDF=function(){
 let c=activeCycle(),ps=(M.purchases||[]).filter(p=>!c||!p.cycleId||p.cycleId===c.id).sort((a,b)=>a.ts-b.ts),z=messStats(),total=ps.reduce((a,p)=>a+N(p.amount),0);
 let summary=(M.members||[]).filter(m=>m.active||z.stats.has(m.id)).map(m=>{let x=z.stats.get(m.id)||{paid:0,share:0,balance:0};return '<tr><td>'+esc(m.name)+'</td><td>'+F(x.paid)+'</td><td>'+F(x.share)+'</td><td>'+F(x.balance)+'</td><td>'+(x.balance>0?'To receive':x.balance<0?'To pay':'Settled')+'</td></tr>'}).join('');
 let details=ps.map((p,i)=>'<section><h3>'+(i+1)+'. '+esc(p.description||'Purchase')+'</h3><p><b>Date/Time:</b> '+new Date(p.ts).toLocaleString()+' | <b>Paid by:</b> '+esc(M.members.find(m=>m.id===p.paidBy)?.name||'Unknown')+' | <b>Total:</b> '+F(p.amount)+' | <b>Split:</b> '+esc(p.splitMode||'equal')+'</p><table><tr><th>Member involved</th><th>Share</th></tr>'+(p.allocations||[]).map(a=>'<tr><td>'+esc(M.members.find(m=>m.id===a.memberId)?.name||'Member')+'</td><td>'+F(a.amount)+'</td></tr>').join('')+'</table></section>').join('');
 let html='<!doctype html><html><head><meta charset="utf-8"><style>body{font-family:Arial;padding:28px;color:#111}table{width:100%;border-collapse:collapse;margin:8px 0 20px}th,td{border:1px solid #aaa;padding:7px;text-align:left}th{background:#eee}section{break-inside:avoid}h1{margin-bottom:4px}</style></head><body><h1>NadEx Monthly Expense Statement</h1><p>Cycle: '+esc(c?.name||'Current')+' | Generated: '+new Date().toLocaleString()+'</p><h2>Summary</h2><p><b>Total transactions:</b> '+ps.length+' &nbsp; <b>Total spend:</b> '+F(total)+'</p><table><tr><th>Member</th><th>Paid</th><th>Share</th><th>Net</th><th>Status</th></tr>'+summary+'</table><h2>All Transaction Details</h2>'+details+'</body></html>';
 let w=window.open('','_blank');if(!w)return alert('Unable to open statement preview.');w.document.write(html);w.document.close();setTimeout(()=>w.print(),250);
};
function bindPdf(){document.querySelectorAll('#messView button').forEach(b=>{let t=(b.textContent||'').toLowerCase();if(t.includes('pdf')||t.includes('statement'))b.onclick=e=>{e.preventDefault();exportMessPDF()}})}
const oldMess=window.renderMess;window.renderMess=function(){let x=oldMess.apply(this,arguments);setTimeout(bindPdf,0);return x};

/* Main Ledger Balance statement. */
function mainBal(){let s=[];try{s=states()}catch(e){}return R(s.filter(x=>x.wallet).reduce((a,x)=>a+N(x.balance),0)+s.filter(x=>!x.wallet&&x.key!==EXPENSE_KEY).reduce((a,x)=>a+N(x.balance),0)+N(MS().balance))}
window.openMainBalanceStatement=function(){
 let tx=D.transactions.filter(t=>!t.messId).slice().sort((a,b)=>a.ts-b.ts),run=0,rows=tx.map(t=>{let d=(t.kind==='add'?1:-1)*N(t.amount);run=R(run+d);return{t,d,run}});
 modal('Main Balance Statement','<div class="balance-card"><small>CURRENT MAIN BALANCE</small><strong>'+F(mainBal())+'</strong><span>'+rows.length+' transactions</span></div><div class="party-timeline">'+(rows.length?rows.slice().reverse().map(x=>'<div class="party-tx"><div><div class="pt-date">'+new Date(x.t.ts).toLocaleString()+'</div><div class="pt-desc">'+esc(x.t.description||'Transaction')+'</div><div class="pt-meta">'+esc(x.t.party||'Account')+'</div></div><div><div class="pt-amount '+(x.d>=0?'pos':'neg')+'">'+(x.d>=0?'+ ':'− ')+F(Math.abs(x.d))+'</div><div class="pt-balance">Running: '+F(x.run)+'</div></div></div>').join(''):'<div class="empty">No Ledger transactions</div>')+'</div>');
};
function bindMain(){[E('fullLedgerBalance'),document.querySelector('.full-ledger-balance'),document.querySelector('.ledger-total-card')].filter(Boolean).forEach(x=>{x.style.cursor='pointer';x.onclick=()=>openMainBalanceStatement()})}
document.addEventListener('DOMContentLoaded',()=>setTimeout(()=>{repair();bindPdf();bindMain()},50));
setTimeout(()=>{repair();bindPdf();bindMain()},300);
})();
