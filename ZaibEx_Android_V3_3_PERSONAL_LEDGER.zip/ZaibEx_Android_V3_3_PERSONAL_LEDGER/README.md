# Transactor Android V2
Offline Android WebView app combining the existing Ledger with the new Mess Record module.

- Keeps applicationId `ae.transactor.app` and the original Ledger localStorage key `ledgerCalculationV1` so an update can retain existing Ledger data.
- Adds Mess Record storage separately under `transactorMessV2`.
- Mess purchases support equal or individual member allocation and automatically sync only the user's net share to the MESS party in Ledger.
- Monthly Mess overview, member management, CSV export and Android Print/PDF are included.
- Android system-bar insets are applied to the WebView so the interface stays below the status bar and above the navigation bar.
- CSV/JSON files save to Downloads/Transactor.

Build with JDK 17, Gradle 8.9 and Android SDK 35:
`gradle assembleDebug`

APK output: `app/build/outputs/apk/debug/app-debug.apk`
