Transactor / NadEx V3.1 FUTURE DASHBOARD

- Launcher display name: NadEx
- Futuristic neon/glass dashboard with supplied family picture as subtle watermark
- Launcher icon uses approved NadEx family design
- Ledger order locked: Money With Me, Money I Owe, Money I Will Get
- Parties inside each section sorted by latest activity first
- Hide/Show main balance and all three section totals
- Full-screen individual statements retained
- One tap on a statement transaction opens Edit/Delete directly
- My Share remains linked receivable account; My Expense remains personal-spend indicator linked to Monthly Expense Details
- Cash/Mashreq free Add Money retained
- Existing transfer, FX, PDF/CSV, backup/restore, expense cycles and storage keys retained
