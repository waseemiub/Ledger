Transactor V2.8
- Restores full-screen individual party statements.
- Party statement PDF/CSV actions restored.
- Payables (red) displayed above Receivables (green).
- Main position breakdown color-coded.
- Existing storage and backup formats unchanged.
