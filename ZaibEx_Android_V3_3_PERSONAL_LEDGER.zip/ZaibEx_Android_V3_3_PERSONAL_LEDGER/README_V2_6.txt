Transactor Android V2.6 — Classic Party Statement

Built on V2.5 Money Flow without changing the storage keys or established financial/Mess logic.
Changes:
- Restored robust tap-to-open statement for every Ledger row, including zero-balance wallet/My Expense rows.
- Dedicated Party Statement screen with transaction overview, running balances, FX details, PDF and CSV actions.
- Modern-classic navy / ivory / gold visual refresh.
- New NADEEM-branded classic launcher icon.
- Existing ledgerCalculationV1 and transactorMessV2 storage keys retained for backup compatibility.
- Manual Mess Cycle, My Expense linkage, Money Flow, transfers, FX and backup/restore logic retained.
