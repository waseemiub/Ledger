Transactor Android V2.5 — Money Flow Redesign

DATA COMPATIBILITY
- Keeps ledgerCalculationV1 and transactorMessV2 storage keys unchanged.
- Existing V2.4 backup JSON is accepted.
- Restore normalizes legacy MESS/My Expense labels into one visible My Expense account.
- Existing Mess purchases are merged into one open manual Mess cycle using the established V2.4 migration rule.
- No existing transaction is deleted or recalculated during restore.

LEDGER UI
- Money With Me: Cash, Mashreq, Tabby Cash.
- Pending Receivables: money others owe the user.
- Pending Payables: money the user owes others.
- My Expense: single visible Mess-linked account.
- New money movement flows update the funding account and party together.
- Transfer supports existing or newly typed parties on both FROM and TO.
- FX conversion remains manual with AED as master currency.

REPORTS
- Professional A4 portrait tables and protected compact owner branding.
