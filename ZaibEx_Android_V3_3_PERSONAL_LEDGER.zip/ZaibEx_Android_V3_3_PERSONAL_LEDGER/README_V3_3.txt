ZaibEx V3.3 — PERSONAL LEDGER + MONTHLY EXPENSES

Hard Money: Cash, Meezan Bank, Askari Bank.
Open Source into Hard Money asks Income or Money I Owe.
Income increases only the selected hard-money account.
Money I Owe increases hard money and creates a matching payable.
My Monthly Expenses is a one-person expense ledger, separate from Main Balance.
Expenses can be paid from Hard Money or Open Source; Open Source creates a payable automatically.
Legacy storage keys remain unchanged for backup compatibility.
