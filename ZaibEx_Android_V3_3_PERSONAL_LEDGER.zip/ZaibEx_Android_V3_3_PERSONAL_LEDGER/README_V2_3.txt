Transactor Android V2.3

Changes:
- My Expense replaces MESS as the permanent Ledger party label while retaining the same internal storage key for backup compatibility.
- Transfers involving My Expense automatically continue into the existing Mess split workflow.
- Manual currency conversion for entries and transfers; AED remains the master ledger currency and original amount/currency/rate are retained in transaction records.
- Professional portrait PDF statements with balanced tables and Nadeem Siddiqui / ندیم صدیقی footer on every page.
- Existing Mess share calculation, storage keys, backup/restore, and Android safe-area behavior retained.
