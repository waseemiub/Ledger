Ledger Calculation PWA V1
Offline-first ledger using localStorage.
ADD increases party balance; SUBTRACT decreases it.
Positive = My Receivables; negative = My Payments.
Zero-balance parties disappear from active overview and New Entry dropdown while full history is retained.
Includes party statement, full/party CSV and PDF printing, JSON backup/restore.
Use Backup Ledger regularly because clearing browser/app data can remove locally stored records.
