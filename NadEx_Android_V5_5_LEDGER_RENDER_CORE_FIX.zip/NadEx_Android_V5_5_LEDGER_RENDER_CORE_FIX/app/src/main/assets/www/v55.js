/* NadEx V5.5 — core ledger renderer repair.
   Presentation-only: does not change transaction, balance, restore or expense calculations. */
(function(){
  'use strict';
  var baseRenderLedger = window.renderLedger;

  function currency(){ return (window.D && D.settings && D.settings.displayCurrency) || 'AED'; }
  function fmt(n){ return money(Math.abs(Number(n)||0)); }
  function byModified(a,b){ return (Number(b.modified)||0)-(Number(a.modified)||0); }

  function safePartyRows(id, rows, keepZero){
    var box=document.getElementById(id); if(!box)return;
    var arr=(rows||[]).filter(function(p){return keepZero || Math.abs(Number(p.balance)||0)>0.000001;}).slice().sort(byModified);
    box.innerHTML=arr.length?arr.map(function(p){
      var cur=currency(), txs=[];
      try{txs=typeof tx==='function'?tx(p.key):[];}catch(e){txs=[];}
      var tin=0,tout=0;
      txs.forEach(function(t){
        var v=Number(t.displayAmount!=null?t.displayAmount:(t.valueAmount!=null?t.valueAmount:t.amount))||0;
        if(t.kind==='add')tin+=v; else tout+=v;
      });
      var meaning=p.wallet?'Available balance':p.balance>0?'You will receive':p.balance<0?'You owe':'Settled';
      return '<article class="account-overview-card v55-party" data-k="'+esc(p.key)+'">'+
       '<div class="account-overview-top"><div><small>'+esc(meaning)+'</small><h3>'+esc(p.name)+'</h3></div><b class="'+(p.balance>0?'pos':p.balance<0?'neg':'neu')+'">'+cur+' '+fmt(p.balance)+'</b></div>'+
       '<div class="account-overview-stats"><span><small>TOTAL IN</small><b>'+cur+' '+money(tin)+'</b></span><span><small>TOTAL OUT</small><b>'+cur+' '+money(tout)+'</b></span><span><small>ENTRIES</small><b>'+txs.length+'</b></span></div>'+
       '<div class="account-overview-foot"><span>'+(p.modified?new Date(p.modified).toLocaleString():(p.wallet?'Available account':'No activity'))+'</span><b>View statement ›</b></div></article>';
    }).join(''):'<div class="empty">None</div>';
    box.querySelectorAll('[data-k]').forEach(function(el){el.onclick=function(){party(el.getAttribute('data-k'));};});
  }

  function renderExpense(){
    var box=document.getElementById('expenseAccount'); if(!box)return;
    var x={items:[],total:0}; try{x=myExpenseData();}catch(e){}
    var cur=currency(),last=x.items&&x.items.length?x.items[x.items.length-1].ts:0;
    box.innerHTML='<article class="account-overview-card v55-party" data-myexpense="1">'+
      '<div class="account-overview-top"><div><small>Personal spending</small><h3>My Expense</h3></div><b class="neg">'+cur+' '+money(Number(x.total)||0)+'</b></div>'+
      '<div class="account-overview-stats"><span><small>TOTAL</small><b>'+cur+' '+money(Number(x.total)||0)+'</b></span><span><small>ENTRIES</small><b>'+((x.items||[]).length)+'</b></span><span><small>LATEST</small><b>'+(last?new Date(last).toLocaleDateString():'—')+'</b></span></div>'+
      '<div class="account-overview-foot"><span>Monthly Expense linked</span><b>View statement ›</b></div></article>';
    var el=box.querySelector('[data-myexpense]'); if(el)el.onclick=function(){party(MY_EXPENSE_VIEW_KEY);};
  }

  function setHead(cls,label,value,isExpense){
    var head=document.querySelector('.group.'+cls+' .fold-head'); if(!head)return;
    var num=head.querySelector('span:first-child'); var n=num?num.textContent:'';
    head.innerHTML='<span>'+esc(n)+'</span><span class="section-name">'+esc(label)+'</span><span class="section-total"><small>'+(isExpense?'TOTAL':'BALANCE')+'</small>'+currency()+' '+fmt(value)+'</span><i class="fold-arrow">⌄</i>';
    head.setAttribute('role','button'); head.setAttribute('tabindex','0');
    var toggle=function(){head.parentElement.classList.toggle('collapsed');};
    head.onclick=toggle;
    head.onkeydown=function(e){if(e.key==='Enter'||e.key===' '){e.preventDefault();toggle();}};
  }

  function repairLedger(){
    var s=[]; try{s=states();}catch(e){return;}
    var wallets=s.filter(function(p){return !!p.wallet;});
    var others=s.filter(function(p){return !p.wallet && p.key!==EXPENSE_KEY;});
    var share=s.find(function(p){return p.key===EXPENSE_KEY;}) || {key:EXPENSE_KEY,name:EXPENSE_NAME,balance:0,modified:0,wallet:false};
    var pay=others.filter(function(p){return Number(p.balance)<-0.000001;});
    var rec=others.filter(function(p){return Number(p.balance)>0.000001;});
    var receivableRows=[share].concat(rec);
    safePartyRows('payments',pay,false);
    safePartyRows('receivables',receivableRows,true);
    safePartyRows('wallets',wallets,true);
    renderExpense();
    var payTotal=pay.reduce(function(n,p){return n+Math.abs(Number(p.balance)||0);},0)+Math.max(-(Number(share.balance)||0),0);
    var recTotal=rec.reduce(function(n,p){return n+(Number(p.balance)||0);},0)+Math.max(Number(share.balance)||0,0);
    var walletTotal=wallets.reduce(function(n,p){return n+(Number(p.balance)||0);},0);
    var expenseTotal=0; try{expenseTotal=Number(myExpenseData().total)||0;}catch(e){}
    setHead('pay','Money I Owe',payTotal,false);
    setHead('rec','Money I Will Get',recTotal,false);
    setHead('wallet','Money With Me',walletTotal,false);
    setHead('expense','My Expense',expenseTotal,true);
  }

  window.renderLedger=function(){
    if(typeof baseRenderLedger==='function') baseRenderLedger();
    repairLedger();
  };
  window.nadexRepairLedger=repairLedger;
  if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',function(){window.renderLedger();});
  else window.renderLedger();
})();
