/* NadEx V5.2 — presentation refresh + expense/ledger consistency */
(()=>{
  const oldList=list;
  list=function(id,a,showZero=false){
    const dc=(D.settings&&D.settings.displayCurrency)||'AED';
    const arr=(showZero?a:a.filter(p=>Math.abs(p.balance)>.000001)).slice().sort((x,y)=>(y.modified||0)-(x.modified||0));
    $(id).innerHTML=arr.length?arr.map(p=>{
      const data=tx(p.key), tin=data.filter(t=>t.kind==='add').reduce((n,t)=>n+Number(t.displayAmount??t.amount??0),0), tout=data.filter(t=>t.kind==='subtract').reduce((n,t)=>n+Number(t.displayAmount??t.amount??0),0);
      const rem=(!p.wallet&&p.balance<0)?remainingOweLimit(p.key,p.balance):null;
      const meaning=p.wallet?'Available balance':p.balance>0?'You will receive':p.balance<0?'You owe':'Settled';
      return `<article class="account-overview-card" data-k="${esc(p.key)}">
        <div class="account-overview-top"><div><small>${esc(meaning)}</small><h3>${esc(p.name)}</h3></div><b class="${p.balance>0?'pos':p.balance<0?'neg':'neu'}">${dc} ${money(Math.abs(p.balance))}</b></div>
        <div class="account-overview-stats"><span><small>TOTAL IN</small><b>${dc} ${money(tin)}</b></span><span><small>TOTAL OUT</small><b>${dc} ${money(tout)}</b></span><span><small>ENTRIES</small><b>${data.length}</b></span></div>
        ${rem==null?'':`<div class="overview-limit">Remaining limit: ${dc} ${money(rem)}</div>`}
        <div class="account-overview-foot"><span>${p.modified?new Date(p.modified).toLocaleString():(p.wallet?'Available account':'No activity')}</span><b>View statement ›</b></div>
      </article>`
    }).join(''):'<div class="empty">None</div>';
    $(id).querySelectorAll('[data-k]').forEach(r=>r.onclick=()=>party(r.dataset.k));
  };

  const oldRenderMess=renderMess;
  renderMess=function(){
    oldRenderMess();
    const {stats}=messStats(),dc=(D.settings&&D.settings.displayCurrency)||'AED',box=$('memberSummary');
    if(!box)return;
    box.innerHTML=[...stats.values()].filter(x=>x.paid||x.share||x.member.active).map(x=>{
      const meaning=x.balance>0?'Expense cycle owes':x.balance<0?'Member owes cycle':'Balanced';
      return `<article class="member-overview-card">
        <div class="member-overview-top"><div><small>${meaning}</small><h3>${esc(x.member.name)}</h3></div><b class="${x.balance>0?'pos':x.balance<0?'neg':'neu'}">${x.balance>0?'+ ':x.balance<0?'− ':''}${dc} ${money(Math.abs(x.balance))}</b></div>
        <div class="member-overview-stats"><span><small>PAID</small><b>${dc} ${money(x.paid)}</b></span><span><small>SHARE</small><b>${dc} ${money(x.share)}</b></span><span><small>BALANCE</small><b class="${x.balance>0?'pos':x.balance<0?'neg':'neu'}">${dc} ${money(Math.abs(x.balance))}</b></span></div>
      </article>`
    }).join('');
  };

  // v5.2 has no aggregate balance/position block on Ledger. Keep render logic safe
  // for older functions that still try to write to those removed elements.
  const native$=$;
  window.$=function(id){
    const el=native$(id);
    if(el)return el;
    if(['bal','meaning','balanceChange','balanceChangeAmount','balanceChangeBar','walletTotal','receivableTotal','payableTotal','homeMainBalance','homeWallet','homePayable','homeReceivable','homeCurrencyLabel','homeMainBalanceRow'].includes(id)){
      return {textContent:'',className:'',style:{},classList:{add(){},remove(){},toggle(){}},addEventListener(){},setAttribute(){}};
    }
    return el;
  };
  renderLedger();renderMess();
})();
