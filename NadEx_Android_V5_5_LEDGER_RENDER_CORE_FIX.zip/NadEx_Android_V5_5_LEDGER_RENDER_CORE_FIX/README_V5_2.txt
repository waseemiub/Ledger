NadEx V5.2
- Home: removed Total Position and financial snapshot/overview values; retained family artwork and reorganized workspace.
- Ledger: removed Main Balance and three-position summary from top.
- Ledger account overview redesigned as statement-style cards with balance, Total In, Total Out, entry count and latest activity.
- Monthly Expense Overview redesigned as matching member statement-style cards.
- Fixed My Share linked-account mismatch: accounting/display value now uses stored valueAmount/amount before original purchase amount. This prevents full purchase originalAmount from replacing the member's actual split share.
- Existing storage keys, transactions, purchases, members, cycles and calculations otherwise preserved.
