NadEx V5.3 Compact Responsive
- Home family artwork zoomed out with object-fit contain so full artwork is visible.
- Ledger category cards show live section balances/totals while collapsed and remain full-row touch targets.
- Monthly Expense purchases changed to compact linear transaction rows.
- Monthly Expense member overview changed to compact statement-style rows.
- V5.2 My Share / Monthly Expense synchronization correction retained.
- Existing data model, calculations, backup/restore, transaction logic and package ID preserved.
