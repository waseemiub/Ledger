NadEx V5.1 — Clean Modern Redesign

This release rebuilds only the visual design and layout layer from scratch.
Financial functions, calculations, storage keys, ledger logic, multi-currency logic, party limits, expense-cycle/member logic, exports, backup and restore are preserved from V5.0.

Navigation:
- Dedicated in-app Back button on Ledger, Monthly Expenses and Party Statement screens.
- Party Statement returns to Ledger, or to Monthly Expenses for My Expense.
- Android system back/gesture is not required for primary navigation.

Application ID: ae.transactor.app
versionCode: 51
versionName: 5.1
