NadEx V5.4 — Restore-Safe Ledger Rendering

Fixes the V5.3 regression where restored data existed but expanded Ledger categories appeared blank.
- Ledger category bodies are rebuilt directly from the restored transaction state on every render.
- Section totals remain visible and refresh after restore/transactions.
- Full category header remains touch responsive.
- Party cards retain current balance, Total In, Total Out, Entries and latest activity.
- My Share remains in Money I Will Get and keeps the V5.2 Monthly Expense synchronization correction.
- My Expense section renders its linked expense statement card.
- No transaction, backup schema, monthly expense calculation, or account logic was changed.
Version 5.4 / versionCode 54.
