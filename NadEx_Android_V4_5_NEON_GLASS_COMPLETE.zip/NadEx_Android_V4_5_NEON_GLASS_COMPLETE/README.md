NadEx Android V4.5 — Complete Neon Glass Theme

- One neon-glass transparent theme across Home, Ledger, Monthly Expenses, party statements and all modal/pop-up forms.
- Family-only artwork retained as dissolved hero/watermark; no Urdu child-name overlay.
- Home family hero is controlled to the upper portion of the usable app viewport.
- High-contrast text protection over all transparent surfaces.
- Backup/Restore remain on Home only.
- Latest balance movement: green increase, red decrease, white neutral, no white rectangle.
- Android WebView remains inside status/navigation bar safe insets.
- Android back gesture closes modal first, then navigates Party -> Ledger/Expense -> Home, then exits from Home.
- Existing NadEx accounting, multi-currency, party limits, expense and backup data logic preserved.
