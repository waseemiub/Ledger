NadEx V4.4 Mockup Theme Complete
- Full app viewport remains inside Android system status/navigation bars.
- Home rebuilt to match approved neon-glass mockup proportions.
- Family hero sits at top at controlled size and dissolves into navy background.
- No names over family image.
- Backup/Restore only on Home; removed visually from Ledger/Expense screens.
- Restore confirmation/result dialogs use NadEx transparent glass theme.
- Inner screens use protected transparent glass panels over subtle family watermark.
- Latest movement indicator has no white background: green increase, red decrease, white neutral.
- Existing ledger, expenses, multi-currency, party limits, backup data keys and Android back navigation retained.
