# NadEx Android V6.1
Minimal universal transaction entry and numbers-only presentation.
Version 6.1 / versionCode 61 / applicationId ae.transactor.app.
Existing local data keys and records are preserved.
