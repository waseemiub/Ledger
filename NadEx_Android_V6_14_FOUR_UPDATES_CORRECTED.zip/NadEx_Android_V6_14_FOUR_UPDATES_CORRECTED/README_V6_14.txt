NadEx V6.14 — Four requested updates corrected
VersionCode 74 / VersionName 6.14

V6.13 runtime patch is removed from index.html and is not executed.

1. Monthly Expense
- Purchases paid by the user where the user is the only involved member are hidden from Monthly Expense:
  purchase list, Total Spend, member summary, CSV and PDF.
- Those records are NOT deleted.
- Ledger > My Expense still uses all allocations belonging to the user from M.purchases,
  so personal-only purchases remain in My Expense together with all other Monthly Expense shares
  and direct Ledger My Expense transactions.

2. Delete
- Monthly Expense purchase delete rebuilt at the actual Purchase Details and purchase-list handlers.
- Removes purchase plus linked messId/transfer records, persists both stores, verifies storage.
- Ledger transaction delete also uses in-app confirmation and storage verification.

3. Party dropdown management
- Open any non-wallet party statement and tap Manage Party.
- Rename party OR Remove from Dropdown / Show in Dropdown.
- No separate page.
- Removing from dropdown does not delete the party, balance, or history.
- New Transaction dropdown is generated from the saved hidden-party state.

4. Main Ledger Balance Statement
- Preserved from the working V6.13 behavior.

No existing user data is migrated or erased.
