
/* NadEx V6.14 — exact correction of the four requested updates.
   V6.13 runtime patch is intentionally NOT loaded.
   No accounting records are migrated or deleted on install. */
(function(){
'use strict';

const V14=id=>document.getElementById(id);
const n14=v=>Number.isFinite(Number(v))?Number(v):0;
const r14=v=>Math.round(n14(v)*100)/100;
const f14=v=>{try{return money(Math.abs(n14(v)))}catch(e){return Math.abs(n14(v)).toFixed(2)}};
const saveLedger14=()=>localStorage.setItem(K,JSON.stringify(D));
const saveMess14=()=>localStorage.setItem(MK,JSON.stringify(M));

/* ============================================================
   1) MONTHLY EXPENSE:
      hide "paid by me + only me involved" from Monthly Expense,
      WITHOUT deleting it. Ledger > My Expense still sees it
      because V6.9 reads directly from M.purchases.
   ============================================================ */

function personalOnly14(p){
  if(!p)return false;
  const myId=me().id;
  if(String(p.paidBy)!==String(myId))return false;
  const involved=(p.allocations||[]).filter(a=>n14(a.amount)>0.000001);
  return involved.length===1 && String(involved[0].memberId)===String(myId);
}
function cyclePurchasesAll14(){
  const c=activeCycle();
  return (M.purchases||[]).filter(p=>!c || !p.cycleId || p.cycleId===c.id);
}
function monthlyVisible14(){
  return cyclePurchasesAll14().filter(p=>!personalOnly14(p)).sort((a,b)=>(b.ts||0)-(a.ts||0));
}

/* This is the actual function renderMess consumes. */
window.messStats=function(){
  const ps=monthlyVisible14();
  const stats=new Map((M.members||[]).map(m=>[m.id,{member:m,paid:0,share:0,balance:0}]));
  ps.forEach(p=>{
    const payer=stats.get(p.paidBy);
    if(payer)payer.paid=r14(payer.paid+n14(p.amount));
    (p.allocations||[]).forEach(a=>{
      const x=stats.get(a.memberId);
      if(x)x.share=r14(x.share+n14(a.amount));
    });
  });
  stats.forEach(x=>x.balance=r14(x.paid-x.share));
  return {ps,stats,total:r14(ps.reduce((a,p)=>a+n14(p.amount),0))};
};

/* Replace the actual Monthly Expense renderer rather than post-render patching. */
window.renderMess=function(){
  const c=activeCycle(), z=window.messStats(), ps=z.ps, stats=z.stats, total=z.total;
  const mine=stats.get(me().id)||{balance:0};

  V14('messMonthLabel').textContent=cycleLabel(c);
  V14('cycleTitle').textContent=cycleLabel(c);
  V14('monthExpense').textContent=money(total);
  V14('myMessBalance').textContent=(mine.balance>=0?'+ ':'- ')+money(Math.abs(mine.balance));
  V14('myMessBalance').className=mine.balance>0?'pos':mine.balance<0?'neg':'neu';
  V14('myMessMeaning').textContent=mine.balance>0?'Mess owes you':mine.balance<0?'You owe Mess':'Balanced';

  V14('purchaseList').innerHTML=ps.length?ps.map(p=>{
    const payer=M.members.find(m=>m.id===p.paidBy)?.name||'Unknown';
    const names=(p.allocations||[]).filter(a=>n14(a.amount)>0.000001)
      .map(a=>M.members.find(m=>m.id===a.memberId)?.name||'Member').join(', ');
    return '<div class="purchase">'+
      '<div class="purchase-top"><div><h3>'+esc(p.description||'Mess Purchase')+'</h3>'+
      '<div class="meta">'+new Date(p.ts).toLocaleString()+' · Paid by '+esc(payer)+'</div></div>'+
      '<div class="total">'+money(p.amount)+'</div></div>'+
      '<div class="split">'+(p.splitMode==='equal'?'Equal':'Individual')+' split · '+esc(names)+'</div>'+
      '<div class="pactions"><button type="button" data-viewp="'+esc(p.id)+'">Details</button>'+
      '<button type="button" data-editp="'+esc(p.id)+'">Edit</button>'+
      '<button type="button" data-delp="'+esc(p.id)+'">Delete</button></div></div>';
  }).join(''):'<div class="empty">No purchases in this cycle</div>';

  V14('purchaseList').querySelectorAll('[data-viewp]').forEach(b=>b.onclick=e=>{
    e.preventDefault();e.stopPropagation();window.purchaseDetails(b.dataset.viewp);
  });
  V14('purchaseList').querySelectorAll('[data-editp]').forEach(b=>b.onclick=e=>{
    e.preventDefault();e.stopPropagation();openPurchase({editId:b.dataset.editp});
  });
  V14('purchaseList').querySelectorAll('[data-delp]').forEach(b=>b.onclick=e=>{
    e.preventDefault();e.stopPropagation();window.deletePurchase(b.dataset.delp);
  });

  V14('memberSummary').innerHTML=[...stats.values()]
    .filter(x=>x.paid||x.share||x.member.active)
    .map(x=>'<tr><td>'+esc(x.member.name)+'</td><td>'+money(x.paid)+'</td><td>'+money(x.share)+'</td>'+
      '<td class="'+(x.balance>0?'pos':x.balance<0?'neg':'neu')+'">'+(x.balance>0?'+':'')+money(x.balance)+'</td></tr>').join('');

  renderMembers();

  /* Preserve the already-working entry buttons and PDF button. */
  const np=V14('newPurchase'), npt=V14('newPurchaseTop');
  if(np)np.onclick=e=>{e.preventDefault();openPurchase({})};
  if(npt)npt.onclick=e=>{e.preventDefault();openPurchase({})};
  document.querySelectorAll('#messView button').forEach(b=>{
    const t=(b.textContent||'').trim().toLowerCase();
    if(t.includes('pdf')||t.includes('statement'))b.onclick=e=>{e.preventDefault();window.exportMessPDF()};
  });

  /* V6.1 numbers-only presentation. */
  const rx=/\b(?:AED|USD|EUR|GBP|PKR|INR|SAR|QAR|KWD|BHD|OMR|JPY|CNY|CAD|AUD)\s+/g;
  document.querySelectorAll('#messView #monthExpense,#messView #myMessBalance,#messView .purchase .total')
    .forEach(el=>{if(!el.children.length)el.textContent=el.textContent.replace(rx,'').trim()});
};

/* CSV and PDF use the SAME filtered Monthly Expense dataset. */
window.messRows=function(){
  return monthlyVisible14().slice().reverse().flatMap(p=>(p.allocations||[]).map(a=>[
    new Date(p.ts).toLocaleDateString(),new Date(p.ts).toLocaleTimeString(),p.id,p.description,
    M.members.find(m=>m.id===p.paidBy)?.name||'',p.amount,
    M.members.find(m=>m.id===a.memberId)?.name||'',a.amount,p.splitMode
  ]));
};

window.exportMessPDF=function(){
  const c=activeCycle(), ps=monthlyVisible14().slice().reverse(), z=window.messStats();
  const summary=(M.members||[]).filter(m=>m.active||z.stats.has(m.id)).map(m=>{
    const x=z.stats.get(m.id)||{paid:0,share:0,balance:0};
    return '<tr><td>'+esc(m.name)+'</td><td>'+f14(x.paid)+'</td><td>'+f14(x.share)+'</td>'+
      '<td>'+f14(x.balance)+'</td><td>'+(x.balance>0?'To receive':x.balance<0?'To pay':'Settled')+'</td></tr>';
  }).join('');
  const details=ps.map((p,i)=>{
    const payer=M.members.find(m=>m.id===p.paidBy)?.name||'Unknown';
    const alloc=(p.allocations||[]).filter(a=>n14(a.amount)>0.000001).map(a=>
      '<tr><td>'+esc(M.members.find(m=>m.id===a.memberId)?.name||'Member')+'</td><td>'+f14(a.amount)+'</td></tr>'
    ).join('');
    return '<section><h3>'+(i+1)+'. '+esc(p.description||'Purchase')+'</h3>'+
      '<p><b>Date/Time:</b> '+new Date(p.ts).toLocaleString()+
      ' &nbsp; <b>Paid by:</b> '+esc(payer)+
      ' &nbsp; <b>Total:</b> '+f14(p.amount)+
      ' &nbsp; <b>Split:</b> '+esc(p.splitMode||'equal')+'</p>'+
      '<table><tr><th>Member involved</th><th>Share</th></tr>'+alloc+'</table></section>';
  }).join('');
  const html='<!doctype html><html><head><meta charset="utf-8"><style>'+
    '@page{size:A4;margin:12mm}body{font-family:Arial,sans-serif;color:#111;font-size:11pt}'+
    'table{width:100%;border-collapse:collapse;margin:6px 0 14px}th,td{border:1px solid #888;padding:6px;text-align:left}'+
    'th{background:#eee}section{break-inside:avoid}</style></head><body>'+
    '<h1>NadEx Monthly Expense Statement</h1><p>Cycle: '+esc(c?.name||'Current')+
    ' | Generated: '+new Date().toLocaleString()+'</p>'+
    '<h2>Summary</h2><p><b>Total transactions:</b> '+ps.length+
    ' &nbsp; | &nbsp; <b>Total spend:</b> '+f14(z.total)+'</p>'+
    '<table><tr><th>Member</th><th>Paid</th><th>Share</th><th>Net Balance</th><th>Status</th></tr>'+
    summary+'</table><h2>Complete Transaction Details</h2>'+details+'</body></html>';

  if(window.AndroidBridge&&typeof AndroidBridge.printHtml==='function'){
    AndroidBridge.printHtml(html,'NadEx Monthly Expense');
  }else alert('Android PDF service is unavailable in this installation.');
};

/* ============================================================
   2) DELETE:
      direct working delete for Monthly Expense AND Ledger.
   ============================================================ */

window.deletePurchase=function(id){
  const p=(M.purchases||[]).find(x=>String(x.id)===String(id));
  if(!p)return alert('Purchase not found.');

  nxConfirm('Delete Purchase?',
    (p.description||'This purchase')+' will be permanently removed.',
    'DELETE',()=>{
      try{
        M.purchases=M.purchases.filter(x=>String(x.id)!==String(id));
        D.transactions=D.transactions.filter(t=>{
          if(String(t.messId||'')===String(id))return false;
          if(p.transferId && t.transferId===p.transferId)return false;
          return true;
        });
        saveMess14();saveLedger14();

        const verify=JSON.parse(localStorage.getItem(MK)||'{}');
        if((verify.purchases||[]).some(x=>String(x.id)===String(id)))
          throw new Error('Purchase remained in storage.');

        close();window.renderMess();renderLedger();setMessTab('purchases');
      }catch(err){
        console.error('V6.14 purchase delete',err);
        alert('Delete failed: '+(err.message||'Unknown error'));
      }
    });
};

window.purchaseDetails=function(id){
  const p=(M.purchases||[]).find(x=>String(x.id)===String(id)); if(!p)return alert('Purchase not found.');
  const payer=M.members.find(m=>m.id===p.paidBy)?.name||'Unknown';
  modal('Purchase Details',
    '<div class="themed-dialog"><div class="dialog-icon">▤</div><h3>'+esc(p.description||'Purchase')+'</h3>'+
    '<p>'+new Date(p.ts).toLocaleString()+'</p></div>'+
    '<p>Paid by: <b>'+esc(payer)+'</b><br>Total: <b>'+money(p.amount)+'</b><br>Split: '+
    (p.splitMode==='equal'?'Equal':'Individual')+'</p>'+
    '<div class="table"><table><tr><th>Member</th><th>Share</th></tr>'+
    (p.allocations||[]).map(a=>'<tr><td>'+esc(M.members.find(m=>m.id===a.memberId)?.name||'Member')+
    '</td><td>'+money(a.amount)+'</td></tr>').join('')+'</table></div>'+
    '<div class="opts two"><button type="button" id="v14EditPurchase" class="primary">EDIT PURCHASE</button>'+
    '<button type="button" id="v14DeletePurchase" class="danger">DELETE PURCHASE</button></div>'
  );
  V14('v14EditPurchase').onclick=e=>{e.preventDefault();close();openPurchase({editId:id})};
  V14('v14DeletePurchase').onclick=e=>{e.preventDefault();e.stopPropagation();window.deletePurchase(id)};
};

/* Rebuild Ledger transaction actions using the proven V6.3 model, but route
   linked Monthly Expense delete through the V6.14 delete above. */
function linked14(t){
  if(t.transferId)return D.transactions.filter(x=>x.transferId===t.transferId);
  if(t.movementId)return D.transactions.filter(x=>x.movementId===t.movementId);
  return [t];
}
function dt14(ts){
  const d=new Date(Number(ts)||Date.now()),p=v=>String(v).padStart(2,'0');
  return {date:d.getFullYear()+'-'+p(d.getMonth()+1)+'-'+p(d.getDate()),time:p(d.getHours())+':'+p(d.getMinutes())};
}
window.transactionActions=function(id){
  const t=D.transactions.find(x=>String(x.id)===String(id));
  if(!t)return alert('Transaction not found.');

  if(t.messId){
    const p=M.purchases.find(x=>String(x.id)===String(t.messId));
    modal('Expense-linked Transaction',
      '<div class="note">This entry is controlled by its Monthly Expense purchase.</div>'+
      '<div class="opts two"><button type="button" id="v14ExpenseEdit">EDIT EXPENSE</button>'+
      '<button type="button" id="v14ExpenseDelete" class="danger">DELETE EXPENSE</button></div>');
    V14('v14ExpenseEdit').onclick=()=>{close();p?openPurchase({editId:p.id}):alert('Linked expense was not found.')};
    V14('v14ExpenseDelete').onclick=()=>{p?window.deletePurchase(p.id):alert('Linked expense was not found.')};
    return;
  }

  const rows=linked14(t), pair=rows.length>1, dp=dt14(t.ts), returnKey=t.partyKey;
  modal(pair?'Edit Linked Transaction':'Edit Transaction',
    '<div class="field"><label>Amount</label><input id="v14Amount" type="number" inputmode="decimal" min=".01" step=".01" value="'+esc(n14(t.amount))+'"></div>'+
    '<div class="field"><label>Description</label><textarea id="v14Desc">'+esc(t.description||'')+'</textarea></div>'+
    '<div class="field"><label>Date</label><input id="v14Date" type="date" value="'+dp.date+'"></div>'+
    '<div class="field"><label>Time</label><input id="v14Time" type="time" value="'+dp.time+'"></div>'+
    (pair?'<div class="linked">Amount and date/time update both linked sides.</div>':'')+
    '<div class="opts two"><button type="button" id="v14SaveTx" class="primary">SAVE CHANGES</button>'+
    '<button type="button" id="v14DeleteTx" class="danger">DELETE</button></div>'
  );

  V14('v14SaveTx').onclick=e=>{
    e.preventDefault();e.stopPropagation();
    const amt=r14(V14('v14Amount').value);
    if(!(amt>0))return alert('Enter a valid amount.');
    const nts=new Date(V14('v14Date').value+'T'+V14('v14Time').value+':00').getTime();
    if(!Number.isFinite(nts))return alert('Enter a valid date and time.');
    rows.forEach((x,i)=>{x.amount=amt;x.ts=nts+i;if('originalAmount'in x)x.originalAmount=amt;if('aedAmount'in x)x.aedAmount=amt});
    t.description=String(V14('v14Desc').value||'').trim();
    saveLedger14();close();renderLedger();party(returnKey);
  };

  V14('v14DeleteTx').onclick=e=>{
    e.preventDefault();e.stopPropagation();
    nxConfirm(pair?'Delete Linked Transaction?':'Delete Transaction?',
      pair?'Both linked sides will be removed.':'This transaction will be permanently removed.',
      'DELETE',()=>{
        const ids=new Set(rows.map(x=>String(x.id)));
        D.transactions=D.transactions.filter(x=>!ids.has(String(x.id)));
        saveLedger14();
        const saved=JSON.parse(localStorage.getItem(K)||'{}');
        if((saved.transactions||[]).some(x=>ids.has(String(x.id))))
          return alert('Delete verification failed.');
        close();renderLedger();party(returnKey);
      });
  };
};

/* ============================================================
   3) PARTY MANAGEMENT:
      Manage directly from the existing party statement.
      Rename or Hide/Show in dropdown. No new page.
   ============================================================ */

function hiddenParties14(){
  if(!Array.isArray(D.hiddenParties))D.hiddenParties=[];
  return D.hiddenParties;
}
function hidden14(k){return hiddenParties14().includes(key(k))}
function setHidden14(k,val){
  k=key(k);
  D.hiddenParties=hiddenParties14().filter(x=>x!==k);
  if(val)D.hiddenParties.push(k);
  saveLedger14();
}
function partyState14(k){return states().find(x=>x.key===key(k))}

window.manageParty14=function(k){
  k=key(k);
  const p=partyState14(k);
  if(!p||p.wallet||k===EXPENSE_KEY)return;
  const isHidden=hidden14(k);
  modal('Manage Party',
    '<div class="field"><label>Party Name</label><input id="v14PartyName" value="'+esc(p.name)+'"></div>'+
    '<div class="note">Rename changes this party name throughout its existing Ledger history. '+
    'Hide removes it only from New Transaction dropdown suggestions; its balance and history stay safe.</div>'+
    '<div class="opts two"><button type="button" id="v14RenameParty" class="primary">SAVE NAME</button>'+
    '<button type="button" id="v14ToggleParty">'+(isHidden?'SHOW IN DROPDOWN':'REMOVE FROM DROPDOWN')+'</button></div>'
  );

  V14('v14RenameParty').onclick=()=>{
    const name=String(V14('v14PartyName').value||'').trim().replace(/\s+/g,' ');
    if(!name)return alert('Enter a party name.');
    const nk=key(name);
    if(isWalletKey(nk)||nk===EXPENSE_KEY)return alert('Choose a different party name.');
    const exists=states().find(x=>x.key===nk&&x.key!==k);
    if(exists)return alert('A party with this name already exists.');

    D.transactions.forEach(t=>{
      if(canonicalPartyKey(t)===k){t.partyKey=nk;t.party=name}
    });
    if(D.partyLimits&&Object.prototype.hasOwnProperty.call(D.partyLimits,k)){
      D.partyLimits[nk]=D.partyLimits[k];delete D.partyLimits[k];
    }
    if(hidden14(k)){
      D.hiddenParties=hiddenParties14().filter(x=>x!==k);
      D.hiddenParties.push(nk);
    }
    saveLedger14();close();renderLedger();party(nk);
  };

  V14('v14ToggleParty').onclick=()=>{
    setHidden14(k,!isHidden);close();renderLedger();party(k);
  };
};

function addPartyManageButton14(k){
  const p=partyState14(k);
  const actions=document.querySelector('#partyView .statement-actions');
  if(!actions)return;
  const old=V14('v14ManageParty');if(old)old.remove();
  if(!p||p.wallet||k===EXPENSE_KEY||k===MY_EXPENSE_VIEW_KEY)return;
  const b=document.createElement('button');
  b.id='v14ManageParty';b.type='button';b.textContent='Manage Party';
  b.onclick=e=>{e.preventDefault();e.stopPropagation();window.manageParty14(k)};
  actions.appendChild(b);
}

/* Override New Transaction itself so hidden parties are excluded at source. */
window.ledgerEntry=function(){
  const hidden=new Set(hiddenParties14());
  const accounts=states().filter(p=>!hidden.has(p.key))
    .slice().sort((a,b)=>(!!b.wallet-!!a.wallet)||a.name.localeCompare(b.name));
  const opts=accounts.map(p=>'<option value="'+esc(p.name)+'"></option>').join('');

  modal('New Transaction',
    '<datalist id="nxAccounts">'+opts+
    '<option value="External / No Account"></option><option value="My Expense"></option></datalist>'+
    '<div class="nx-entry">'+
    '<div class="field nx-amount"><label>Amount</label><input id="nxAmount" type="number" inputmode="decimal" min=".01" step=".01" placeholder="0.00"></div>'+
    '<div class="field"><label>Action</label><div class="nx-toggle"><button type="button" id="nxWithdraw" class="active">WITHDRAW</button><button type="button" id="nxDeposit">DEPOSIT</button></div></div>'+
    '<div class="field"><label id="nxPrimaryLabel">Withdraw From</label><input id="nxPrimary" list="nxAccounts" placeholder="Select any account or party"></div>'+
    '<div class="field"><label id="nxOtherLabel">Paid To / For</label><input id="nxOther" list="nxAccounts" placeholder="Select party, account, My Expense or External"></div>'+
    '<div class="field"><label>Description <small>(optional)</small></label><textarea id="nxDesc" placeholder="What was this transaction for?"></textarea></div>'+
    '<button id="nxSave" class="primary wide">SAVE TRANSACTION</button>'+
    '<div class="nx-rule"><b>Automatic accounting</b><span>NadEx decides Money I Owe or Money I Will Get from the resulting party balance. You only record where the amount moved.</span></div></div>'
  );
  let mode='withdraw';
  const paint=()=>{
    V14('nxWithdraw').classList.toggle('active',mode==='withdraw');
    V14('nxDeposit').classList.toggle('active',mode==='deposit');
    V14('nxPrimaryLabel').textContent=mode==='withdraw'?'Withdraw From':'Deposit Into';
    V14('nxOtherLabel').textContent=mode==='withdraw'?'Paid To / For':'Received From';
  };
  V14('nxWithdraw').onclick=()=>{mode='withdraw';paint()};
  V14('nxDeposit').onclick=()=>{mode='deposit';paint()};
  V14('nxSave').onclick=()=>window.saveUniversal(mode);
  paint();
};

/* Wrap the actual party function once: keep its existing statement exactly,
   then add the small Manage Party action to that same screen. */
const partyBefore14=window.party;
window.party=function(k){
  const result=partyBefore14.apply(this,arguments);
  setTimeout(()=>addPartyManageButton14(k),0);
  return result;
};

/* ============================================================
   4) MAIN LEDGER BALANCE STATEMENT:
      preserve the V6.13 feature that worked.
   ============================================================ */

function mainBalance14(){
  try{
    const s=states();
    const wallets=s.filter(x=>x.wallet).reduce((a,x)=>a+n14(x.balance),0);
    const parties=s.filter(x=>!x.wallet&&x.key!==EXPENSE_KEY).reduce((a,x)=>a+n14(x.balance),0);
    const ms=window.messStats(), mine=ms.stats.get(me().id);
    return r14(wallets+parties+n14(mine&&mine.balance));
  }catch(e){return 0}
}
window.openMainBalanceStatement=function(){
  const rows=(D.transactions||[]).filter(t=>!t.messId).slice().sort((a,b)=>(a.ts||0)-(b.ts||0));
  let running=0;
  const data=rows.map(t=>{
    const delta=t.kind==='add'?n14(t.amount):-n14(t.amount);
    running=r14(running+delta);
    return {t,delta,running};
  });
  modal('Main Ledger Balance Statement',
    '<div class="balance-card"><small>CURRENT MAIN LEDGER BALANCE</small><strong>'+f14(mainBalance14())+'</strong>'+
    '<span>'+data.length+' Ledger entries</span></div>'+
    '<div class="party-timeline">'+(data.length?data.slice().reverse().map(x=>
      '<div class="party-tx"><div><div class="pt-date">'+new Date(x.t.ts).toLocaleString()+'</div>'+
      '<div class="pt-desc">'+esc(x.t.description||'Transaction')+'</div><div class="pt-meta">'+esc(x.t.party||'Account')+'</div></div>'+
      '<div><div class="pt-amount '+(x.delta>=0?'pos':'neg')+'">'+(x.delta>=0?'+ ':'− ')+f14(Math.abs(x.delta))+'</div>'+
      '<div class="pt-balance">Running: '+f14(x.running)+'</div></div></div>'
    ).join(''):'<div class="empty">No Ledger transactions</div>')+'</div>'
  );
};
function mainStatementButton14(){
  const panel=V14('ledgerPositionV59');if(!panel)return;
  let b=V14('v14MainStatement');
  if(!b){
    b=document.createElement('button');b.id='v14MainStatement';b.type='button';b.textContent='Statement';
    b.style.cssText='margin-top:12px;width:100%;padding:11px 14px;border-radius:12px;border:1px solid rgba(148,163,184,.25);background:rgba(15,35,50,.75);color:inherit;font-weight:700;';
    panel.appendChild(b);
  }
  b.onclick=e=>{e.preventDefault();e.stopPropagation();window.openMainBalanceStatement()};
}

/* Final render wrappers only re-bind visible controls; calculations above are
   already connected at source. */
const renderLedgerBefore14=window.renderLedger;
window.renderLedger=function(){
  const v=renderLedgerBefore14.apply(this,arguments);
  mainStatementButton14();
  return v;
};

document.addEventListener('DOMContentLoaded',()=>{
  setTimeout(()=>{window.renderMess();mainStatementButton14()},50);
});
setTimeout(()=>{mainStatementButton14()},350);

})();
