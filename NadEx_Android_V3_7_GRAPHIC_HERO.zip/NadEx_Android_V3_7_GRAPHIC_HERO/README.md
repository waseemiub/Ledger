NadEx V3.7 GRAPHIC HERO
- Home hero uses only the graphical background artwork from the NadEx icon.
- No duplicate NadEx wording in the hero image.
- Preserves V3.6 white title, relocated owner card, bright ledger totals, and all financial logic.
