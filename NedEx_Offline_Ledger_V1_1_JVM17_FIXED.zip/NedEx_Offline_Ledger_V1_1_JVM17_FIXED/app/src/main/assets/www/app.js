const KEY="nedex_simple_ledger_v1";
const money=n=>"AED "+Number(n||0).toLocaleString(undefined,{minimumFractionDigits:2,maximumFractionDigits:2});
const uid=()=>Date.now().toString(36)+Math.random().toString(36).slice(2,7);
const now=()=>new Date().toISOString();
let tab="inhand";
let D=load();

function fresh(){
 return {parties:[
   {id:"cash",name:"Cash",type:"inhand",balance:0},
   {id:"myshare",name:"My Share",type:"special",balance:0}
 ],tx:[],cycle:{id:uid(),start:new Date().toISOString().slice(0,10),members:[{id:"me",name:"Me",isMe:true}],purchases:[]},archives:[]};
}
function load(){try{let x=JSON.parse(localStorage.getItem(KEY));return x&&x.parties?x:fresh()}catch(e){return fresh()}}
function save(){localStorage.setItem(KEY,JSON.stringify(D));renderAll()}
function party(id){return D.parties.find(x=>x.id===id)}
function parties(type){return D.parties.filter(x=>x.type===type)}
function totals(){
 const inh=parties("inhand").reduce((s,p)=>s+p.balance,0);
 const rec=parties("recv").reduce((s,p)=>s+p.balance,0);
 const owe=parties("owe").reduce((s,p)=>s+p.balance,0);
 const ms=party("myshare")?.balance||0;
 return {inh,rec:rec+Math.max(ms,0),owe:owe+Math.max(-ms,0),net:inh+rec-owe+ms};
}
function showView(id){document.querySelectorAll(".view").forEach(v=>v.classList.add("hidden"));document.getElementById(id).classList.remove("hidden");closeModal();window.scrollTo(0,0);renderAll()}
function setTab(t){tab=t;document.querySelectorAll(".tabs button").forEach(b=>b.classList.remove("active"));document.getElementById("tab-"+t)?.classList.add("active");renderLedger()}
function row(title,sub,amt,cls="neutral"){return `<div class="row"><div class="meta"><b>${esc(title)}</b><small>${esc(sub||"")}</small></div><div class="amount ${cls}">${money(amt)}</div></div>`}
function esc(s){return String(s??"").replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]))}
function renderAll(){
 const t=totals(); by("netPosition").textContent=money(t.net);by("sumIn").textContent=money(t.inh);by("sumRecv").textContent=money(t.recv);by("sumOwe").textContent=money(t.owe);
 by("recent").innerHTML=D.tx.slice(-5).reverse().map(x=>row(x.label,new Date(x.ts).toLocaleString(),x.amount,x.effect==="plus"?"pos":x.effect==="minus"?"neg":"neutral")).join("")||empty("No transactions yet");
 renderLedger();renderMonthly();
}
function renderLedger(){
 if(!by("ledger"))return;
 ["inhand","recv","owe"].forEach(t=>by("tab-"+t)?.classList.toggle("active",t===tab));
 const labels={inhand:["In Hand","Money available in cash, cards and wallets"],recv:["Receivables","People who owe money to you"],owe:["I Owe","People you owe money to"]};
 by("sectionTitle").textContent=labels[tab][0];by("sectionSub").textContent=labels[tab][1];
 let list=parties(tab).slice();
 const ms=party("myshare")?.balance||0;
 if(tab==="recv"&&ms>=0) list.push({id:"myshare",name:"My Share",balance:ms,type:"special"});
 if(tab==="owe"&&ms<0) list.push({id:"myshare",name:"My Share",balance:-ms,type:"special"});
 by("partyList").innerHTML=list.map(p=>row(p.name,p.id==="myshare"?"Linked to Monthly Expense":"Tap to manage",p.balance,tab==="owe"?"neg":tab==="recv"?"pos":"neutral")).join("")||empty("No parties in this section");
 by("transactions").innerHTML=D.tx.slice().reverse().map(x=>row(x.label,new Date(x.ts).toLocaleString(),x.amount,x.effect==="plus"?"pos":x.effect==="minus"?"neg":"neutral")).join("")||empty("No transactions yet");
}
function renderMonthly(){
 const c=D.cycle;by("cycleDate").textContent="Open since "+c.start;
 const ms=party("myshare").balance;by("myShare").textContent=(ms<0?"− ":"")+money(Math.abs(ms));by("myShare").className=ms>0?"pos":ms<0?"neg":"";
 by("shareMeaning").textContent=ms>0?"Monthly Expense owes you":ms<0?"You owe Monthly Expense":"Settled";
 by("members").innerHTML=c.members.map(m=>`<span class="memberChip">${esc(m.name)}${m.isMe?"":`<button onclick="removeMember('${m.id}')">×</button>`}</span>`).join("");
 by("purchases").innerHTML=c.purchases.slice().reverse().map(p=>row(p.description,`${p.payerName} • Your share ${money(p.myShare)}`,p.amount,"neutral")).join("")||empty("No purchases in this cycle");
}
function empty(s){return `<div class="empty">${esc(s)}</div>`} function by(id){return document.getElementById(id)}
function openModal(title,html){by("modalTitle").textContent=title;by("modalBody").innerHTML=html;by("modal").classList.remove("hidden")}
function closeModal(){by("modal").classList.add("hidden")}

function openParty(){
 openModal("Add Party",`<div class="field"><label>Section</label><select id="pType"><option value="${tab}">${tab==="inhand"?"In Hand":tab==="recv"?"Receivables":"I Owe"}</option></select></div><div class="field"><label>Party / Account name</label><input id="pName" placeholder="${tab==="inhand"?"e.g. Debit Card":"Name"}"></div><button class="save" onclick="addParty()">Add Party</button>`);
}
function addParty(){let name=by("pName").value.trim();if(!name)return;D.parties.push({id:uid(),name,type:tab,balance:0});save();closeModal()}

function openTransaction(){
 openModal("New Transaction",`<div class="field"><label>Transaction type</label><select id="txType" onchange="drawTxFields()"><option value="out">Send money out</option><option value="receive">Receive from receivable</option><option value="income">Add money from open source</option><option value="internal">Internal transfer: Receivable → I Owe</option><option value="borrow">Borrow / receive from someone I owe</option></select></div><div id="txFields"></div>`);
 drawTxFields();
}
function opts(arr){return arr.map(p=>`<option value="${p.id}">${esc(p.name)} — ${money(p.balance)}</option>`).join("")}
function commonAmount(){return `<div class="formGrid"><div class="field"><label>Amount</label><input id="amt" type="number" min="0.01" step="0.01"></div><div class="field"><label>Date</label><input id="date" type="date" value="${new Date().toISOString().slice(0,10)}"></div></div><div class="field"><label>Note</label><input id="note" placeholder="Optional note"></div>`}
function drawTxFields(){
 const t=by("txType").value;let h="";
 if(t==="out")h=`<div class="field"><label>Pay from</label><select id="from">${opts(parties("inhand"))}</select></div><div class="field"><label>Purpose</label><select id="destMode" onchange="toggleDest()"><option value="open">Open expense / recipient</option><option value="owe">Pay someone I owe</option></select></div><div id="dest"></div>`;
 if(t==="receive")h=`<div class="field"><label>Receive from</label><select id="from">${opts(parties("recv"))}</select></div><div class="field"><label>Receive into</label><select id="to">${opts(parties("inhand"))}</select></div>`;
 if(t==="income")h=`<div class="field"><label>Add into</label><select id="to">${opts(parties("inhand"))}</select></div><div class="field"><label>Open source</label><input id="source" placeholder="e.g. Salary"></div><div class="hint">This source is only a transaction description. It will not become a Receivable or I Owe party.</div>`;
 if(t==="internal")h=`<div class="field"><label>From person who owes you</label><select id="from">${opts(parties("recv"))}</select></div><div class="field"><label>Transfer directly to person you owe</label><select id="to">${opts(parties("owe"))}</select></div><div class="hint">No In-Hand account is affected.</div>`;
 if(t==="borrow")h=`<div class="field"><label>Person you owe</label><select id="from">${opts(parties("owe"))}</select></div><div class="field"><label>Money received into</label><select id="to">${opts(parties("inhand"))}</select></div>`;
 by("txFields").innerHTML=h+commonAmount()+`<button class="save" onclick="commitTx()">Save Transaction</button>`;
 if(t==="out")toggleDest();
}
function toggleDest(){let m=by("destMode")?.value;by("dest").innerHTML=m==="owe"?`<div class="field"><label>Pay to</label><select id="to">${opts(parties("owe"))}</select></div>`:`<div class="field"><label>Recipient / purpose</label><input id="openDest" placeholder="e.g. Grocery, Fuel"></div>`}
function commitTx(){
 const t=by("txType").value,a=Number(by("amt").value),note=by("note").value.trim();if(!(a>0))return;
 let label="",effect="neutral",f,to;
 if(t==="out"){f=party(by("from").value);if(!f||f.balance<a)return alert("Not enough balance in selected In-Hand account.");f.balance-=a;if(by("destMode").value==="owe"){to=party(by("to").value);to.balance=Math.max(0,to.balance-a);label=`Paid ${to.name} from ${f.name}`}else label=`${by("openDest").value.trim()||"Money sent"} from ${f.name}`;effect="minus"}
 if(t==="receive"){f=party(by("from").value);to=party(by("to").value);if(!f||!to)return;f.balance=Math.max(0,f.balance-a);to.balance+=a;label=`Received from ${f.name} into ${to.name}`;effect="plus"}
 if(t==="income"){to=party(by("to").value);if(!to)return;to.balance+=a;label=`${by("source").value.trim()||"Open source"} → ${to.name}`;effect="plus"}
 if(t==="internal"){f=party(by("from").value);to=party(by("to").value);if(!f||!to)return;f.balance=Math.max(0,f.balance-a);to.balance=Math.max(0,to.balance-a);label=`${f.name} paid ${to.name} directly`}
 if(t==="borrow"){f=party(by("from").value);to=party(by("to").value);if(!f||!to)return;f.balance+=a;to.balance+=a;label=`Borrowed from ${f.name} into ${to.name}`;effect="plus"}
 D.tx.push({id:uid(),ts:now(),type:t,amount:a,label:label+(note?` • ${note}`:""),effect});save();closeModal()
}

function openMember(){openModal("Add Monthly Expense Member",`<div class="field"><label>Member name</label><input id="memberName" placeholder="Roommate / colleague"></div><button class="save" onclick="addMember()">Add Member</button>`)}
function addMember(){let n=by("memberName").value.trim();if(!n)return;D.cycle.members.push({id:uid(),name:n,isMe:false});save();closeModal()}
function removeMember(id){if(!confirm("Remove this member? Existing purchases will keep their saved split."))return;D.cycle.members=D.cycle.members.filter(m=>m.id!==id);save()}

function openPurchase(){
 const payers=[...parties("inhand").map(p=>({...p,payerType:"inhand"})),...parties("owe").map(p=>({...p,payerType:"owe"}))];
 const checks=D.cycle.members.map(m=>`<label class="check"><input type="checkbox" class="splitMember" value="${m.id}" checked> ${esc(m.name)}</label>`).join("");
 openModal("Add Purchase",`<div class="field"><label>Purchase description</label><input id="purDesc" placeholder="e.g. Groceries"></div><div class="formGrid"><div class="field"><label>Amount</label><input id="purAmt" type="number" min="0.01" step="0.01"></div><div class="field"><label>Paid by</label><select id="purPayer">${payers.map(p=>`<option value="${p.payerType}:${p.id}">${esc(p.name)} (${p.payerType==="inhand"?"In Hand":"I Owe"})</option>`).join("")}</select></div></div><div class="field"><label>Split method</label><select id="splitMode" onchange="drawSplit()"><option value="equal">Equal between selected members</option><option value="custom">Custom amounts</option><option value="mine">100% My Expense</option></select></div><div id="splitArea"><div class="checkgrid">${checks}</div></div><button class="save" onclick="commitPurchase()">Save Purchase</button>`);
}
function drawSplit(){
 let mode=by("splitMode").value;
 if(mode==="equal")by("splitArea").innerHTML=`<div class="checkgrid">${D.cycle.members.map(m=>`<label class="check"><input type="checkbox" class="splitMember" value="${m.id}" checked> ${esc(m.name)}</label>`).join("")}</div>`;
 if(mode==="custom")by("splitArea").innerHTML=D.cycle.members.map(m=>`<div class="field"><label>${esc(m.name)} share</label><input class="customShare" data-id="${m.id}" type="number" min="0" step="0.01" value="0"></div>`).join("");
 if(mode==="mine")by("splitArea").innerHTML=`<div class="hint">The full purchase amount will be allocated to Me.</div>`;
}
function commitPurchase(){
 const desc=by("purDesc").value.trim()||"Purchase",a=Number(by("purAmt").value);if(!(a>0))return;
 const [pt,pid]=by("purPayer").value.split(":");const payer=party(pid);if(!payer)return;
 let shares={},mode=by("splitMode").value;
 if(mode==="mine")shares.me=a;
 if(mode==="equal"){let ids=[...document.querySelectorAll(".splitMember:checked")].map(x=>x.value);if(!ids.length)return alert("Select at least one member.");let each=a/ids.length;ids.forEach(id=>shares[id]=each)}
 if(mode==="custom"){let total=0;document.querySelectorAll(".customShare").forEach(x=>{shares[x.dataset.id]=Number(x.value||0);total+=shares[x.dataset.id]});if(Math.abs(total-a)>.01)return alert("Custom shares must add up to the purchase amount.")}
 let myShare=shares.me||0, contribution=0;
 if(pt==="inhand"){if(payer.balance<a)return alert("Not enough balance in selected In-Hand account.");payer.balance-=a;contribution=a}
 else if(pt==="owe"){payer.balance+=a}
 const ms=party("myshare");ms.balance += contribution-myShare;
 D.cycle.purchases.push({id:uid(),ts:now(),description:desc,amount:a,payerType:pt,payerId:pid,payerName:payer.name,shares,myShare});
 D.tx.push({id:uid(),ts:now(),type:"monthly",amount:a,label:`Monthly Expense: ${desc} • paid by ${payer.name}`,effect:pt==="inhand"?"minus":"neutral"});
 save();closeModal()
}
function closeCycle(){
 if(!confirm("Close this Monthly Expense cycle? The current My Share balance will remain in the ledger until settled."))return;
 D.archives.push(JSON.parse(JSON.stringify(D.cycle)));
 D.cycle={id:uid(),start:new Date().toISOString().slice(0,10),members:[{id:"me",name:"Me",isMe:true}],purchases:[]};
 save()
}
function openSettings(){
 openModal("Data & Settings",`<p class="hint">All data is stored locally on this Android device. No internet or account is required.</p><button class="secondary" onclick="backup()">Backup Data</button><div class="field"><label>Restore backup JSON</label><textarea id="restoreText" placeholder="Paste backup JSON here"></textarea></div><button class="secondary" onclick="restoreData()">Restore Data</button><button class="secondary" onclick="showView('ledger');closeModal()">Manage Ledger Parties</button>`)
}
function backup(){const s=JSON.stringify(D);navigator.clipboard?.writeText(s);openModal("Backup Ready",`<div class="field"><label>Copy and save this JSON safely</label><textarea style="min-height:240px">${esc(s)}</textarea></div><div class="hint">The backup contains your complete offline ledger and Monthly Expense data.</div>`)}
function restoreData(){try{let x=JSON.parse(by("restoreText").value);if(!x.parties||!x.cycle)throw 0;D=x;save();closeModal()}catch(e){alert("Invalid backup data.")}}
renderAll();
