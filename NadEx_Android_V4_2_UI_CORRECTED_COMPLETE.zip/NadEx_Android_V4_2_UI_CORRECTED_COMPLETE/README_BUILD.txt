NadEx Android V4.2 UI Corrected Complete Source
Upload the ZIP NadEx_Android_V4_2_UI_CORRECTED_COMPLETE.zip to the ROOT of your GitHub repository.
Create .github/workflows/build-apk.yml using the workflow supplied with this package/conversation.
The workflow extracts this ZIP and builds app-debug.apk.
