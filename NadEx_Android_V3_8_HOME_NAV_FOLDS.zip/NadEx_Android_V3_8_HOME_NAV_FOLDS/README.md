# NadEx Android V3.8

Home/reference visual update, Android system-back navigation, logical balance movement colors, reordered folded ledger overview, and preserved NadEx financial logic/data keys.
