NadEx V5.0 — Modern Banking UI

This release redesigns the complete visual layer into a premium modern banking-app interface while preserving the established NadEx finance/data logic.

UI: full usable Android safe-area layout, family artwork hero/watermark, restrained translucent banking cards, protected high-contrast text, semantic transaction colors, consistent statements/forms/popups.
Navigation: Android system Back/predictive back routes popup -> party/statement -> Ledger/Expenses -> Home -> exit. Vertical touch/scroll remains native on long pages.
Data: existing local storage keys, transactions, expense cycles, party limits, multi-currency and backup/restore behavior preserved.
