NadEx V4.6 — Neon Glass Redesign
- Full-screen usable app area respecting Android system bars.
- Family-only artwork dissolved into upper 25% of Home.
- Lower 60% reserved for two primary neon-glass modules.
- Lower 15% Developed By ندیم صدیقی.
- Transparent neon-glass styling across Ledger, Expense, Party statements, tables and popups.
- Family watermark on inner screens with protective dark glass for readability.
- Android back gesture routing retained throughout app layers.
- Existing NadEx data/accounting logic retained.
