# NedEx Offline Ledger V1.0

A completely separate offline Android app.

Package ID: ae.nedex.simpleledger
Version: 1.0 (versionCode 1)

Core model:
- In Hand: cash/cards/wallets
- Receivables: people who owe you
- I Owe: people you owe
- Open-source income adds directly to In Hand without creating a party
- Internal transfer: Receivable -> I Owe without touching In Hand
- Fixed My Share account linked to Monthly Expense
- Monthly Expense cycles remain open until manually closed
- Flexible members and equal/custom/100%-mine splits
- Purchase payer can be In Hand or I Owe
- Fully offline localStorage
- Backup/Restore JSON
- Dedicated in-app Back buttons

Visual assets reused from the prior NadEx package only as requested. Financial data and application package are independent.
