
(function(){
'use strict';
const num=v=>Number.isFinite(Number(v))?Number(v):0;
function show(v){try{return String(fmt(Math.abs(num(v)))).replace(/\b(AED|USD|PKR|INR|GBP|EUR)\b/gi,'').trim()}catch(e){return Math.abs(num(v)).toFixed(2)}}
function limitOf(s){
  if(!s)return 0;
  for(const v of [s.limit,s.creditLimit,s.oweLimit,s.borrowLimit,s.partyLimit,s.maxLimit,s.limitAmount]){
    if(num(v)>0)return num(v);
  }
  const k=s.key||s.partyKey;
  for(const c of [D.parties,D.partySettings,D.partyLimits]){
    if(!c)continue;
    const o=Array.isArray(c)?c.find(x=>x&&(x.key===k||x.partyKey===k||x.name===s.name)):(k?c[k]:null);
    if(o)for(const v of [o.limit,o.creditLimit,o.oweLimit,o.borrowLimit,o.partyLimit,o.maxLimit,o.limitAmount])if(num(v)>0)return num(v);
  }
  return 0;
}
function apply(){
  let all;try{all=states()}catch(e){return}
  document.querySelectorAll('[onclick*="party("]').forEach(card=>{
    const m=(card.getAttribute('onclick')||'').match(/party\((['"])(.*?)\1\)/);
    if(!m)return;
    const st=all.find(x=>String(x.key)===m[2]);
    if(!st)return;
    const lim=limitOf(st),owed=Math.max(0,-num(st.net));
    let box=card.querySelector('.nx-remaining-limit');
    if(!(lim>0&&owed>0)){if(box)box.remove();return}
    if(!box){box=document.createElement('div');box.className='nx-remaining-limit';card.appendChild(box)}
    const rem=lim-owed;
    box.innerHTML='<span>LIMIT '+show(lim)+'</span><strong>'+(rem>=0?'REMAINING '+show(rem):'OVER LIMIT '+show(-rem))+'</strong>';
  });
}
const old=window.renderLedger;
if(typeof old==='function')window.renderLedger=function(){const r=old.apply(this,arguments);setTimeout(apply,0);return r};
document.addEventListener('DOMContentLoaded',()=>setTimeout(apply,0));
setTimeout(apply,250);
})();
