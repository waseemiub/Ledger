# NadEx Android V6.2 — Edit Save Fix

Built directly from the supplied V6.1 package.

Only targeted functional fix:
- Edit Transaction -> SAVE CHANGES now executes without depending on removed currency controls.
- Amount, description, date and time can be edited.
- Legacy linked transfers remain synchronized.
- V6.1 universal paired transactions remain synchronized through movementId.
- Existing local data, balances, Monthly Expense, My Share and V6.1 transaction design are preserved.
- Currency options remain removed and amounts remain numbers-only.

Version 6.2
versionCode 62
applicationId ae.transactor.app
