
/* NadEx V6.2 — surgical Edit -> Save fix.
   No currency UI. No accounting redesign. Existing and V6.1 paired records remain linked. */
(function(){
'use strict';

window.transactionActions = function(id){
  const t = D.transactions.find(x => x.id === id);
  if(!t) return;

  // Expense-linked records remain controlled by the Monthly Expense purchase.
  if(t.messId){
    const p = M.purchases.find(x => x.id === t.messId);
    modal('Expense-linked Transaction',
      `<div class="note">This Ledger entry is controlled by its Monthly Expense purchase so both records remain consistent.</div>
       <div class="opts two">
         <button id="editLinked">Edit Expense Purchase</button>
         <button id="deleteLinked" class="danger">Delete Expense Purchase</button>
       </div>`);
    $('editLinked').onclick = () => {
      close();
      p ? openPurchase({editId:p.id}) : alert('Linked expense purchase was not found.');
    };
    $('deleteLinked').onclick = () => {
      close();
      p ? deletePurchase(p.id) : alert('Linked expense purchase was not found.');
    };
    return;
  }

  // Legacy transfers use transferId. V6.1 universal movements use movementId.
  let linked = [t];
  if(t.transferId) linked = D.transactions.filter(x => x.transferId === t.transferId);
  else if(t.movementId) linked = D.transactions.filter(x => x.movementId === t.movementId);

  const dt = new Date(t.ts || Date.now());
  const pad = v => String(v).padStart(2,'0');
  const date = `${dt.getFullYear()}-${pad(dt.getMonth()+1)}-${pad(dt.getDate())}`;
  const time = `${pad(dt.getHours())}:${pad(dt.getMinutes())}`;
  const amount = Number(t.amount ?? t.valueAmount ?? t.aedAmount ?? t.originalAmount) || 0;
  const isLinked = linked.length > 1;

  modal(isLinked ? 'Edit Linked Transaction' : 'Edit Transaction',
    `<div class="field">
       <label>Amount</label>
       <input id="editAmt" type="number" inputmode="decimal" step=".01" min=".01" value="${esc(amount)}">
     </div>
     <div class="field">
       <label>Description</label>
       <textarea id="editDesc">${esc(t.description || '')}</textarea>
     </div>
     <div class="field">
       <label>Date</label>
       <input id="editDate" type="date" value="${date}">
     </div>
     <div class="field">
       <label>Time</label>
       <input id="editTime" type="time" value="${time}">
     </div>
     ${isLinked ? '<div class="linked">Amount and date/time will be updated on both sides. The description applies to the selected record only.</div>' : ''}
     <div class="opts two">
       <button id="saveTx" class="primary">SAVE CHANGES</button>
       <button id="deleteTx" class="danger">DELETE</button>
     </div>`);

  $('saveTx').onclick = () => {
    const amt = Math.round(Number($('editAmt').value) * 100) / 100;
    if(!(amt > 0)) return alert('Enter a valid amount.');

    const dateValue = $('editDate').value;
    const timeValue = $('editTime').value;
    if(!dateValue || !timeValue) return alert('Enter a valid date and time.');

    const nts = new Date(`${dateValue}T${timeValue}:00`).getTime();
    if(!Number.isFinite(nts)) return alert('Enter a valid date and time.');

    // Update all linked sides with the same numeric amount.
    linked.forEach((x,i) => {
      x.amount = amt;
      x.ts = nts + i;

      // Keep legacy fields numerically synchronized without doing conversion.
      if(Object.prototype.hasOwnProperty.call(x,'originalAmount')) x.originalAmount = amt;
      if(Object.prototype.hasOwnProperty.call(x,'aedAmount')) x.aedAmount = amt;
      if(Object.prototype.hasOwnProperty.call(x,'valueAmount')) x.valueAmount = amt;
      if(Object.prototype.hasOwnProperty.call(x,'fxRate')) x.fxRate = 1;
      if(Object.prototype.hasOwnProperty.call(x,'fxRateToValue')) x.fxRateToValue = 1;
      if(Object.prototype.hasOwnProperty.call(x,'originalCurrency')) x.originalCurrency = '';
      if(Object.prototype.hasOwnProperty.call(x,'valueCurrency')) x.valueCurrency = '';
    });

    t.description = $('editDesc').value.trim();

    localStorage.setItem(K, JSON.stringify(D));
    close();
    renderLedger();

    // Return to the same statement safely if it still exists.
    if(window.__partyKey) party(window.__partyKey);
  };

  $('deleteTx').onclick = () => {
    const title = isLinked ? 'Delete Linked Transaction?' : 'Delete Transaction?';
    const msg = isLinked ? 'Both sides of this transaction will be removed.' : 'This transaction will be permanently removed.';
    nxConfirm(title, msg, 'DELETE', () => {
      if(t.transferId) D.transactions = D.transactions.filter(x => x.transferId !== t.transferId);
      else if(t.movementId) D.transactions = D.transactions.filter(x => x.movementId !== t.movementId);
      else D.transactions = D.transactions.filter(x => x.id !== t.id);

      localStorage.setItem(K, JSON.stringify(D));
      close();
      renderLedger();
      if(window.__partyKey) party(window.__partyKey);
    });
  };
};
})();
