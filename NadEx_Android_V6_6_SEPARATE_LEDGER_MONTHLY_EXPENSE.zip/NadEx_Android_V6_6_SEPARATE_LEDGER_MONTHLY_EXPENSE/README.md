# NadEx V6.6 — Separate Ledger and Monthly Expense

Built from V6.5, with the requested structural separation.

- Monthly Expense is completely independent from Ledger.
- Saving/editing/deleting a Monthly Expense purchase does not post to My Share or any Ledger party.
- Historical messId auto-posts are ignored by Ledger calculations.
- New Purchase and Edit Purchase use a self-contained numbers-only editor and verified localStorage save.
- My Share remains a manual Ledger account.
- My Expense is information-only and reflects manual My Share/My Expense Ledger entries.
- Selecting My Expense in the universal Ledger transaction creates only Ledger entries; it never creates a Monthly Expense purchase.
- V6.3 transaction Edit/Save remains intact.
- V6.4 party remaining-limit feature remains intact.
- Existing localStorage keys and stored Monthly Expense data are preserved.

Version 6.6 / versionCode 66 / applicationId ae.transactor.app
