# NadEx V6.5 — Monthly Expense Link Restore

Built directly from V6.4.

Targeted fixes:
- Restores + Buy and + New Purchase buttons in Monthly Expense.
- Restores My Share as the live settlement account linked to Monthly Expense.
- My Share card opens the expense-linked My Share statement.
- My Share balance comes from current Monthly Expense messStats().
- My Expense shows only the user's allocated share from Monthly Expense, not the full cycle purchase total.
- My Share moves to Money I Owe when negative and Money I Will Get when positive.
- Section totals include the live My Share balance on the correct side.
- Keeps the working V6.3 Edit/Save controller.
- Keeps V6.4 Remaining Limit and corrects it to use the app's actual party balance field.
- No currency controls restored and no unrelated transaction redesign.

Version 6.5 / versionCode 65 / applicationId ae.transactor.app
