
/* NadEx V6.5 — Monthly Expense / My Share link restoration.
   Restores bindings and authoritative displays without changing transaction accounting. */
(function(){
'use strict';
const E=id=>document.getElementById(id);
const N=v=>Number.isFinite(Number(v))?Number(v):0;

function mine(){
  try{
    const r=messStats(), x=r.stats.get(me().id);
    return x||{paid:0,share:0,balance:0};
  }catch(e){ return {paid:0,share:0,balance:0}; }
}
function myExpense(){
  try{return myExpenseData()}catch(e){return {items:[],total:0}}
}
function cleanMoney(v){
  try{return money(Math.abs(N(v)))}catch(e){return Math.abs(N(v)).toFixed(2)}
}

/* The two Monthly Expense purchase buttons are rebound after every render.
   This avoids later render wrappers leaving a visible but inactive button. */
function bindPurchaseButtons(){
  const a=E('newPurchase'), b=E('newPurchaseTop');
  if(a) a.onclick=function(ev){ev.preventDefault();ev.stopPropagation();openPurchase({});};
  if(b) b.onclick=function(ev){ev.preventDefault();ev.stopPropagation();openPurchase({});};
}

/* Keep Monthly Expense summary authoritative:
   - TOTAL SPEND remains the cycle total.
   - MY SHARE BALANCE is only this user's net Monthly Expense position. */
function restoreMessSummary(){
  const x=mine();
  const bal=E('myMessBalance'), meaning=E('myMessMeaning');
  if(bal){
    bal.textContent=(x.balance>0?'+ ':x.balance<0?'− ':'')+cleanMoney(x.balance);
    bal.className=x.balance>0?'pos':x.balance<0?'neg':'neu';
  }
  if(meaning) meaning.textContent=x.balance>0?'Mess owes you':x.balance<0?'You owe Mess':'Balanced';
}

/* Keep the Ledger My Expense card strictly equal to MY allocated share of
   Monthly Expense purchases — never the full family/cycle purchase total. */
function restoreMyExpenseCard(){
  const x=myExpense(), box=E('expenseAccount');
  if(!box)return;
  const card=box.querySelector('[data-expense]');
  if(!card)return;
  const top=card.querySelector('.account-overview-top > b');
  if(top) top.textContent=cleanMoney(x.total);
  const total=card.querySelector('.account-overview-stats span:first-child b');
  if(total) total.textContent=cleanMoney(x.total);
  card.onclick=function(){party(MY_EXPENSE_VIEW_KEY);};
}

/* My Share is the live Monthly Expense settlement account.
   Recreate/update its Ledger card from messStats(), and keep the card linked
   to the expense-linked My Share statement from V5.8. */
function restoreMyShareCard(){
  const x=mine(), bal=N(x.balance);
  const pay=E('payments'), rec=E('receivables');
  if(!pay||!rec)return;

  let card=document.querySelector('[data-k="'+EXPENSE_KEY+'"]');
  const target=bal<0?pay:rec;

  if(!card){
    card=document.createElement('article');
    card.className='account-overview-card';
    card.setAttribute('data-k',EXPENSE_KEY);
  }
  if(card.parentElement!==target) target.prepend(card);

  card.innerHTML=
    '<div class="account-overview-top"><div><small>'+
      (bal>0?'You will receive':bal<0?'You owe':'Settled')+
      '</small><h3>'+esc(EXPENSE_NAME)+'</h3></div><b class="'+
      (bal>0?'pos':bal<0?'neg':'neu')+'">'+cleanMoney(bal)+'</b></div>'+
    '<div class="account-overview-stats">'+
      '<span><small>PAID</small><b>'+cleanMoney(x.paid)+'</b></span>'+
      '<span><small>MY SHARE</small><b>'+cleanMoney(x.share)+'</b></span>'+
      '<span><small>BALANCE</small><b>'+cleanMoney(bal)+'</b></span>'+
    '</div>'+
    '<div class="account-overview-foot"><span>Linked to Monthly Expense</span><b>View statement ›</b></div>';

  card.onclick=function(){party(EXPENSE_KEY);};
}

/* Recalculate section headings so My Share belongs to the correct side,
   while My Expense remains informational and equals only the user's share. */
function restoreSectionTotals(){
  let s=[];try{s=states()}catch(e){}
  const x=mine(), sb=N(x.balance);
  const others=s.filter(p=>!p.wallet&&p.key!==EXPENSE_KEY);
  const wallets=s.filter(p=>p.wallet);
  const pay=others.filter(p=>N(p.balance)<0).reduce((a,p)=>a+Math.abs(N(p.balance)),0)+Math.max(-sb,0);
  const rec=others.filter(p=>N(p.balance)>0).reduce((a,p)=>a+N(p.balance),0)+Math.max(sb,0);
  const wal=wallets.reduce((a,p)=>a+N(p.balance),0);
  const exp=N(myExpense().total);

  const set=(cls,label,val)=>{
    const b=document.querySelector('#ledgerView .group.'+cls+' .section-total');
    if(b)b.innerHTML='<small>'+label+'</small>'+cleanMoney(val);
  };
  set('pay','BALANCE',pay); set('rec','BALANCE',rec);
  set('wallet','BALANCE',wal); set('expense','TOTAL',exp);
}

function repairMess(){
  bindPurchaseButtons();
  restoreMessSummary();
}
function repairLedger(){
  restoreMyShareCard();
  restoreMyExpenseCard();
  restoreSectionTotals();
}

/* Wrap the final V6.1/V6.3/V6.4 render chains instead of replacing them. */
const oldMess=window.renderMess;
window.renderMess=function(){
  const r=oldMess.apply(this,arguments);
  repairMess();
  return r;
};
const oldLedger=window.renderLedger;
window.renderLedger=function(){
  const r=oldLedger.apply(this,arguments);
  repairLedger();
  return r;
};

/* Also restore bindings when entering Monthly Expense directly. */
document.addEventListener('DOMContentLoaded',function(){
  setTimeout(function(){repairMess();repairLedger();},0);
});
setTimeout(function(){repairMess();repairLedger();},250);
})();
